#import "VRTStudioModule.h"
#import "RVStudioWatermarkState.h"
#import <React/RCTUtils.h>
#import <ViroKit/VROColocationBridge.h>

static NSString *const kBaseUrl      = @"https://platform.reactvision.xyz";
// kBaseUrl's database region, sent as x-region so its edge functions run beside
// the database instead of nearest the device. A session on another base URL is
// pinned only when it brings its own functionRegion.
static NSString *const kFunctionRegion = @"eu-west-2";
static NSString *const kApiKeyKey    = @"RVApiKey";
static NSString *const kProjectIdKey = @"RVProjectId";
static const NSTimeInterval kTimeout = 30.0;
// scene-api-request waits on the upstream API (timeout_ms caps at 30s), so the
// transport must outlive the proxy's own timeout or valid requests get cut off.
static const NSTimeInterval kApiRequestTimeout = 40.0;

// @internal session auth for first-party apps (e.g. StudioGo). When set, the
// fetch methods target this base URL with Authorization: Bearer + x-rv-client
// and send NO x-api-key, so the server's resolveApiAuth takes the JWT path.
// Immutable snapshot; module methods run serially on one methodQueue.
static NSDictionary *gStudioSession = nil;

// Called off the method queue (the AR navigator's main-thread prop setter), so
// it only compares the pointer and never dereferences the snapshot.
BOOL VRTStudioHasSession(void) {
    return gStudioSession != nil;
}

// What the gateway answers when it never reached a function. With a non-JSON
// body (every platform function answers JSON) nothing ran, so a resend cannot
// run a request twice. 500, 504, 520, 524 and 546 are left out: a function may
// have run before any of them.
static BOOL VRTUndelivered(NSHTTPURLResponse *http) {
    switch (http.statusCode) {
        case 502: case 503: case 521: case 522: case 523: case 525: case 526: case 530:
            return ![http.MIMEType containsString:@"json"];
        default:
            return NO;
    }
}

// The platform does not fail a pinned region over, so an undelivered pinned
// request is sent once more without x-region.
static NSDictionary *VRTUnpinned(NSDictionary *headers) {
    NSMutableDictionary *unpinned = [headers mutableCopy];
    [unpinned removeObjectForKey:@"x-region"];
    return unpinned;
}

@implementation VRTStudioModule

RCT_EXPORT_MODULE(VRTStudio);

- (NSString *)readInfoString:(NSString *)key {
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    NSString *v = info[key];
    return (v.length > 0) ? v : nil;
}

- (NSString *)readApiKey    { return [self readInfoString:kApiKeyKey]; }
- (NSString *)readProjectId { return [self readInfoString:kProjectIdKey]; }

// Resolves { mode, baseUrl, headers } for the active auth mode. A set session
// wins over the manifest RVApiKey. Returns nil when neither is available.
- (NSDictionary *)authContext {
    NSDictionary *session = gStudioSession;
    if (session) {
        NSMutableDictionary *headers = [NSMutableDictionary new];
        headers[@"Authorization"] = [NSString stringWithFormat:@"Bearer %@", session[@"accessToken"]];
        NSString *clientTag = session[@"clientTag"];
        if (clientTag.length > 0) headers[@"x-rv-client"] = clientTag;
        NSString *region = session[@"functionRegion"];
        if (region.length == 0 && [session[@"baseUrl"] isEqualToString:kBaseUrl]) region = kFunctionRegion;
        if (region.length > 0) headers[@"x-region"] = region;
        return @{@"mode": @"session", @"baseUrl": session[@"baseUrl"], @"headers": headers};
    }
    NSString *apiKey = [self readApiKey];
    if (!apiKey) return nil;
    return @{@"mode": @"api_key", @"baseUrl": kBaseUrl,
             @"headers": @{@"x-api-key": apiKey, @"x-region": kFunctionRegion}};
}

- (void)runGet:(NSString *)url headers:(NSDictionary *)headers resolve:(RCTPromiseResolveBlock)resolve {
    NSURL *nsUrl = [NSURL URLWithString:url];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:nsUrl
                                                       cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                   timeoutInterval:kTimeout];
    [req setHTTPMethod:@"GET"];
    [headers enumerateKeysAndObjectsUsingBlock:^(NSString *name, NSString *value, BOOL *stop) {
        [req setValue:value forHTTPHeaderField:name];
    }];

    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSMutableDictionary *r = [NSMutableDictionary new];
        if (error) {
            [r setObject:@NO  forKey:@"success"];
            [r setObject:error.localizedDescription forKey:@"error"];
            resolve(r);
            return;
        }
        NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
        if (headers[@"x-region"] && VRTUndelivered(http)) {
            [self runGet:url headers:VRTUnpinned(headers) resolve:resolve];
            return;
        }
        BOOL ok = http.statusCode >= 200 && http.statusCode < 300;
        [r setObject:@(ok) forKey:@"success"];
        if (ok && data) {
            NSString *body = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            if (body) [r setObject:body forKey:@"data"];
        }
        if (!ok) {
            NSString *body = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
            [r setObject:body ?: [NSString stringWithFormat:@"HTTP %ld", (long)http.statusCode] forKey:@"error"];
        }
        resolve(r);
    }] resume];
}

- (void)runPost:(NSString *)url
           body:(NSString *)bodyJson
        headers:(NSDictionary *)headers
        resolve:(RCTPromiseResolveBlock)resolve {
    NSURL *nsUrl = [NSURL URLWithString:url];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:nsUrl
                                                       cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                   timeoutInterval:kApiRequestTimeout];
    [req setHTTPMethod:@"POST"];
    [req setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [headers enumerateKeysAndObjectsUsingBlock:^(NSString *name, NSString *value, BOOL *stop) {
        [req setValue:value forHTTPHeaderField:name];
    }];
    [req setHTTPBody:[bodyJson dataUsingEncoding:NSUTF8StringEncoding]];

    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSMutableDictionary *r = [NSMutableDictionary new];
        if (error) {
            [r setObject:@NO  forKey:@"success"];
            [r setObject:error.localizedDescription forKey:@"error"];
            resolve(r);
            return;
        }
        NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
        if (headers[@"x-region"] && VRTUndelivered(http)) {
            [self runPost:url body:bodyJson headers:VRTUnpinned(headers) resolve:resolve];
            return;
        }
        BOOL ok = http.statusCode >= 200 && http.statusCode < 300;
        [r setObject:@(ok) forKey:@"success"];
        if (ok && data) {
            NSString *body = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            if (body) [r setObject:body forKey:@"data"];
        }
        if (!ok) {
            NSString *body = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
            [r setObject:body ?: [NSString stringWithFormat:@"HTTP %ld", (long)http.statusCode] forKey:@"error"];
        }
        resolve(r);
    }] resume];
}

// JS sends the full scene-api-request body ({"function_id", "variables"}) as a
// pre-serialised string; native only transmits it, so there is no JSON
// construction to keep in sync across platforms.
RCT_EXPORT_METHOD(rvStudioApiRequest:(NSString *)bodyJson
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject) {
    NSDictionary *ctx = [self authContext];
    if (!ctx) {
        resolve(@{@"success": @NO, @"error": @"RVApiKey not set in Info.plist"});
        return;
    }
    NSString *url = [NSString stringWithFormat:@"%@/functions/v1/scene-api-request", ctx[@"baseUrl"]];
    [self runPost:url body:bodyJson headers:ctx[@"headers"] resolve:resolve];
}

RCT_EXPORT_METHOD(rvGetScene:(NSString *)sceneId
                     resolve:(RCTPromiseResolveBlock)resolve
                      reject:(RCTPromiseRejectBlock)reject) {
    NSDictionary *ctx = [self authContext];
    if (!ctx) {
        resolve(@{@"success": @NO, @"error": @"RVApiKey not set in Info.plist"});
        return;
    }
    NSString *url = [NSString stringWithFormat:@"%@/functions/v1/scenes/%@",
                     ctx[@"baseUrl"],
                     [sceneId stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLPathAllowedCharacterSet]];
    // Watermark applies only to API-key (SDK) consumers; session auth is exempt.
    // Derived and gated natively so a JS consumer can't strip it or opt in.
    BOOL deriveWatermark = (gStudioSession == nil);
    RCTPromiseResolveBlock cb = resolve;
    if (deriveWatermark) {
        cb = ^(id result) {
            if ([result isKindOfClass:[NSDictionary class]]) {
                [[RVStudioWatermarkState sharedState] updateFromSceneResponse:result];
            }
            resolve(result);
        };
    }
    [self runGet:url headers:ctx[@"headers"] resolve:cb];
}

RCT_EXPORT_METHOD(rvGetProject:(RCTPromiseResolveBlock)resolve
                        reject:(RCTPromiseRejectBlock)reject) {
    NSDictionary *ctx = [self authContext];
    if (!ctx) {
        resolve(@{@"success": @NO, @"error": @"RVApiKey not set in Info.plist"});
        return;
    }
    NSString *projectId = [self readProjectId];
    if (!projectId) {
        resolve(@{@"success": @NO, @"error": @"RVProjectId not set in Info.plist"});
        return;
    }
    NSString *url = [NSString stringWithFormat:@"%@/functions/v1/projects/%@",
                     ctx[@"baseUrl"],
                     [projectId stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLPathAllowedCharacterSet]];
    [self runGet:url headers:ctx[@"headers"] resolve:resolve];
}

RCT_EXPORT_METHOD(rvGetProjectId:(RCTPromiseResolveBlock)resolve
                          reject:(RCTPromiseRejectBlock)reject) {
    NSString *projectId = [self readProjectId];
    resolve(projectId ?: [NSNull null]);
}

// Rules for the internal session config, shared with Android's StudioSessionRules. The
// session's bearer token goes to baseUrl on every Studio, cloud-anchor and co-location
// request, so baseUrl must be https; cleartext is allowed only for the hosts a local platform
// runs on (localhost, 127.0.0.1, and 10.0.2.2 for parity with the Android emulator).
// functionRegion is sent as the x-region header, so it must be a plain region slug.

// Returns nil when value is absent or NSNull, sets *error when it is not a string.
static NSString *RVOptionalString(NSDictionary *config, NSString *key, NSString **error) {
    id value = config[key];
    if (value == nil || value == [NSNull null]) return nil;
    if (![value isKindOfClass:[NSString class]]) {
        *error = [NSString stringWithFormat:@"%@ must be a string", key];
        return nil;
    }
    return value;
}

// Returns baseUrl without trailing slashes, or nil with *error set.
static NSString *RVValidatedBaseUrl(NSString *baseUrl, NSString **error) {
    NSURLComponents *components = [NSURLComponents componentsWithString:baseUrl];
    if (!components) {
        *error = @"baseUrl is not a valid URL";
        return nil;
    }
    NSString *scheme = components.scheme.lowercaseString ?: @"";
    NSString *host = components.host.lowercaseString;
    if (![scheme isEqualToString:@"https"] && ![scheme isEqualToString:@"http"]) {
        *error = @"baseUrl must use https";
        return nil;
    }
    if (host.length == 0) {
        *error = @"baseUrl has no host";
        return nil;
    }
    if ([scheme isEqualToString:@"http"] &&
        ![@[@"localhost", @"127.0.0.1", @"10.0.2.2"] containsObject:host]) {
        *error = @"baseUrl must use https; http is allowed only for localhost, 127.0.0.1 and 10.0.2.2";
        return nil;
    }
    if (components.user != nil || components.password != nil) {
        *error = @"baseUrl must not contain credentials";
        return nil;
    }
    if (components.query != nil) {
        *error = @"baseUrl must not have a query";
        return nil;
    }
    if (components.fragment != nil) {
        *error = @"baseUrl must not have a fragment";
        return nil;
    }
    while ([baseUrl hasSuffix:@"/"]) {
        baseUrl = [baseUrl substringToIndex:baseUrl.length - 1];
    }
    return baseUrl;
}

// Empty means "not pinned", as before. Anything else must match ^[a-z0-9-]{1,32}$.
static BOOL RVValidFunctionRegion(NSString *region) {
    if (region.length == 0) return YES;
    if (region.length > 32) return NO;
    NSCharacterSet *allowed =
        [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyz0123456789-"];
    return [region rangeOfCharacterFromSet:allowed.invertedSet].location == NSNotFound;
}

static void RVClearStudioSession(void) {
    gStudioSession = nil;
    [VROColocationBridge setStudioSessionBaseUrl:nil accessToken:nil clientTag:nil];
}

// @internal — sets/clears the first-party session auth (see gStudioSession).
// A dict { baseUrl, accessToken, clientTag?, functionRegion? } enables session mode; nil,
// NSNull, or a missing or empty baseUrl or accessToken reverts to manifest RVApiKey mode. A
// config that breaks a rule above (wrong type, non-https baseUrl, malformed functionRegion) is
// rejected with E_INVALID_STUDIO_SESSION and also clears the session, so a bad config never
// leaves an older token pointed at an older host. The renderer keeps its own copy, which
// cloud anchors and the co-location channel read.
RCT_EXPORT_METHOD(rvSetStudioSession:(id)config
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject) {
    if (config == nil || config == [NSNull null]) {
        RVClearStudioSession();
        resolve([NSNull null]);
        return;
    }
    NSString *error = nil;
    if (![config isKindOfClass:[NSDictionary class]]) {
        error = @"session config must be an object";
    }
    NSString *baseUrl = nil, *accessToken = nil, *clientTag = nil, *functionRegion = nil;
    if (!error) baseUrl = RVOptionalString(config, @"baseUrl", &error);
    if (!error) accessToken = RVOptionalString(config, @"accessToken", &error);
    if (!error) clientTag = RVOptionalString(config, @"clientTag", &error);
    if (!error) functionRegion = RVOptionalString(config, @"functionRegion", &error);
    if (!error && (baseUrl.length == 0 || accessToken.length == 0)) {
        RVClearStudioSession();
        resolve([NSNull null]);
        return;
    }
    if (!error) baseUrl = RVValidatedBaseUrl(baseUrl, &error);
    if (!error && !RVValidFunctionRegion(functionRegion)) {
        error = @"functionRegion must match ^[a-z0-9-]{1,32}$";
    }
    if (error) {
        RVClearStudioSession();
        reject(@"E_INVALID_STUDIO_SESSION", error, nil);
        return;
    }
    NSMutableDictionary *snapshot =
        [@{ @"baseUrl": baseUrl, @"accessToken": accessToken } mutableCopy];
    if (clientTag.length > 0) snapshot[@"clientTag"] = clientTag;
    if (functionRegion.length > 0) snapshot[@"functionRegion"] = functionRegion;
    gStudioSession = [snapshot copy];
    [VROColocationBridge setStudioSessionBaseUrl:baseUrl
                                     accessToken:accessToken
                                       clientTag:snapshot[@"clientTag"]
                                  functionRegion:snapshot[@"functionRegion"]];
    resolve([NSNull null]);
}

// @internal Credentials for JS clients that talk to the platform or the relay
// directly: { mode, baseUrl, headers, projectId }, projectId being the
// manifest RVProjectId in every mode.
RCT_EXPORT_METHOD(rvGetAuthHeaders:(RCTPromiseResolveBlock)resolve
                            reject:(RCTPromiseRejectBlock)reject) {
    NSDictionary *ctx = [self authContext];
    NSString *projectId = [self readProjectId];
    resolve(@{
        @"mode":      ctx[@"mode"] ?: @"none",
        @"baseUrl":   ctx[@"baseUrl"] ?: [NSNull null],
        @"headers":   ctx[@"headers"] ?: @{},
        @"projectId": projectId ?: [NSNull null],
    });
}

// @internal Project the ReactVision cloud anchor provider files anchors under,
// overriding RVProjectId. null / NSNull / empty clears the override.
RCT_EXPORT_METHOD(rvSetCloudAnchorProject:(id)projectId
                                  resolve:(RCTPromiseResolveBlock)resolve
                                   reject:(RCTPromiseRejectBlock)reject) {
    NSString *value = [projectId isKindOfClass:[NSString class]] ? projectId : nil;
    [VROColocationBridge setCloudAnchorProjectId:value];
    resolve([NSNull null]);
}

@end

//
//  VRTARUtils.m
//  ViroReact
//
//  Copyright © 2017 Viro Media. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining
//  a copy of this software and associated documentation files (the
//  "Software"), to deal in the Software without restriction, including
//  without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to
//  permit persons to whom the Software is furnished to do so, subject to
//  the following conditions:
//
//  The above copyright notice and this permission notice shall be included
//  in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//  CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import "VRTARUtils.h"
#import <AVFoundation/AVFoundation.h>
#import <CoreLocation/CoreLocation.h>
#import <Photos/Photos.h>

// Delegate that resolves a completion block once CLLocationManager reports a determined status.
@interface ViroLocationRequestDelegate : NSObject <CLLocationManagerDelegate>
@property (nonatomic, copy) void (^completion)(BOOL granted);
@end

@implementation ViroLocationRequestDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    if (status == kCLAuthorizationStatusNotDetermined) return;
    if (self.completion) {
        self.completion(status == kCLAuthorizationStatusAuthorizedWhenInUse ||
                        status == kCLAuthorizationStatusAuthorizedAlways);
        self.completion = nil;
    }
}
@end

@implementation VRTARUtils {
    CLLocationManager *_locationManager;
    ViroLocationRequestDelegate *_locationDelegate;
}

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(requestRequiredPermissions:(NSArray<NSString *> *)permissions
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
    dispatch_group_t group = dispatch_group_create();
    NSMutableDictionary *result = [NSMutableDictionary dictionary];

    if ([permissions containsObject:@"camera"]) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusAuthorized) {
            result[@"camera"] = @YES;
        } else if (status == AVAuthorizationStatusNotDetermined) {
            dispatch_group_enter(group);
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                result[@"camera"] = @(granted);
                dispatch_group_leave(group);
            }];
        } else {
            result[@"camera"] = @NO;
        }
    }

    if ([permissions containsObject:@"microphone"]) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
        if (status == AVAuthorizationStatusAuthorized) {
            result[@"microphone"] = @YES;
        } else if (status == AVAuthorizationStatusNotDetermined) {
            dispatch_group_enter(group);
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {
                result[@"microphone"] = @(granted);
                dispatch_group_leave(group);
            }];
        } else {
            result[@"microphone"] = @NO;
        }
    }

    if ([permissions containsObject:@"storage"]) {
        PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
        if (status == PHAuthorizationStatusAuthorized) {
            result[@"storage"] = @YES;
        } else if (status == PHAuthorizationStatusNotDetermined) {
            dispatch_group_enter(group);
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus s) {
                result[@"storage"] = @(s == PHAuthorizationStatusAuthorized);
                dispatch_group_leave(group);
            }];
        } else {
            result[@"storage"] = @NO;
        }
    }

    if ([permissions containsObject:@"location"]) {
        CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
        if (status == kCLAuthorizationStatusAuthorizedWhenInUse || status == kCLAuthorizationStatusAuthorizedAlways) {
            result[@"location"] = @YES;
        } else if (status == kCLAuthorizationStatusNotDetermined) {
            dispatch_group_enter(group);
            _locationManager = [[CLLocationManager alloc] init];
            _locationDelegate = [[ViroLocationRequestDelegate alloc] init];
            _locationDelegate.completion = ^(BOOL granted) {
                result[@"location"] = @(granted);
                dispatch_group_leave(group);
            };
            _locationManager.delegate = _locationDelegate;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self->_locationManager requestWhenInUseAuthorization];
            });
        } else {
            result[@"location"] = @NO;
        }
    }

    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        resolve([result copy]);
    });
}

RCT_EXPORT_METHOD(checkPermissions:(NSArray<NSString *> *)permissions
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
    NSMutableDictionary *result = [NSMutableDictionary dictionary];

    if ([permissions containsObject:@"camera"]) {
        result[@"camera"] = @([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo] == AVAuthorizationStatusAuthorized);
    }
    if ([permissions containsObject:@"microphone"]) {
        result[@"microphone"] = @([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio] == AVAuthorizationStatusAuthorized);
    }
    if ([permissions containsObject:@"storage"]) {
        result[@"storage"] = @([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusAuthorized);
    }
    if ([permissions containsObject:@"location"]) {
        CLAuthorizationStatus locStatus = [CLLocationManager authorizationStatus];
        result[@"location"] = @(locStatus == kCLAuthorizationStatusAuthorizedWhenInUse ||
                                locStatus == kCLAuthorizationStatusAuthorizedAlways);
    }

    resolve([result copy]);
}

RCT_EXPORT_METHOD(isARSupported:(RCTResponseSenderBlock)callback)
{
  bool result = [VROViewAR isARSupported];
  NSDictionary *props = @{@"isARSupported" : @(result)};
  callback(@[[NSNull null], props]);
}

// Helper function to convert plane classification enum to string
+ (NSString *)stringFromPlaneClassification:(VROARPlaneClassification)classification {
    switch (classification) {
        case VROARPlaneClassification::Wall:
            return @"Wall";
        case VROARPlaneClassification::Floor:
            return @"Floor";
        case VROARPlaneClassification::Ceiling:
            return @"Ceiling";
        case VROARPlaneClassification::Table:
            return @"Table";
        case VROARPlaneClassification::Seat:
            return @"Seat";
        case VROARPlaneClassification::Door:
            return @"Door";
        case VROARPlaneClassification::Window:
            return @"Window";
        case VROARPlaneClassification::Unknown:
            return @"Unknown";
        case VROARPlaneClassification::None:
        default:
            return @"None";
    }
}

+ (NSDictionary *)createDictionaryFromAnchor:(std::shared_ptr<VROARAnchor>) anchor {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];

    [dict setObject:[NSString stringWithUTF8String:anchor->getId().c_str()] forKey:@"anchorId"];

    VROMatrix4f transform =  anchor->getTransform();
    VROVector3f position = transform.extractTranslation();
    VROVector3f scale = transform.extractScale();
    VROVector3f rotation = transform.extractRotation(scale).toEuler();

    [dict setObject:@[@(position.x), @(position.y), @(position.z)] forKey:@"position"];
    [dict setObject:@[@(scale.x), @(scale.y), @(scale.z)] forKey:@"scale"];
    [dict setObject:@[@(toDegrees(rotation.x)), @(toDegrees(rotation.y)), @(toDegrees(rotation.z))] forKey:@"rotation"];

    // default type is "anchor", override below.
    [dict setObject:@"anchor" forKey:@"type"];

    std::shared_ptr<VROARPlaneAnchor> planeAnchor = std::dynamic_pointer_cast<VROARPlaneAnchor>(anchor);
    if (planeAnchor) {
        [dict setObject:@"plane" forKey:@"type"];
        [dict setObject:@[@(planeAnchor->getCenter().x), @(planeAnchor->getCenter().y), @(planeAnchor->getCenter().z)] forKey:@"center"];
        [dict setObject:@(planeAnchor->getExtent().x) forKey:@"width"];
        [dict setObject:@(planeAnchor->getExtent().z) forKey:@"height"];
        
        // Set polygon vertices points
        std::vector<VROVector3f> points = planeAnchor->getBoundaryVertices();
        NSMutableArray *pointsArray = [[NSMutableArray alloc] initWithCapacity:points.size()];
        for (VROVector3f point : points) {
            [pointsArray addObject:@[@(point.x), @(point.y), @(point.z)]];
        }
        [dict setObject:pointsArray forKey:@"vertices"];

        switch (planeAnchor->getAlignment()) {
            case VROARPlaneAlignment::Vertical:
                [dict setObject:@"Vertical" forKey:@"alignment"];
                break;
            case VROARPlaneAlignment::Horizontal:
            default:
                [dict setObject:@"Horizontal" forKey:@"alignment"];
                break;
        }

        // Add plane classification (iOS 12+, basic inference on Android)
        VROARPlaneClassification classification = planeAnchor->getClassification();
        NSString *classificationString = [VRTARUtils stringFromPlaneClassification:classification];
        [dict setObject:classificationString forKey:@"classification"];
    }

    return dict;
}

+ (NSDictionary *)createDictionaryFromARPointCloud:(std::shared_ptr<VROARPointCloud>) pointCloud {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];

    std::vector<VROVector4f> points = pointCloud->getPoints();
    NSMutableArray *pointsArray = [[NSMutableArray alloc] initWithCapacity:points.size()];
    
    // note: the 4th value of the VROVector4f is a "confidence" value only meaningful in Android.
    for (VROVector4f point : points) {
        [pointsArray addObject:@[@(point.x), @(point.y), @(point.z), @(point.w)]];
    }

    std::vector<uint64_t> identifiers = pointCloud->getIdentifiers();
    NSMutableArray *identifiersArray = [[NSMutableArray alloc] initWithCapacity:identifiers.size()];

    for (uint64_t identifier : identifiers) {
        [identifiersArray addObject:[NSNumber numberWithUnsignedLongLong:identifier]];
    }

    [dict setObject:pointsArray forKey:@"points"];
    [dict setObject:identifiersArray forKey:@"identifiers"];

    return dict;
}

@end

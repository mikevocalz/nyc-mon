//
//  VRTARSceneNavigator.h
//  ViroReact
//
//  Created by Andy Chu on 6/12/17.
//  Copyright © 2017 Viro Media. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining
//  a copy of this software and associated documentation files (the
//  "Software"), to deal in the Software without restriction, including
//  without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to
//  permit persons to whom the Software is furnished to do so, subject to
//  the following conditions:
//
//  The above copyright notice and this permission notice shall be included
//  in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//  CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridge.h>
#import <React/RCTInvalidating.h>
#import "VRTNode.h"

@class VRTScene;

@interface VRTARSceneNavigator : VRTView<VRORenderDelegate, RCTInvalidating>

@property (nonatomic, assign) NSInteger currentSceneIndex;
@property (nonatomic, readwrite, strong) NSMutableArray<VRTScene *> *currentViews;
@property (readwrite, nonatomic) VRTScene *currentScene;
@property (nonatomic, copy) NSString *worldAlignment;
@property (nonatomic, copy, nullable) RCTDirectEventBlock onExitViro;
@property (nonatomic, assign) BOOL autofocus;
@property (nonatomic, copy) NSString *videoQuality;
@property (nonatomic, assign) NSInteger numberOfTrackedImages;
@property (nonatomic, readwrite) BOOL hdrEnabled;
@property (nonatomic, readwrite) BOOL pbrEnabled;
@property (nonatomic, readwrite) BOOL bloomEnabled;
@property (nonatomic, readwrite) BOOL shadowsEnabled;
@property (nonatomic, readwrite) BOOL multisamplingEnabled;
@property (nonatomic, copy) NSString *occlusionMode;
@property (nonatomic, assign) BOOL depthEnabled;
@property (nonatomic, assign) BOOL depthDebugEnabled;
@property (nonatomic, assign) BOOL semanticDebugEnabled;
@property (nonatomic, assign) float monocularDepthScale;
@property (nonatomic, assign) int monocularDepthTargetFPS;
@property (nonatomic, assign) BOOL frontCameraEnabled;
@property (nonatomic, assign) float semanticConfidenceThreshold;
@property (nonatomic, copy) NSString *cloudAnchorProvider;
@property (nonatomic, copy) NSString *geospatialAnchorProvider;

// World mesh properties
@property (nonatomic, assign) BOOL worldMeshEnabled;
@property (nonatomic, copy, nullable) NSDictionary *worldMeshConfig;
@property (nonatomic, copy, nullable) RCTDirectEventBlock onWorldMeshUpdated;

- (instancetype)initWithBridge:(RCTBridge *)bridge;
- (void)insertReactSubview:(UIView *)subview atIndex:(NSInteger)atIndex;
- (void)removeReactSubview:(UIView *)subview;
- (NSArray *)reactSubviews;
- (UIView *)reactSuperview;
- (UIView *)rootVROView;
- (void)invalidate;
- (void)cleanupViroResources;
- (VROVector3f)unprojectPoint:(VROVector3f)point;
- (VROVector3f)projectPoint:(VROVector3f)point;

- (void)startVideoRecording:(NSString *)fileName
           saveToCameraRoll:(BOOL)saveToCameraRoll
                    onError:(RCTResponseSenderBlock)onError;

- (void)stopVideoRecordingWithHandler:(VROViewWriteMediaFinishBlock)completionHandler;

- (void)takeScreenshot:(NSString *)fileName
      saveToCameraRoll:(BOOL)saveToCameraRoll
     completionHandler:(VROViewWriteMediaFinishBlock)completionHandler;

#pragma mark - Cloud Anchor Methods

// Cloud Anchor completion handler types
typedef void (^CloudAnchorHostCompletionHandler)(BOOL success,
                                                  NSString * _Nullable cloudAnchorId,
                                                  NSString * _Nullable error,
                                                  NSString * _Nonnull state);

typedef void (^CloudAnchorResolveCompletionHandler)(BOOL success,
                                                     NSDictionary * _Nullable anchorData,
                                                     NSString * _Nullable error,
                                                     NSString * _Nonnull state);

- (void)hostCloudAnchor:(NSString *)anchorId
                ttlDays:(NSInteger)ttlDays
      completionHandler:(CloudAnchorHostCompletionHandler)completionHandler;

- (void)resolveCloudAnchor:(NSString *)cloudAnchorId
         completionHandler:(CloudAnchorResolveCompletionHandler)completionHandler;

// Progress of a resolve in flight, or nil when none is. Polled rather than
// pushed: resolve localisation runs per AR frame with no event channel to JS.
- (NSDictionary *)cloudAnchorStatus;

- (void)cancelCloudAnchorOperations;

#pragma mark - AR Session Recording Methods

// Records the AR session (video + IMU + tracked pose) to local storage — see
// ViroWorkspace/plans/viro-ar-recording-playback-plan.md. Not to be confused
// with startVideoRecording/stopVideoRecording, which capture the rendered
// screen only.
typedef void (^RecordingStartCompletionHandler)(BOOL success,
                                                 NSString * _Nullable error);

- (void)startRecording:(NSString *)outputDir
      completionHandler:(RecordingStartCompletionHandler)completionHandler;

- (void)stopRecording;

// One of "None", "Recording", "IOError", "Unsupported" — mirrors
// VROARRecordingStatus (VROARSession.h).
- (NSString *)getRecordingStatus;

#pragma mark - Geospatial API Methods

// Geospatial completion handler types
typedef void (^GeospatialPoseCompletionHandler)(BOOL success,
                                                  NSDictionary * _Nullable poseData,
                                                  NSString * _Nullable error);

typedef void (^VPSAvailabilityCompletionHandler)(NSString * _Nonnull availability);

typedef void (^GeospatialAnchorCompletionHandler)(BOOL success,
                                                    NSDictionary * _Nullable anchorData,
                                                    NSString * _Nullable error);

// Geospatial mode
- (BOOL)isGeospatialModeSupported;
- (BOOL)isLocationAccuracyReduced;
- (void)setGeospatialModeEnabled:(BOOL)enabled;

// Earth tracking state
- (NSString *)getEarthTrackingState;

// Camera geospatial pose
- (void)getCameraGeospatialPose:(GeospatialPoseCompletionHandler)completionHandler;

// VPS availability
- (void)checkVPSAvailability:(double)latitude
                   longitude:(double)longitude
           completionHandler:(VPSAvailabilityCompletionHandler)completionHandler;

// Geospatial anchors
// Note: quaternion accepts both array [x, y, z, w] and dictionary {x, y, z, w}
- (void)createGeospatialAnchor:(double)latitude
                     longitude:(double)longitude
                      altitude:(double)altitude
                    quaternion:(id)quaternion
             completionHandler:(GeospatialAnchorCompletionHandler)completionHandler;

- (void)createTerrainAnchor:(double)latitude
                  longitude:(double)longitude
        altitudeAboveTerrain:(double)altitudeAboveTerrain
                  quaternion:(id)quaternion
           completionHandler:(GeospatialAnchorCompletionHandler)completionHandler;

- (void)createRooftopAnchor:(double)latitude
                  longitude:(double)longitude
       altitudeAboveRooftop:(double)altitudeAboveRooftop
                  quaternion:(id)quaternion
           completionHandler:(GeospatialAnchorCompletionHandler)completionHandler;

- (void)removeGeospatialAnchor:(NSString *)anchorId;

// ReactVision-specific: save GPS anchor to backend (returns platform UUID), no local AR anchor
- (void)hostGeospatialAnchor:(double)latitude
                   longitude:(double)longitude
                    altitude:(double)altitude
               altitudeMode:(NSString *)altitudeMode
           completionHandler:(void (^)(BOOL success, NSString * _Nullable platformUuid, NSString * _Nullable error))completionHandler;

// ReactVision-specific: fetch GPS coords from backend by UUID + create local AR anchor
- (void)resolveGeospatialAnchor:(NSString *)platformUuid
                      quaternion:(id)quaternion
              completionHandler:(GeospatialAnchorCompletionHandler)completionHandler;

// ReactVision Geospatial CRUD
- (void)rvGetGeospatialAnchor:(NSString *)anchorId
            completionHandler:(void (^)(BOOL success, NSDictionary *anchorData, NSString *error))completionHandler;
- (void)rvFindNearbyGeospatialAnchors:(double)latitude
                            longitude:(double)longitude
                               radius:(double)radius
                                limit:(int)limit
                    completionHandler:(void (^)(BOOL success, NSArray *anchors, NSString *error))completionHandler;
- (void)rvUpdateGeospatialAnchor:(NSString *)anchorId
                    sceneAssetId:(NSString *)sceneAssetId
                         sceneId:(NSString *)sceneId
                            name:(NSString *)name
                     userAssetId:(NSString *)userAssetId
               completionHandler:(void (^)(BOOL success, NSDictionary *anchorData, NSString *error))completionHandler;
- (void)rvUploadAsset:(NSString *)filePath
            assetType:(NSString *)assetType
             fileName:(NSString *)fileName
           appUserId:(NSString *)appUserId
    completionHandler:(void (^)(BOOL success, NSString *userAssetId, NSString *fileUrl, NSString *error))completionHandler;
// WS-C: serialize the current world mesh to a temp file — pass the returned
// path straight into rvUploadAsset(). locationTransformCsv is the value
// finishScan()'s success callback returned (16 comma-separated floats);
// there is no placed anchor for a finishScan()-hosted mesh to read a
// transform from otherwise. Returns nil if there is no current mesh.
- (NSString *)rvSnapshotWorldMeshToFile:(NSString *)locationTransformCsv;
/** Same, but says which precondition failed instead of answering nil for all six. */
- (NSString *)rvSnapshotWorldMeshToFile:(NSString *)locationTransformCsv
                                  error:(NSString **)outError;
// WS-C: load a mesh snapshot (downloaded to filePath by the app from the
// resolved anchor's asset fileUrl) and attach it for both physics collision
// and visual occlusion. resolvedTransformCsv is the resolved anchor's
// transform (16 comma-separated floats). Requires worldMeshEnabled to be
// true. Returns NO if there is no AR scene, no world mesh, or the file is
// malformed.
- (BOOL)rvLoadWorldMeshFromFile:(NSString *)filePath
              resolvedTransform:(NSString *)resolvedTransformCsv;
- (void)rvDeleteGeospatialAnchor:(NSString *)anchorId
               completionHandler:(void (^)(BOOL success, NSString *error))completionHandler;
- (void)rvListGeospatialAnchors:(int)limit
                         offset:(int)offset
              completionHandler:(void (^)(BOOL success, NSArray *anchors, NSString *error))completionHandler;

// Cloud anchor management
- (void)rvStartScan;
/** Scan status as the renderer's JSON; `{"available":false}` when there is no session. */
// Whether a world mesh exists and how big it is. Polled, because the `onWorldMeshUpdated`
// event prop never fires: VROARScene calls its delegate, but neither VROARSceneDelegateiOS nor
// VRTARScene forwards that call, so the chain to JS was never finished.
- (NSDictionary *)rvGetWorldMeshStats;

- (NSString *)rvGetScanStatusJson;
/** Last scan-based host's measurements as the renderer's JSON. */
- (NSString *)rvGetScanDiagnosticsJson;

- (void)rvFinishScan:(NSInteger)ttlDays
   completionHandler:(void (^)(BOOL success, NSString *cloudAnchorId,
                               NSString *locationTransformCsv, NSString *error))completionHandler;
- (void)rvGetCloudAnchor:(NSString *)anchorId
       completionHandler:(void (^)(BOOL success, NSDictionary *anchorData, NSString *error))completionHandler;
- (void)rvListCloudAnchors:(int)limit
                    offset:(int)offset
         completionHandler:(void (^)(BOOL success, NSArray *anchors, NSString *error))completionHandler;
- (void)rvUpdateCloudAnchor:(NSString *)anchorId
                       name:(NSString *)name
                description:(NSString *)description
                   isPublic:(BOOL)isPublic
          completionHandler:(void (^)(BOOL success, NSDictionary *anchorData, NSString *error))completionHandler;
- (void)rvDeleteCloudAnchor:(NSString *)anchorId
          completionHandler:(void (^)(BOOL success, NSString *error))completionHandler;
- (void)rvFindNearbyCloudAnchors:(double)latitude
                       longitude:(double)longitude
                          radius:(double)radius
                           limit:(int)limit
               completionHandler:(void (^)(BOOL success, NSArray *anchors, NSString *error))completionHandler;
- (void)rvGetProject:(void (^)(BOOL success, NSString *data, NSString *error))completionHandler;
- (void)rvGetScene:(NSString *)sceneId
 completionHandler:(void (^)(BOOL success, NSString *data, NSString *error))completionHandler;
- (void)rvGetSceneAssets:(NSString *)sceneId
      completionHandler:(void (^)(BOOL success, NSArray *assets, NSString *error))completionHandler;
- (void)rvAttachAssetToCloudAnchor:(NSString *)anchorId
                           fileUrl:(NSString *)fileUrl
                          fileSize:(int64_t)fileSize
                              name:(NSString *)name
                         assetType:(NSString *)assetType
                    externalUserId:(NSString *)externalUserId
                 completionHandler:(void (^)(BOOL success, NSString *error))completionHandler;
- (void)rvRemoveAssetFromCloudAnchor:(NSString *)anchorId
                             assetId:(NSString *)assetId
                   completionHandler:(void (^)(BOOL success, NSString *error))completionHandler;
- (void)rvTrackCloudAnchorResolution:(NSString *)anchorId
                             success:(BOOL)success
                          confidence:(double)confidence
                          matchCount:(int)matchCount
                         inlierCount:(int)inlierCount
                    processingTimeMs:(int)processingTimeMs
                            platform:(NSString *)platform
                      externalUserId:(NSString *)externalUserId
                   completionHandler:(void (^)(BOOL success, NSString *error))completionHandler;

#pragma mark - Scene Semantics API Methods

// Check if Scene Semantics mode is supported on this device
- (BOOL)isSemanticModeSupported;

// Enable or disable Scene Semantics mode
- (void)setSemanticModeEnabled:(BOOL)enabled;

// Get the fraction of pixels for each semantic label
// Returns a dictionary with label names (sky, building, etc.) as keys
- (NSDictionary *)getSemanticLabelFractions;

// Get the fraction of pixels for a specific semantic label
// @param label The semantic label name (e.g., "sky", "building", "road")
// @return The fraction of pixels (0.0-1.0)
- (float)getSemanticLabelFraction:(NSString *)label;

#pragma mark - Monocular Depth Estimation API Methods

// When enabled, monocular depth will be used even on devices with LiDAR
// This allows consistency across device types, testing, or depth beyond LiDAR's ~5m range
- (void)setPreferMonocularDepth:(BOOL)prefer;

// Check if monocular depth is preferred over LiDAR
- (BOOL)isPreferMonocularDepth;

@end

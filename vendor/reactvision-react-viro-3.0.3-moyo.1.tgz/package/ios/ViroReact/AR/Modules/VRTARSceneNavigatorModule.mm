//
//  VRTARSceneNavigatorModule.m
//  ViroReact
//
//  Created by Andy Chu on 7/25/17.
//  Copyright © 2017 Viro Media. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining
//  a copy of this software and associated documentation files (the
//  "Software"), to deal in the Software without restriction, including
//  without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to
//  permit persons to whom the Software is furnished to do so, subject to
//  the following conditions:
//
//  The above copyright notice and this permission notice shall be included
//  in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//  CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import <React/RCTUIManager.h>
#import "VRTARSceneNavigatorModule.h"
#import "VRTARSceneNavigator.h"
#import <React/RCTUIManagerUtils.h>
#import <React/RCTLog.h>
#import <React/RCTUtils.h>
#import "VRTUtils.h"
#import <CoreLocation/CoreLocation.h>

@implementation VRTARSceneNavigatorModule
@synthesize bridge = _bridge;
// Views are looked up through RCTViewRegistry, not the NSDictionary the legacy
// RCTUIManager block hands out: under the new architecture that dictionary
// never contains interop-mounted views, so every method here answered
// "Invalid view type", and the legacy block queue itself only drains when
// something else flushes it (observed 10 to 40 s late in bridgeless mode).
// The registry returns the interop wrapper, hence the paper-view unwrap.
@synthesize viewRegistry_DEPRECATED = _viewRegistry_DEPRECATED;

static const int kRVViewLookupMaxFrames = 60;

// Fabric mounts on the main queue after the JS commit that triggered a call, so
// a method invoked from componentDidMount can run before its navigator view
// exists. Wait up to about a second of frames for the tag to resolve; each
// method's own class check still decides after that, and a miss is logged with
// what the tag actually resolved to.
- (void)rv_withViewForTag:(NSNumber *)reactTag block:(RCTViewRegistryUIBlock)block {
    [self rv_withViewForTag:reactTag attempt:0 block:block];
}

- (void)rv_withViewForTag:(NSNumber *)reactTag attempt:(int)attempt block:(RCTViewRegistryUIBlock)block {
    RCTViewRegistry *registry = self.viewRegistry_DEPRECATED;
    if (registry == nil) {
        RCTLogWarn(@"[ViroAR] viewRegistry_DEPRECATED is nil, view lookup for tag %@ cannot run", reactTag);
        RCTExecuteOnMainQueue(^{ block(nil); });
        return;
    }
    __weak __typeof(self) weakSelf = self;
    [registry addUIBlock:^(RCTViewRegistry *viewRegistry) {
        UIView *found = [viewRegistry viewForReactTag:reactTag];
        if (found == nil && attempt < kRVViewLookupMaxFrames) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(16 * NSEC_PER_MSEC)),
                           dispatch_get_main_queue(), ^{
                [weakSelf rv_withViewForTag:reactTag attempt:attempt + 1 block:block];
            });
            return;
        }
        UIView *view = RCTPaperViewOrCurrentView(found);
        if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
            RCTLogWarn(@"[ViroAR] tag %@ resolved to %@ (unwrapped %@) after %d frames, expected VRTARSceneNavigator",
                       reactTag,
                       found ? NSStringFromClass([found class]) : @"nil",
                       view ? NSStringFromClass([view class]) : @"nil",
                       attempt);
        }
        block(viewRegistry);
    }];
}

static NSString *const kVRTRecordingKeySuccess = @"success";
static NSString *const kVRTRecordingKeyUrl = @"url";
static NSString *const kVRTRecordingKeyErrorCode = @"errorCode";

RCT_EXPORT_MODULE()

- (dispatch_queue_t)methodQueue {
    return RCTGetUIManagerQueue();
}

RCT_EXPORT_METHOD(startVideoRecording:(nonnull NSNumber *)reactTag
                             fileName:(NSString *)fileName
                     saveToCameraRoll:(BOOL)saveToCameraRoll
                              callback:(RCTResponseSenderBlock)callback) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                RCTLogError(@"Invalid view returned from registry, expecting VRTARSceneNavigator, got: %@", view);
                callback(@[@(1)]); // Error code 1: Invalid view
                return;
            }
            
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            
            // Check if component is still valid
            if (!component.rootVROView) {
                RCTLogWarn(@"Cannot start video recording: AR view has been unmounted");
                callback(@[@(2)]); // Error code 2: View unmounted
                return;
            }
            
            [component startVideoRecording:fileName saveToCameraRoll:saveToCameraRoll onError:callback];
        } @catch (NSException *exception) {
            RCTLogError(@"Error starting video recording: %@", exception.reason);
            callback(@[@(3)]); // Error code 3: Exception
        }
    }];
}

RCT_EXPORT_METHOD(stopVideoRecording:(nonnull NSNumber *)reactTag
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                reject(@"invalid_view", @"Invalid view returned from registry, expecting VRTARSceneNavigator", nil);
                return;
            }
            
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            
            // Check if component is still valid
            if (!component.rootVROView) {
                NSMutableDictionary *toReturn = [NSMutableDictionary new];
                [toReturn setObject:@(NO) forKey:kVRTRecordingKeySuccess];
                [toReturn setObject:@(2) forKey:kVRTRecordingKeyErrorCode]; // Error code 2: View unmounted
                resolve(toReturn);
                return;
            }
            
            [component stopVideoRecordingWithHandler:^(BOOL success, NSURL *url, NSURL *gifPath, NSInteger errorCode) {
                NSMutableDictionary *toReturn = [NSMutableDictionary new];
                [toReturn setObject:@(success) forKey:kVRTRecordingKeySuccess];
                if (url) [toReturn setObject:[url path] forKey:kVRTRecordingKeyUrl];
                [toReturn setObject:@(errorCode) forKey:kVRTRecordingKeyErrorCode];
                resolve(toReturn);
            }];
        } @catch (NSException *exception) {
            reject(@"recording_error", [NSString stringWithFormat:@"Error stopping video recording: %@", exception.reason], nil);
        }
    }];
}

RCT_EXPORT_METHOD(takeScreenshot:(nonnull NSNumber *)reactTag
                        fileName:(NSString *)fileName
                saveToCameraRoll:(BOOL)saveToCameraRoll
                         resolve:(RCTPromiseResolveBlock)resolve
                          reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                reject(@"invalid_view", @"Invalid view returned from registry, expecting VRTARSceneNavigator", nil);
                return;
            }
            
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            
            // Check if component is still valid
            if (!component.rootVROView) {
                NSMutableDictionary *toReturn = [NSMutableDictionary new];
                [toReturn setObject:@(NO) forKey:kVRTRecordingKeySuccess];
                [toReturn setObject:@(2) forKey:kVRTRecordingKeyErrorCode]; // Error code 2: View unmounted
                resolve(toReturn);
                return;
            }
            
            [component takeScreenshot:fileName
                     saveToCameraRoll:saveToCameraRoll
                    completionHandler:^(BOOL success, NSURL *url, NSURL *gifPath, NSInteger errorCode) {
                NSMutableDictionary *toReturn = [NSMutableDictionary new];
                [toReturn setObject:@(success) forKey:kVRTRecordingKeySuccess];
                if (url) [toReturn setObject:[url path] forKey:kVRTRecordingKeyUrl];
                [toReturn setObject:@(errorCode) forKey:kVRTRecordingKeyErrorCode];
                resolve(toReturn);
            }];
        } @catch (NSException *exception) {
            reject(@"screenshot_error", [NSString stringWithFormat:@"Error taking screenshot: %@", exception.reason], nil);
        }
    }];
}

RCT_EXPORT_METHOD(resetARSession:(nonnull NSNumber *)reactTag
                  resetTracking:(BOOL)resetTracking
                  removeAnchors:(BOOL)removeAnchors) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
            RCTLogError(@"Invalid view returned from registry, expecting VRTARSceneNavigator, got: %@", view);
        } else {
            @try {
                VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
                VROViewAR *arView = (VROViewAR *)[component rootVROView];
                
                // Check if view and AR session are still valid
                if (!arView) {
                    RCTLogWarn(@"Cannot reset AR session: AR view is nil");
                    return;
                }
                
                std::shared_ptr<VROARSession> arSession = arView.getARSession;
                if (!arSession) {
                    RCTLogWarn(@"Cannot reset AR session: AR session is nil");
                    return;
                }
                
                // Reset the session safely
                arSession->resetSession(resetTracking, removeAnchors);
            } @catch (NSException *exception) {
                RCTLogError(@"Error resetting AR session: %@", exception.reason);
            }
        }
    }];
}

RCT_EXPORT_METHOD(setWorldOrigin:(nonnull NSNumber *)reactTag
                     worldOrigin:(NSDictionary *)worldOrigin) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
            RCTLogError(@"Invalid view returned from registry, expecting VRTARSceneNavigator, got: %@", view);
        } else {
            @try {
                VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
                VROViewAR *arView = (VROViewAR *)[component rootVROView];
                
                // Check if view is still valid
                if (!arView) {
                    RCTLogWarn(@"Cannot set world origin: AR view is nil");
                    return;
                }
                
                std::shared_ptr<VROARSession> session = [arView getARSession];
                if (!session) {
                    RCTLogWarn(@"Cannot set world origin: AR session is nil");
                    return;
                }
                
                NSArray *posArray = [worldOrigin objectForKey:@"position"];
                NSArray *rotArray = [worldOrigin objectForKey:@"rotation"];
                
                VROMatrix4f originMatrix;
                if (posArray) {
                    if ([posArray count] == 3) {
                        float positionValues[3];
                        populateFloatArrayFromNSArray(posArray, positionValues, 3);
                        originMatrix.translate({positionValues[0], positionValues[1], positionValues[2]});
                    } else {
                        RCTLogError(@"[Viro] worldOrigin position requires 3 values");
                    }
                }
                
                if (rotArray) {
                    if ([rotArray count] == 3) {
                        float rotationValues[3];
                        populateFloatArrayFromNSArray(rotArray, rotationValues, 3);
                        originMatrix.rotateX(toRadians(rotationValues[0]));
                        originMatrix.rotateY(toRadians(rotationValues[1]));
                        originMatrix.rotateZ(toRadians(rotationValues[2]));
                    } else {
                        RCTLogError(@"[Viro] worldOrigin rotation requires 3 values");
                    }
                }
                
                session->setWorldOrigin(originMatrix);
            } @catch (NSException *exception) {
                RCTLogError(@"Error setting world origin: %@", exception.reason);
            }
        }
    }];
}


//take 3d position and convert to 2d screen position.
RCT_EXPORT_METHOD(project:(nonnull NSNumber *)reactTag
                  position:(NSArray<NSNumber *> *)position
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            // Validate input parameters
            if (!position || position.count != 3) {
                reject(@"invalid_position", @"Position must be an array of 3 numbers", nil);
                return;
            }
            
            VROVector3f pos = VROVector3f([[position objectAtIndex:0] floatValue],
                                          [[position objectAtIndex:1] floatValue],
                                          [[position objectAtIndex:2] floatValue]);
            
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                reject(@"invalid_view", @"Invalid view returned from registry, expecting VRTARSceneNavigator", nil);
                return;
            }
            
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            
            // Check if component is still valid
            if (!component.rootVROView) {
                reject(@"invalid_state", @"AR view has been unmounted", nil);
                return;
            }
            
            VROVector3f projectedPoint = [component projectPoint:pos];
            resolve(@{
                @"screenPosition" : @[@(projectedPoint.x), @(projectedPoint.y)]
            });
        } @catch (NSException *exception) {
            reject(@"projection_error", [NSString stringWithFormat:@"Error projecting point: %@", exception.reason], nil);
        }
    }];
}

// take 2d screen position and project into 3d
RCT_EXPORT_METHOD(unproject:(nonnull NSNumber *)reactTag
                  position:(NSArray<NSNumber *> *)position
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            // Validate input parameters
            if (!position || position.count != 3) {
                reject(@"invalid_position", @"Position must be an array of 3 numbers", nil);
                return;
            }

            VROVector3f pos = VROVector3f([[position objectAtIndex:0] floatValue],
                                          [[position objectAtIndex:1] floatValue],
                                          [[position objectAtIndex:2] floatValue]);

            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                reject(@"invalid_view", @"Invalid view returned from registry, expecting VRTARSceneNavigator", nil);
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            // Check if component is still valid
            if (!component.rootVROView) {
                reject(@"invalid_state", @"AR view has been unmounted", nil);
                return;
            }

            VROVector3f unprojectedPoint = [component unprojectPoint:pos];
            resolve(@{
                @"position" : @[@(unprojectedPoint.x), @(unprojectedPoint.y), @(unprojectedPoint.z)]
            });
        } @catch (NSException *exception) {
            reject(@"unprojection_error", [NSString stringWithFormat:@"Error unprojecting point: %@", exception.reason], nil);
        }
    }];
}

#pragma mark - Cloud Anchor Methods

RCT_EXPORT_METHOD(hostCloudAnchor:(nonnull NSNumber *)reactTag
                         anchorId:(NSString *)anchorId
                          ttlDays:(NSInteger)ttlDays
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                NSDictionary *result = @{
                    @"success": @NO,
                    @"error": @"Invalid view type",
                    @"state": @"ErrorInternal"
                };
                resolve(result);
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            if (!component.rootVROView) {
                NSDictionary *result = @{
                    @"success": @NO,
                    @"error": @"AR view has been unmounted",
                    @"state": @"ErrorInternal"
                };
                resolve(result);
                return;
            }

            [component hostCloudAnchor:anchorId
                               ttlDays:ttlDays
                     completionHandler:^(BOOL success,
                                        NSString *cloudAnchorId,
                                        NSString *error,
                                        NSString *state) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                [result setObject:state forKey:@"state"];
                if (cloudAnchorId) {
                    [result setObject:cloudAnchorId forKey:@"cloudAnchorId"];
                }
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            NSDictionary *result = @{
                @"success": @NO,
                @"error": [NSString stringWithFormat:@"Exception: %@", exception.reason],
                @"state": @"ErrorInternal"
            };
            resolve(result);
        }
    }];
}

#pragma mark - AR Session Recording Methods

RCT_EXPORT_METHOD(startRecording:(nonnull NSNumber *)reactTag
                        outputDir:(NSString *)outputDir
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                NSDictionary *result = @{ @"success": @NO, @"error": @"Invalid view type" };
                resolve(result);
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            if (!component.rootVROView) {
                NSDictionary *result = @{ @"success": @NO, @"error": @"AR view has been unmounted" };
                resolve(result);
                return;
            }

            [component startRecording:outputDir
                     completionHandler:^(BOOL success, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            NSDictionary *result = @{
                @"success": @NO,
                @"error": [NSString stringWithFormat:@"Exception: %@", exception.reason]
            };
            resolve(result);
        }
    }];
}

RCT_EXPORT_METHOD(stopRecording:(nonnull NSNumber *)reactTag
                         resolve:(RCTPromiseResolveBlock)resolve
                          reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            [(VRTARSceneNavigator *)view stopRecording];
        }
        resolve(nil);
    }];
}

RCT_EXPORT_METHOD(getRecordingStatus:(nonnull NSNumber *)reactTag
                              resolve:(RCTPromiseResolveBlock)resolve
                               reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            resolve([(VRTARSceneNavigator *)view getRecordingStatus]);
        } else {
            resolve(@"Unsupported");
        }
    }];
}

static NSDictionary *VRTEmptyCloudAnchorStatus(void) {
    return @{ @"active": @NO, @"progress": @0, @"message": @"" };
}

RCT_EXPORT_METHOD(getCloudAnchorStatus:(nonnull NSNumber *)reactTag
                               resolve:(RCTPromiseResolveBlock)resolve
                                reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
            resolve(VRTEmptyCloudAnchorStatus());
            return;
        }

        NSDictionary *status = [(VRTARSceneNavigator *)view cloudAnchorStatus];
        if (!status) {
            resolve(VRTEmptyCloudAnchorStatus());
            return;
        }
        resolve(@{
            @"active": @YES,
            @"progress": status[@"progress"] ?: @0,
            @"message": status[@"message"] ?: @""
        });
    }];
}

RCT_EXPORT_METHOD(resolveCloudAnchor:(nonnull NSNumber *)reactTag
                       cloudAnchorId:(NSString *)cloudAnchorId
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                NSDictionary *result = @{
                    @"success": @NO,
                    @"error": @"Invalid view type",
                    @"state": @"ErrorInternal"
                };
                resolve(result);
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            if (!component.rootVROView) {
                NSDictionary *result = @{
                    @"success": @NO,
                    @"error": @"AR view has been unmounted",
                    @"state": @"ErrorInternal"
                };
                resolve(result);
                return;
            }

            [component resolveCloudAnchor:cloudAnchorId
                        completionHandler:^(BOOL success,
                                           NSDictionary *anchorData,
                                           NSString *error,
                                           NSString *state) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                [result setObject:state forKey:@"state"];
                if (anchorData) {
                    [result setObject:anchorData forKey:@"anchor"];
                }
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            NSDictionary *result = @{
                @"success": @NO,
                @"error": [NSString stringWithFormat:@"Exception: %@", exception.reason],
                @"state": @"ErrorInternal"
            };
            resolve(result);
        }
    }];
}

RCT_EXPORT_METHOD(cancelCloudAnchorOperations:(nonnull NSNumber *)reactTag) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component cancelCloudAnchorOperations];
        }
    }];
}

#pragma mark - Geospatial API Methods

RCT_EXPORT_METHOD(isGeospatialModeSupported:(nonnull NSNumber *)reactTag
                                    resolve:(RCTPromiseResolveBlock)resolve
                                     reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"supported": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            BOOL supported = [component isGeospatialModeSupported];
            resolve(@{@"supported": @(supported)});
        } @catch (NSException *exception) {
            resolve(@{@"supported": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(isLocationAccuracyReduced:(nonnull NSNumber *)reactTag
                                     resolve:(RCTPromiseResolveBlock)resolve
                                      reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"reduced": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            BOOL reduced = [component isLocationAccuracyReduced];
            resolve(@{@"reduced": @(reduced)});
        } @catch (NSException *exception) {
            resolve(@{@"reduced": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(setGeospatialModeEnabled:(nonnull NSNumber *)reactTag
                                   enabled:(BOOL)enabled) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component setGeospatialModeEnabled:enabled];
        }
    }];
}

RCT_EXPORT_METHOD(getEarthTrackingState:(nonnull NSNumber *)reactTag
                                resolve:(RCTPromiseResolveBlock)resolve
                                 reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"state": @"Stopped", @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            NSString *state = [component getEarthTrackingState];
            resolve(@{@"state": state});
        } @catch (NSException *exception) {
            resolve(@{@"state": @"Stopped", @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(getCameraGeospatialPose:(nonnull NSNumber *)reactTag
                                  resolve:(RCTPromiseResolveBlock)resolve
                                   reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            if (!component.rootVROView) {
                resolve(@{@"success": @NO, @"error": @"AR view has been unmounted"});
                return;
            }

            [component getCameraGeospatialPose:^(BOOL success, NSDictionary *poseData, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (poseData) {
                    [result setObject:poseData forKey:@"pose"];
                }
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(checkVPSAvailability:(nonnull NSNumber *)reactTag
                              latitude:(double)latitude
                             longitude:(double)longitude
                               resolve:(RCTPromiseResolveBlock)resolve
                                reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"availability": @"Unknown", @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            [component checkVPSAvailability:latitude
                                  longitude:longitude
                          completionHandler:^(NSString *availability) {
                resolve(@{@"availability": availability});
            }];
        } @catch (NSException *exception) {
            resolve(@{@"availability": @"Unknown", @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(createGeospatialAnchor:(nonnull NSNumber *)reactTag
                                latitude:(double)latitude
                               longitude:(double)longitude
                                altitude:(double)altitude
                              quaternion:(NSArray *)quaternion
                                 resolve:(RCTPromiseResolveBlock)resolve
                                  reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            if (!component.rootVROView) {
                resolve(@{@"success": @NO, @"error": @"AR view has been unmounted"});
                return;
            }

            [component createGeospatialAnchor:latitude
                                    longitude:longitude
                                     altitude:altitude
                                   quaternion:quaternion
                            completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (anchorData) {
                    [result setObject:anchorData forKey:@"anchor"];
                }
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(createTerrainAnchor:(nonnull NSNumber *)reactTag
                             latitude:(double)latitude
                            longitude:(double)longitude
                  altitudeAboveTerrain:(double)altitudeAboveTerrain
                           quaternion:(NSArray *)quaternion
                              resolve:(RCTPromiseResolveBlock)resolve
                               reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            if (!component.rootVROView) {
                resolve(@{@"success": @NO, @"error": @"AR view has been unmounted"});
                return;
            }

            [component createTerrainAnchor:latitude
                                 longitude:longitude
                       altitudeAboveTerrain:altitudeAboveTerrain
                                 quaternion:quaternion
                          completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (anchorData) {
                    [result setObject:anchorData forKey:@"anchor"];
                }
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(createRooftopAnchor:(nonnull NSNumber *)reactTag
                             latitude:(double)latitude
                            longitude:(double)longitude
                 altitudeAboveRooftop:(double)altitudeAboveRooftop
                           quaternion:(NSArray *)quaternion
                              resolve:(RCTPromiseResolveBlock)resolve
                               reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

            if (!component.rootVROView) {
                resolve(@{@"success": @NO, @"error": @"AR view has been unmounted"});
                return;
            }

            [component createRooftopAnchor:latitude
                                 longitude:longitude
                      altitudeAboveRooftop:altitudeAboveRooftop
                                 quaternion:quaternion
                          completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (anchorData) {
                    [result setObject:anchorData forKey:@"anchor"];
                }
                if (error) {
                    [result setObject:error forKey:@"error"];
                }
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(hostGeospatialAnchor:(nonnull NSNumber *)reactTag
                            latitude:(double)latitude
                           longitude:(double)longitude
                            altitude:(double)altitude
                        altitudeMode:(NSString *)altitudeMode
                            resolver:(RCTPromiseResolveBlock)resolve
                            rejecter:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTARSceneNavigator *component = (VRTARSceneNavigator *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if (!component || ![component isKindOfClass:[VRTARSceneNavigator class]]) {
            resolve(@{@"success": @NO, @"error": @"Invalid component"});
            return;
        }
        [component hostGeospatialAnchor:latitude
                              longitude:longitude
                               altitude:altitude
                           altitudeMode:altitudeMode
                      completionHandler:^(BOOL success, NSString *platformUuid, NSString *error) {
            if (success) {
                resolve(@{@"success": @YES, @"anchorId": platformUuid});
            } else {
                resolve(@{@"success": @NO, @"error": error ?: @"Unknown error"});
            }
        }];
    }];
}

RCT_EXPORT_METHOD(resolveGeospatialAnchor:(nonnull NSNumber *)reactTag
                          platformUuid:(NSString *)platformUuid
                             quaternion:(id)quaternion
                               resolver:(RCTPromiseResolveBlock)resolve
                               rejecter:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTARSceneNavigator *component = (VRTARSceneNavigator *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if (!component || ![component isKindOfClass:[VRTARSceneNavigator class]]) {
            resolve(@{@"success": @NO, @"error": @"Invalid component"});
            return;
        }
        [component resolveGeospatialAnchor:platformUuid
                                 quaternion:quaternion
                         completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
            if (success) {
                resolve(@{@"success": @YES, @"anchor": anchorData});
            } else {
                resolve(@{@"success": @NO, @"error": error ?: @"Unknown error"});
            }
        }];
    }];
}

RCT_EXPORT_METHOD(removeGeospatialAnchor:(nonnull NSNumber *)reactTag
                                anchorId:(NSString *)anchorId) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component removeGeospatialAnchor:anchorId];
        }
    }];
}

RCT_EXPORT_METHOD(rvGetGeospatialAnchor:(nonnull NSNumber *)reactTag
                               anchorId:(NSString *)anchorId
                                resolve:(RCTPromiseResolveBlock)resolve
                                 reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component rvGetGeospatialAnchor:anchorId
                           completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (anchorData) [result setObject:anchorData forKey:@"anchor"];
                if (error)      [result setObject:error      forKey:@"error"];
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(rvFindNearbyGeospatialAnchors:(nonnull NSNumber *)reactTag
                                       latitude:(double)latitude
                                      longitude:(double)longitude
                                         radius:(double)radius
                                          limit:(int)limit
                                        resolve:(RCTPromiseResolveBlock)resolve
                                         reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component rvFindNearbyGeospatialAnchors:latitude
                                           longitude:longitude
                                              radius:radius
                                               limit:limit
                                   completionHandler:^(BOOL success, NSArray *anchors, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                [result setObject:anchors ?: @[] forKey:@"anchors"];
                if (error) [result setObject:error forKey:@"error"];
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"anchors": @[], @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(rvUpdateGeospatialAnchor:(nonnull NSNumber *)reactTag
                                  anchorId:(NSString *)anchorId
                              sceneAssetId:(NSString *)sceneAssetId
                                   sceneId:(NSString *)sceneId
                                      name:(NSString *)name
                               userAssetId:(NSString *)userAssetId
                                   resolve:(RCTPromiseResolveBlock)resolve
                                    reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component rvUpdateGeospatialAnchor:anchorId
                                   sceneAssetId:sceneAssetId
                                        sceneId:sceneId
                                           name:name
                                    userAssetId:userAssetId
                              completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (anchorData) [result setObject:anchorData forKey:@"anchor"];
                if (error)      [result setObject:error      forKey:@"error"];
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(rvUploadAsset:(nonnull NSNumber *)reactTag
                       filePath:(NSString *)filePath
                      assetType:(NSString *)assetType
                       fileName:(NSString *)fileName
                      appUserId:(NSString *)appUserId
                        resolve:(RCTPromiseResolveBlock)resolve
                         reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvUploadAsset:filePath assetType:assetType
                fileName:fileName appUserId:appUserId
                completionHandler:^(BOOL success, NSString *userAssetId, NSString *fileUrl, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (userAssetId) [result setObject:userAssetId forKey:@"userAssetId"];
                if (fileUrl)     [result setObject:fileUrl     forKey:@"fileUrl"];
                if (error)       [result setObject:error       forKey:@"error"];
                resolve(result);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvSnapshotWorldMeshToFile:(nonnull NSNumber *)reactTag
                        locationTransform:(NSString *)locationTransformCsv
                                     resolve:(RCTPromiseResolveBlock)resolve
                                      reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            NSString *reason = nil;
            NSString *filePath = [(VRTARSceneNavigator *)view rvSnapshotWorldMeshToFile:locationTransformCsv
                                                                                  error:&reason];
            if (filePath) {
                resolve(@{@"success": @YES, @"filePath": filePath});
            } else {
                resolve(@{@"success": @NO,
                          @"error": reason ?: @"No world mesh available to snapshot"});
            }
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvLoadWorldMeshFromFile:(nonnull NSNumber *)reactTag
                                  filePath:(NSString *)filePath
                        resolvedTransform:(NSString *)resolvedTransformCsv
                                   resolve:(RCTPromiseResolveBlock)resolve
                                    reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            BOOL success = [(VRTARSceneNavigator *)view rvLoadWorldMeshFromFile:filePath
                                                              resolvedTransform:resolvedTransformCsv];
            if (success) {
                resolve(@{@"success": @YES});
            } else {
                resolve(@{@"success": @NO, @"error": @"Failed to load world mesh (no scene, no world mesh enabled, or malformed file)"});
            }
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvDeleteGeospatialAnchor:(nonnull NSNumber *)reactTag
                                  anchorId:(NSString *)anchorId
                                   resolve:(RCTPromiseResolveBlock)resolve
                                    reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component rvDeleteGeospatialAnchor:anchorId
                              completionHandler:^(BOOL success, NSString *error) {
                NSMutableDictionary *result = [NSMutableDictionary new];
                [result setObject:@(success) forKey:@"success"];
                if (error) [result setObject:error forKey:@"error"];
                resolve(result);
            }];
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(rvListGeospatialAnchors:(nonnull NSNumber *)reactTag
                                    limit:(NSInteger)limit
                                   offset:(NSInteger)offset
                                  resolve:(RCTPromiseResolveBlock)resolve
                                   reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvListGeospatialAnchors:(int)limit offset:(int)offset
                completionHandler:^(BOOL success, NSArray *anchors, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                [r setObject:success ? anchors : @[] forKey:@"anchors"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

// ── Cloud anchor management ───────────────────────────────────────────────────

RCT_EXPORT_METHOD(rvStartScan:(nonnull NSNumber *)reactTag) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) return;
            [(VRTARSceneNavigator *)view rvStartScan];
        } @catch (NSException *ex) { /* no-op — startScan has no promise to reject */ }
    }];
}

RCT_EXPORT_METHOD(rvFinishScan:(nonnull NSNumber *)reactTag
                        ttlDays:(NSInteger)ttlDays
                        resolve:(RCTPromiseResolveBlock)resolve
                         reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvFinishScan:ttlDays
                completionHandler:^(BOOL success, NSString *cloudAnchorId,
                                    NSString *locationTransformCsv, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (cloudAnchorId)         [r setObject:cloudAnchorId         forKey:@"cloudAnchorId"];
                if (locationTransformCsv)  [r setObject:locationTransformCsv  forKey:@"locationTransform"];
                if (error)                 [r setObject:error                forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

// How the scan in progress is doing, and why the last one ended as it did.
//
// Both resolve the renderer's own JSON string, parsed on the JS side. The shape is defined once,
// in VROARSession, instead of being restated in each bridge and drifting between them.
RCT_EXPORT_METHOD(rvGetWorldMeshStats:(nonnull NSNumber *)reactTag
                              resolve:(RCTPromiseResolveBlock)resolve
                               reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"available": @NO, @"reason": @"AR navigator is not mounted yet"}); return;
            }
            resolve([(VRTARSceneNavigator *)view rvGetWorldMeshStats]);
        } @catch (NSException *ex) {
            resolve(@{@"available": @NO, @"reason": ex.reason ?: @"unknown error"});
        }
    }];
}

RCT_EXPORT_METHOD(rvGetScanStatus:(nonnull NSNumber *)reactTag
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@"{\"available\":false,\"error\":\"AR navigator is not mounted yet\"}"); return;
            }
            resolve([(VRTARSceneNavigator *)view rvGetScanStatusJson]);
        } @catch (NSException *ex) {
            resolve([NSString stringWithFormat:@"{\"available\":false,\"error\":\"%@\"}", ex.reason]);
        }
    }];
}

RCT_EXPORT_METHOD(rvGetScanDiagnostics:(nonnull NSNumber *)reactTag
                               resolve:(RCTPromiseResolveBlock)resolve
                                reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@"{\"valid\":false}"); return;
            }
            resolve([(VRTARSceneNavigator *)view rvGetScanDiagnosticsJson]);
        } @catch (NSException *ex) {
            resolve(@"{\"valid\":false}");
        }
    }];
}

RCT_EXPORT_METHOD(rvGetCloudAnchor:(nonnull NSNumber *)reactTag
                           anchorId:(NSString *)anchorId
                            resolve:(RCTPromiseResolveBlock)resolve
                             reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvGetCloudAnchor:anchorId
                completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (anchorData) [r setObject:anchorData forKey:@"anchor"];
                if (error)      [r setObject:error      forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvListCloudAnchors:(nonnull NSNumber *)reactTag
                               limit:(NSInteger)limit
                              offset:(NSInteger)offset
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvListCloudAnchors:(int)limit offset:(int)offset
                completionHandler:^(BOOL success, NSArray *anchors, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                [r setObject:success ? anchors : @[] forKey:@"anchors"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvUpdateCloudAnchor:(nonnull NSNumber *)reactTag
                               anchorId:(NSString *)anchorId
                                   name:(NSString *)name
                            description:(NSString *)description
                               isPublic:(BOOL)isPublic
                                resolve:(RCTPromiseResolveBlock)resolve
                                 reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvUpdateCloudAnchor:anchorId name:name description:description
                isPublic:isPublic completionHandler:^(BOOL success, NSDictionary *anchorData, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (anchorData) [r setObject:anchorData forKey:@"anchor"];
                if (error)      [r setObject:error      forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvDeleteCloudAnchor:(nonnull NSNumber *)reactTag
                              anchorId:(NSString *)anchorId
                               resolve:(RCTPromiseResolveBlock)resolve
                                reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvDeleteCloudAnchor:anchorId
                completionHandler:^(BOOL success, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvFindNearbyCloudAnchors:(nonnull NSNumber *)reactTag
                                  latitude:(double)latitude
                                 longitude:(double)longitude
                                    radius:(double)radius
                                     limit:(NSInteger)limit
                                   resolve:(RCTPromiseResolveBlock)resolve
                                    reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvFindNearbyCloudAnchors:latitude longitude:longitude
                radius:radius limit:(int)limit
                completionHandler:^(BOOL success, NSArray *anchors, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                [r setObject:success ? anchors : @[] forKey:@"anchors"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvGetProject:(nonnull NSNumber *)reactTag
                    resolve:(RCTPromiseResolveBlock)resolve
                     reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvGetProject:^(BOOL success, NSString *data, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (success && data) [r setObject:data forKey:@"data"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvGetScene:(nonnull NSNumber *)reactTag
                    sceneId:(NSString *)sceneId
                    resolve:(RCTPromiseResolveBlock)resolve
                     reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvGetScene:sceneId
                completionHandler:^(BOOL success, NSString *data, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (success && data) [r setObject:data forKey:@"data"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvGetSceneAssets:(nonnull NSNumber *)reactTag
                            sceneId:(NSString *)sceneId
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvGetSceneAssets:sceneId
                completionHandler:^(BOOL success, NSArray *assets, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                [r setObject:success ? assets : @[] forKey:@"assets"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvAttachAssetToCloudAnchor:(nonnull NSNumber *)reactTag
                                    anchorId:(NSString *)anchorId
                                     fileUrl:(NSString *)fileUrl
                                    fileSize:(double)fileSize
                                        name:(NSString *)name
                                   assetType:(NSString *)assetType
                              externalUserId:(NSString *)externalUserId
                                     resolve:(RCTPromiseResolveBlock)resolve
                                      reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvAttachAssetToCloudAnchor:anchorId fileUrl:fileUrl
                fileSize:(int64_t)fileSize name:name assetType:assetType externalUserId:externalUserId
                completionHandler:^(BOOL success, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvRemoveAssetFromCloudAnchor:(nonnull NSNumber *)reactTag
                                       anchorId:(NSString *)anchorId
                                        assetId:(NSString *)assetId
                                        resolve:(RCTPromiseResolveBlock)resolve
                                         reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvRemoveAssetFromCloudAnchor:anchorId assetId:assetId
                completionHandler:^(BOOL success, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(success) forKey:@"success"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

RCT_EXPORT_METHOD(rvTrackCloudAnchorResolution:(nonnull NSNumber *)reactTag
                                       anchorId:(NSString *)anchorId
                                        success:(BOOL)success
                                     confidence:(double)confidence
                                     matchCount:(NSInteger)matchCount
                                    inlierCount:(NSInteger)inlierCount
                               processingTimeMs:(NSInteger)processingTimeMs
                                       platform:(NSString *)platform
                                 externalUserId:(NSString *)externalUserId
                                        resolve:(RCTPromiseResolveBlock)resolve
                                         reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"}); return;
            }
            [(VRTARSceneNavigator *)view rvTrackCloudAnchorResolution:anchorId success:success
                confidence:confidence matchCount:(int)matchCount inlierCount:(int)inlierCount
                processingTimeMs:(int)processingTimeMs platform:platform externalUserId:externalUserId
                completionHandler:^(BOOL ok, NSString *error) {
                NSMutableDictionary *r = [NSMutableDictionary new];
                [r setObject:@(ok) forKey:@"success"];
                if (error) [r setObject:error forKey:@"error"];
                resolve(r);
            }];
        } @catch (NSException *ex) { resolve(@{@"success": @NO, @"error": ex.reason}); }
    }];
}

#pragma mark - Scene Semantics API Methods

RCT_EXPORT_METHOD(isSemanticModeSupported:(nonnull NSNumber *)reactTag
                                  resolve:(RCTPromiseResolveBlock)resolve
                                   reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"supported": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            BOOL supported = [component isSemanticModeSupported];
            resolve(@{@"supported": @(supported)});
        } @catch (NSException *exception) {
            resolve(@{@"supported": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(setSemanticModeEnabled:(nonnull NSNumber *)reactTag
                                 enabled:(BOOL)enabled) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component setSemanticModeEnabled:enabled];
        }
    }];
}

RCT_EXPORT_METHOD(getSemanticLabelFractions:(nonnull NSNumber *)reactTag
                                    resolve:(RCTPromiseResolveBlock)resolve
                                     reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            NSDictionary *fractions = [component getSemanticLabelFractions];

            NSMutableDictionary *result = [NSMutableDictionary new];
            [result setObject:@YES forKey:@"success"];
            [result setObject:fractions forKey:@"fractions"];
            resolve(result);
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(getSemanticLabelFraction:(nonnull NSNumber *)reactTag
                                     label:(NSString *)label
                                   resolve:(RCTPromiseResolveBlock)resolve
                                    reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"success": @NO, @"fraction": @0.0, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            float fraction = [component getSemanticLabelFraction:label];

            NSMutableDictionary *result = [NSMutableDictionary new];
            [result setObject:@YES forKey:@"success"];
            [result setObject:@(fraction) forKey:@"fraction"];
            resolve(result);
        } @catch (NSException *exception) {
            resolve(@{@"success": @NO, @"fraction": @0.0, @"error": exception.reason});
        }
    }];
}

#pragma mark - Monocular Depth Estimation API Methods

RCT_EXPORT_METHOD(setPreferMonocularDepth:(nonnull NSNumber *)reactTag
                                   prefer:(BOOL)prefer) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
        if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            [component setPreferMonocularDepth:prefer];
        }
    }];
}

RCT_EXPORT_METHOD(isPreferMonocularDepth:(nonnull NSNumber *)reactTag
                                 resolve:(RCTPromiseResolveBlock)resolve
                                  reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"preferred": @NO, @"error": @"Invalid view type"});
                return;
            }

            VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;
            BOOL preferred = [component isPreferMonocularDepth];
            resolve(@{@"preferred": @(preferred)});
        } @catch (NSException *exception) {
            resolve(@{@"preferred": @NO, @"error": exception.reason});
        }
    }];
}

#pragma mark - Debugging & Validation Methods

RCT_EXPORT_METHOD(isDepthOcclusionSupported:(nonnull NSNumber *)reactTag
                                   resolve:(RCTPromiseResolveBlock)resolve
                                    reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{@"supported": @NO, @"error": @"Invalid view type - component not found or not initialized"});
                return;
            }

            // On iOS, depth occlusion is always supported (via monocular depth or LiDAR)
            resolve(@{@"supported": @YES});
        } @catch (NSException *exception) {
            resolve(@{@"supported": @NO, @"error": exception.reason});
        }
    }];
}

RCT_EXPORT_METHOD(getGeospatialSetupStatus:(nonnull NSNumber *)reactTag
                                  resolve:(RCTPromiseResolveBlock)resolve
                                   reject:(RCTPromiseRejectBlock)reject) {
    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if (![view isKindOfClass:[VRTARSceneNavigator class]]) {
                resolve(@{
                    @"geospatialSupported": @NO,
                    @"locationServicesAvailable": @NO,
                    @"apiKeyConfigured": @YES,
                    @"error": @"Invalid view type"
                });
                return;
            }

            // On iOS:
            // - Geospatial is supported on iOS 15+
            // - Location services must be enabled by user
            // - No API key configuration needed (uses Apple's location services)
            
            BOOL geospatialSupported = [NSProcessInfo processInfo].operatingSystemVersion.majorVersion >= 15;
            BOOL locationServicesAvailable = [CLLocationManager locationServicesEnabled];
            
            resolve(@{
                @"geospatialSupported": @(geospatialSupported),
                @"locationServicesAvailable": @(locationServicesAvailable),
                @"apiKeyConfigured": @YES  // Always true on iOS
            });
        } @catch (NSException *exception) {
            resolve(@{
                @"geospatialSupported": @NO,
                @"locationServicesAvailable": @NO,
                @"apiKeyConfigured": @YES,
                @"error": exception.reason
            });
        }
    }];
}

#pragma mark - Cleanup Methods

RCT_EXPORT_METHOD(cleanup:(nonnull NSNumber *)reactTag) {
    // This method is called from componentWillUnmount to ensure proper cleanup
    // of AR resources before the native view is deallocated.

    [self rv_withViewForTag:reactTag block:^(RCTViewRegistry *viewRegistry) {
        @try {
            VRTView *view = (VRTView *)RCTPaperViewOrCurrentView([viewRegistry viewForReactTag:reactTag]);
            if ([view isKindOfClass:[VRTARSceneNavigator class]]) {
                VRTARSceneNavigator *component = (VRTARSceneNavigator *)view;

                // Trigger explicit cleanup to prevent memory leaks
                // This ensures ARSession is paused and GL resources are released
                // even if willMoveToSuperview: is not called (e.g., in Fabric)
                [component cleanupViroResources];

                // Force removal from superview to trigger deallocation
                if (component.superview) {
                    [component removeFromSuperview];
                }

                // Try to manually call invalidate
                [component invalidate];
            }
        } @catch (NSException *exception) {
            NSLog(@"ERROR during cleanup: %@", exception.reason);
        }
    }];
}

@end

//
//  VRORendererBridge+Scene.h
//  ViroReact
//
//  Copyright © 2026 ReactVision. All rights reserved.
//
//  The scene-handoff half of VRORendererBridge, kept apart from the main header because it
//  names C++ types. VRORendererBridge.h is imported by ViroReactUI's Swift, and Swift builds it
//  as a Clang module in plain Objective-C mode, where <memory> and VROSceneController do not
//  parse. Only the Objective-C++ side of ViroReact — the view managers — needs what is here.
//

#pragma once

#if __has_include(<CompositorServices/CompositorServices.h>)

#import "VRORendererBridge.h"

#include <memory>

class VROSceneController;

NS_ASSUME_NONNULL_BEGIN

@interface VRORendererBridge (Scene)

/// Hands a scene built by React Native to the renderer, replacing whatever it was showing.
///
/// The bridge starts on a small hardcoded scene so the ImmersiveSpace is never empty while the
/// JS side is still mounting — and so the renderer stays independently testable without React.
/// The first call here takes over from it.
///
/// Passing nullptr is not a way to clear the scene; the renderer always needs one.
- (void)setNativeSceneController:(std::shared_ptr<VROSceneController>)sceneController;

/// Drops the React-owned scene and puts an empty one in its place.
///
/// Must be called before React tears the scene's views down. The renderer keeps the scene
/// controller alive and walks its nodes every frame; those nodes are backed by the very
/// Objective-C views React is destroying, so a scene that outlives its owner is a use-after-free
/// waiting for the next frame.
- (void)detachNativeSceneController;

/// Drops the scene only if it is the one currently being rendered.
///
/// The ImmersiveSpace is one surface for the whole app and the renderer holds one scene, but an
/// app can have several navigators mounted at once — a stack that keeps the screen underneath
/// alive is the ordinary case. Whichever hands its scene over last is the one on display, and an
/// unconditional detach from any of the others blanks it. This detaches only the owner's own.
- (void)detachNativeSceneControllerIfCurrent:(std::shared_ptr<VROSceneController>)sceneController;

@end

NS_ASSUME_NONNULL_END

#endif  // __has_include(<CompositorServices/CompositorServices.h>)


//
//  VRTSceneNavigator.m
//  React
//
//  Created by Vik Advani on 3/11/16.
//  Copyright © 2016 Viro Media. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining
//  a copy of this software and associated documentation files (the
//  "Software"), to deal in the Software without restriction, including
//  without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to
//  permit persons to whom the Software is furnished to do so, subject to
//  the following conditions:
//
//  The above copyright notice and this permission notice shall be included
//  in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//  CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import <ViroKit/ViroKit.h>
#import <React/RCTAssert.h>
#import <React/RCTLog.h>
#import "VRTSceneNavigator.h"
#import "VRTScene.h"
#import "VRTNotifications.h"
#if TARGET_OS_VISION
#import "VisionOS/VRORendererBridge+Scene.h"
#endif
#import <React/RCTRootView.h>
#import <React/RCTUtils.h>
#import "VRTPerfMonitor.h"
#import "VRTMaterialManager.h"
#import "VRTMaterialVideo.h"

/**
 VRTSceneNavigator manages the various scenes that a Viro App can navigate between.
 **/

@implementation VRTSceneNavigator {
    id <VROView> _vroView;
//    VROViewControllerGVR *_gvrController;
#if TARGET_OS_VISION
    // Scene waiting for an ImmersiveSpace to exist. See -setSceneView:.
    VRTScene *_pendingScene;
#endif
}

- (instancetype)initWithBridge:(RCTBridge *)bridge {
    self = [super initWithBridge:bridge];
    if (self) {
    }
    return self;
}

#if TARGET_OS_VISION
// The observer is bound to the window, not to the object's lifetime.
//
// NSNotificationCenter keeps an unretained reference, so a registration that outlives the view
// by even a moment is a message to freed memory. React Native recycles this view through
// RCTLegacyViewManagerInteropComponentView, which tears it out of the hierarchy on unmount —
// registering in -init and unregistering only in -dealloc left exactly that window open, and the
// app died in -[UIView removeFromSuperview] with an objc_msgSend on a released object.
- (void)willMoveToWindow:(UIWindow *)newWindow {
    [super willMoveToWindow:newWindow];
    if (newWindow == nil) {
        // Leaving the hierarchy: hand the renderer back an empty scene before React starts
        // destroying the views these nodes are built on.
        //
        // Only if the scene on display is this navigator's. A screen stack keeps the screen
        // underneath mounted, so two navigators can be alive at once, and the one leaving is not
        // necessarily the one being rendered — detaching unconditionally blanked the ImmersiveSpace
        // of the screen the wearer was actually looking at.
        if (_currentScene != nil) {
            [VRORendererBridge.currentBridge
                detachNativeSceneControllerIfCurrent:[_currentScene sceneController]];
        }
        _pendingScene = nil;
    }
}

- (void)didMoveToWindow {
    [super didMoveToWindow];
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center removeObserver:self name:@"ViroImmersiveRendererDidBecomeActive" object:nil];
    if (self.window != nil) {
        [center addObserver:self
                   selector:@selector(immersiveRendererDidBecomeActive:)
                       name:@"ViroImmersiveRendererDidBecomeActive"
                     object:nil];
        // The renderer may already be up by the time this view lands in a window.
        [self attachPendingSceneToBridge];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#endif

/*
 We defer creating the VR view until either the Scene is added or
 VR mode is set. This way we're able to disable VR mode prior to creating
 the view, which is important because if VR mode is enabled we force
 landscape mode, and if VR mode is not we do not.
 
 Ideally we'd be able to set VR mode after the fact, but GVR bugs prevent
 this (the double-viewport issue). Return YES if we created a new _vroView, NO if
 one already exists and the method was a no-op.
 */
- (BOOL)initVRView {
    if (_vroView != nil) {
        return NO;
    }
  //  VRORendererConfiguration config;
  //  _gvrController = [[VROViewControllerGVR alloc] initWithConfig:config];
  //  _gvrController.forceLandscape = _vrModeEnabled;
  //  _vroView = (id<VROView>) _gvrController.view;
    
    // Load materials; must be done each time we have a new context (e.g. after
    // the EGL context is created by the VROViewGVR
    VRTMaterialManager *materialManager = [self.bridge materialManager];
    [materialManager reloadMaterials];
   // VROViewGVR *viewCardboard = (VROViewGVR *) _gvrController.view;
   // [viewCardboard setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    _vroView.renderDelegate = self;
    
#if TARGET_OS_VISION
    // No UIScreen on visionOS: there is no single screen to match, and this view is not the
    // render surface — the ImmersiveSpace owns the geometry and VRORendererBridge drives the
    // renderer. Leaving the frame to the layout system is the correct behaviour here.
#else
    [self setFrame:[UIScreen mainScreen].bounds];
#endif
    [self setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    
  //  [self addSubview:viewCardboard];
    self.currentViews = [[NSMutableArray alloc] init];
    [self.bridge.perfMonitor setView:_vroView];
    
    return YES;
}

- (void)setVrModeEnabled:(BOOL)enabled {
    _vrModeEnabled = enabled;
    [self initVRView];
    [_vroView setVrMode:_vrModeEnabled];
}

- (void)recenterTracking {
    [self initVRView];
   // VROViewGVR *cardboardView = _vroView;
   // [cardboardView recenterTracking];
}

- (UIView *)rootVROView {
    [self initVRView];
    return (UIView *)_vroView;
}

//VROComponent overrides...
- (void)insertReactSubview:(UIView *)subview atIndex:(NSInteger)atIndex {
    VRT_RETURN_IF_NIL_SUBVIEW(subview, atIndex);
    RCTAssert([subview isKindOfClass:[VRTScene class]], @"VRTSceneNavigator only accepts VRTScene subviews");
    VRTScene *sceneView = (VRTScene *)subview;
    BOOL isVRViewInit = [self initVRView];
    //if initVRView ran then re apply materials.
    if (isVRViewInit == YES) {
        [self applyMaterialsToSceneChildren:sceneView];
    }
    
    [sceneView setView:_vroView];
    [self.currentViews insertObject:sceneView atIndex:atIndex];
    
    if (self.currentSceneIndex == atIndex) {
        [self setSceneView:sceneView];
    //    [(VROViewGVR *)_vroView setPaused:NO];
    }
    [super insertReactSubview:subview atIndex:atIndex];
}

-(void)setCurrentSceneIndex:(NSInteger)index {
    int currentViewsLength = (int)[_currentViews count];
    _currentSceneIndex = index;
    
    if (_currentSceneIndex < 0 || _currentSceneIndex > (currentViewsLength - 1)){
        // setCurrentSceneTag may be set before insertReactSubView class.
        // In this case, just return.
        return;
    }
    
    VRTScene *sceneView = [_currentViews objectAtIndex:index];
    [self setSceneView:sceneView];
}

- (void)removeReactSubview:(UIView *)subview {
    VRTScene *sceneView = (VRTScene *)subview;
    [self.currentViews removeObject:sceneView];
    [super removeReactSubview:subview];
}

- (NSArray *)reactSubviews {
    return self.currentViews;
}

- (UIView *)reactSuperview{
    return nil;
}

#pragma mark - VRORenderDelegate methods

- (void)setupRendererWithDriver:(std::shared_ptr<VRODriver>)driver {
    
}

- (void)userDidRequestExitVR {
    // Notify javascript listeners (for ReactNativeJs to ViroReactJs cases)
    if (self.onExitViro != nil) {
        self.onExitViro(nil);
    }
    
    // Notify Native listeners (for NativeApp to ViroReactJs cases)
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:kVRTOnExitViro object:nil]];
}

#if TARGET_OS_VISION
- (void)attachPendingSceneToBridge {
    if (_pendingScene == nil) {
        return;
    }
    VRORendererBridge *bridge = VRORendererBridge.currentBridge;
    if (bridge == nil) {
        return;
    }
    [bridge setNativeSceneController:[_pendingScene sceneController]];
    _pendingScene = nil;
}

- (void)immersiveRendererDidBecomeActive:(NSNotification *)notification {
    [self attachPendingSceneToBridge];
}
#endif

- (void)setSceneView:(VRTScene *)sceneView {
    if (_currentScene == sceneView) {
        return;
    }

#if TARGET_OS_VISION
    // On visionOS this view is not a render surface and _vroView is nil — the GVR view this
    // navigator used to create was removed long ago, which is why ViroSceneNavigator carries a
    // deprecation notice everywhere else. The ImmersiveSpace owns the display instead, so the
    // scene goes to the bridge driving it. Nothing is lost by skipping the timed transition:
    // VRORendererBridge swaps scenes outright.
    // React mounts the scene as soon as the navigator renders, while opening the ImmersiveSpace
    // is asynchronous — so on a cold start there is usually no bridge yet. Hold the scene and
    // hand it over when the renderer announces itself.
    _pendingScene = sceneView;
    [self attachPendingSceneToBridge];
#else
    if (_currentScene == nil) {
        [_vroView setSceneController:[sceneView sceneController]];
    } else {
        [_vroView setSceneController:[sceneView sceneController] duration:1 timingFunction:VROTimingFunctionType::EaseIn];
    }
#endif
    _currentScene = sceneView;
}

// recursively traverse down the scene tree to apply materials. This is invoked after reloaded materials from initVRView() to ensure components are applying the latest reloaded materials.
- (void)applyMaterialsToSceneChildren:(VRTView *)view {
    NSArray *children = [view reactSubviews];
    if (children != nil && children.count > 0) {
        for (VRTView *childView in children) {
            if ([childView respondsToSelector:@selector(applyMaterials)]) {
                if ([childView isKindOfClass:[VRTNode class]]) {
                    VRTNode *node = (VRTNode *)childView;
                    [node applyMaterials];
                }
            }
            [self applyMaterialsToSceneChildren:childView];
        }
    }
}

- (void)removeFromSuperview {
    [self parentDidDisappear];
    
    // For React Native New Architecture (Fabric) compatibility
    if (!self.superview) {
        return;
    }
    
    [super removeFromSuperview];
    
    /*
     We need to always ensure that React's root view is showing when we
     are deallocating Viro and our renderer. This is because GVR does not
     perform the proper cleanup on its windows: VIRO-1067
     */
    if (RCTIsMainQueue()){
        NSArray *windowArray = [UIApplication sharedApplication].windows;
        if (windowArray == nil || [windowArray count] == 0) {
            return;
        }
        
        /*
         Search the top level rootView controllers and their children to see if their views are
         RCTRootView. If so, then make that root view visible. This is a hack that
         removes GVR's frozen frame referenced in VIRO-1067 during shutdown.
         */
        for (int i = 0; i < [windowArray count]; i ++) {
            UIWindow *window = [windowArray objectAtIndex:i];
            if (window != nil && window.rootViewController != nil) {
                if (window.rootViewController.view != nil && [self findRCTRootView:window.rootViewController] != nil) {
                    [window makeKeyAndVisible];
                    return;
                }
            }
        }
        
        /*
         If we are still here we didn't make any window visible over GVR. Make first one with a valid
         rootViewController visible.
         */
        for (int i = 0; i < [windowArray count]; i++) {
            UIWindow *window = [windowArray objectAtIndex:i];
            if (window != nil && window.rootViewController != nil) {
                [window makeKeyAndVisible];
                return;
            }
        }
    }
}

/*
 Unproject the given screen coordinates into world coordinates. The given screen coordinate vector must
 contain a Z element in the range [0,1], where 0 is the near clipping plane and 1 the far clipping plane.
 */
- (VROVector3f) unprojectPoint:(VROVector3f)point {
    if (_vroView == nil || _vroView.renderer == nil) {
        RCTLogError(@"Unable to unproject. Renderer not intialized");
    }

    VROVector3f unprojectedPoint = [_vroView unprojectPoint:point];
    return unprojectedPoint;
}

// Project the given world coordinates into screen coordinates.
- (VROVector3f) projectPoint:(VROVector3f)point {
    if (_vroView == nil || _vroView.renderer == nil) {
        RCTLogError(@"Unable to unproject. Renderer not intialized");
    }

    VROVector3f projectedPoint = [_vroView projectPoint:point];
    return projectedPoint;
}


// Return the RCTRootView, if any, descending from the given controller
-(RCTRootView *) findRCTRootView:(UIViewController *)controller {
    if ([controller.view isKindOfClass:[RCTRootView class]]) {
        return (RCTRootView *)controller.view;
    }
    for (UIView *view in controller.view.subviews) {
        if([view isKindOfClass:[RCTRootView class]]) {
            return (RCTRootView *)view;
        }
    }

    if (controller.childViewControllers == nil) {
        return nil;
    }
    
    for (UIViewController *controllerChild in controller.childViewControllers) {
        if (controllerChild.view != nil) {
            if ([controllerChild.view isKindOfClass:[RCTRootView class]]) {
                return (RCTRootView *)controllerChild.view;
            }
            for (UIView *view in controllerChild.view.subviews) {
                if ([view isKindOfClass:[RCTRootView class]]) {
                    return (RCTRootView *)view;
                }
            }
        }

        RCTRootView *potentialRootView = [self findRCTRootView:controllerChild];
        if (potentialRootView != nil) {
            return potentialRootView;
        }
    }
    return nil;
}

#pragma mark RCTInvalidating methods

- (void)invalidate {
    //NOTE: DO NOT NULL OUT _currentViews here, that will cause a memory leak and prevent child views from
    //being released.
    //_currentViews = nil;
    _currentScene = nil;
    _vroView = nil;
    _childViews = nil;
}

@end

//
//  VRTView.h
//  React
//
//  Created by Vik Advani on 10/21/15.
//  Copyright © 2015 Viro Media. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining
//  a copy of this software and associated documentation files (the
//  "Software"), to deal in the Software without restriction, including
//  without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to
//  permit persons to whom the Software is furnished to do so, subject to
//  the following conditions:
//
//  The above copyright notice and this permission notice shall be included
//  in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//  CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
//  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

#import <ViroKit/ViroKit.h>
#import <React/RCTComponent.h>
#import <React/RCTBridge.h>
#import <React/UIView+React.h>
#import "VRTMaterialManager.h"

typedef NS_ENUM(NSInteger, ViroConstraintType) {
  ViroConstraintTypeNone,
  ViroConstraintTypeBillboard,
};


/*
 RN 0.86's legacy interop can hand a view manager a nil subview. A child inserted in the
 middle of a legacy parent waits in the parent's queue until the parent's next update. If
 the child is unmounted first, its recycled view is nil by the time the queue runs, and
 -[NSMutableArray insertObject:atIndex:] throws "object cannot be nil". Skip it instead:
 the child is already gone.
 */
#define VRT_RETURN_IF_NIL_SUBVIEW(subview, index) \
    if ((subview) == nil) { \
        NSLog(@"[Viro] %@ ignored a nil subview inserted at index %ld", NSStringFromClass([self class]), (long)(index)); \
        return; \
    }

@class VRTScene;

@interface VRTView : UIView {
    @protected NSMutableArray *_childViews;
}

// NOT named `superview`. This is Viro's parent in the React element tree, which is a different
// relationship from UIKit's view hierarchy — a VRTNode is a scene-graph node, not a subview of
// anything. Declaring it as `superview` synthesised an override of -[UIView superview], so every
// UIKit internal that asked a VRT view for its superview got Viro's answer. -removeFromSuperview
// is one of those, and the guards written as `if (!self.superview) return;` before the real
// removal then skipped it, leaving the view linked in UIKit while React believed it detached.
@property(nullable, nonatomic, weak) VRTView *viroSuperview;
@property (nonatomic, readonly, weak) RCTBridge *bridge;

/*
 The following variables are only valid after sceneWillAppear is 
 invoked.
 */
@property (nonatomic, readwrite) VRORenderContext *context;
@property (nonatomic, readwrite) std::shared_ptr<VROScene> scene;
@property (nonatomic, readwrite) std::shared_ptr<VRODriver> driver;
/*
 true/false if it's attached to a parent and its parent has appeared.
 */
@property (nonatomic, assign) BOOL parentHasAppeared;

- (instancetype)initWithBridge:(RCTBridge *)bridge;

- (void)insertReactSubview:(UIView *)subview atIndex:(NSInteger)atIndex;
- (void)removeReactSubview:(UIView *)subview;
- (NSArray *)reactSubviews;
- (UIView *)reactSuperview;
- (NSNumber *)reactTagAtPoint:(CGPoint)point;

// View/ShadowView is a root view
- (BOOL)isReactRootView;

// Whether or not the view should appear
- (BOOL)shouldAppear;

// Methods invoked by parent views to let child views whether or not they
// did appear based on the parent's properties (ie. if parent is visible
// and within the scene graph, but the child may not show up if itself is
// not visible). Children override these methods to perform actions based
// on the view appearing or disappearing.
- (void)parentDidAppear;
- (void)parentDidDisappear;

// This function handles any logic we need to do due to changes in [self shouldAppear].
- (void)handleAppearanceChange;

// Methods invoked when the scene to which the views belong appears
// and disappears
- (void)sceneWillAppear;
- (void)sceneWillDisappear;

// Fabric architecture compatibility - called before view recycling
- (void)prepareForRecycle;

// The VRTScene this view sits under, or nil until it, or an ancestor of it, has been inserted
// beneath one. A VRTScene answers itself.
- (nullable VRTScene *)viroScene;

// Invoked on a view, and then on each of its children, the moment it joins a VRTScene's tree:
// when it is inserted under a parent that already sits under a scene, or when such an ancestor
// is. React Native inserts a subtree bottom-up, children before their parent, so a view's own
// insertion is not always that moment; its parent's may be. Overrides must call super.
- (void)didJoinViroScene:(VRTScene *)scene;

@end

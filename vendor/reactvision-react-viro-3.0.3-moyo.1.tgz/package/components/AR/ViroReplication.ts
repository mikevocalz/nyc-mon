/**
 * Copyright © 2026 ReactVision
 *
 * Replicated room state — ordering, conflict resolution and authority.
 *
 * The co-location channel (`ViroColocation`) relays poses and is lossy by
 * design: the next pose supersedes the last one 100 ms later. Application state
 * does not work that way — "the door is open" has to survive a dropped frame, a
 * late joiner and a reconnect — so it gets a different transport with different
 * guarantees.
 *
 * ## Where this runs, and why it is not the channel
 *
 * A separate WebSocket, opened from JS, against the same room id. Poses
 * originate in C++ at frame rate and must not cross the bridge; application
 * state originates in JS and must not be lossy. One socket for both would make
 * each pay the other's cost.
 *
 * ## What the server guarantees
 *
 * Total order. Every accepted change carries a sequence number, identical for
 * every client. A gap means a delta was missed, and this client asks for a
 * resync rather than carrying on with a hole in its state.
 *
 * ## Conflict resolution
 *
 * - `claim()` takes authority over an entity. While held, only the owner may
 *   change it — that is how two people grabbing the same object resolve.
 * - `expectVersion` opts a write into optimistic concurrency: if the entity
 *   moved on, the write is refused and the current value comes back.
 * - Unowned entities are last-writer-wins.
 * - A peer that disconnects releases whatever it held, so a crash mid-drag does
 *   not freeze an object.
 *
 * @providesModule ViroReplication
 */

"use strict";

import { Platform } from "react-native";
import { isWeb } from "../Utilities/ViroPlatform";
import { VIRO_VERSION } from "../Utilities/ViroVersion";

/** React Native's constructor, which the DOM typing does not describe. */
type HeaderWebSocket = new (
  url: string,
  protocols: null,
  options: { headers: Record<string, string> }
) => WebSocket;

export type ViroReplicatedEntity = {
  id: string;
  fields: Record<string, unknown>;
  /** Server-assigned, bumped on every accepted change. Pass to `expectVersion`. */
  version: number;
  /** peerId holding authority, or null when free. */
  owner: string | null;
};

export type ViroReplicationState =
  | "idle"
  | "connecting"
  | "synced"
  | "reconnecting"
  | "failed";

export type ViroReplicationRejectReason =
  | "not-owner"
  | "version-conflict"
  | "already-owned"
  | "no-such-entity"
  | "malformed"
  | "too-many-entities"
  | "field-too-large"
  /** The room is at the size its saved copy may be, so nothing more fits. */
  | "room-too-large"
  /** Every room this team has open adds up to its ceiling on the relay. */
  | "org-too-large";

export type ViroReplicationRejection = {
  reason: ViroReplicationRejectReason;
  /** The entity's server state at the time of refusal, when it has one. */
  current?: ViroReplicatedEntity;
};

export type ViroReplicationConfig = {
  /** Same id that names the frame and the channel room. */
  roomId: string;
  /**
   * Required unless `headers` is given. The only credential a browser can
   * send.
   */
  apiKey?: string;
  projectId: string;
  /**
   * Co-location relay base URL; `http(s)` is converted to `ws(s)`.
   *
   * The relay, not the platform API. `ViroColocationRooms` calls the platform
   * for join codes and they are different hosts, so one endpoint cannot serve
   * both.
   */
  endpoint?: string;
  /**
   * Handshake credentials, called before every connect and reconnect so a
   * token that refreshed in the meantime reaches the next attempt. Sent
   * alongside `x-api-key` when `apiKey` is also given. Native only: a browser
   * cannot set handshake headers.
   */
  headers?: () => Promise<Record<string, string>> | Record<string, string>;
};

export type ViroWriteOptions = {
  /**
   * Refuse the write unless the entity is still at this version. Omit to accept
   * last-writer-wins.
   */
  expectVersion?: number;
  /**
   * Apply locally before the server confirms, and roll back if it refuses.
   *
   * Off by default: the simple path is one round trip and never shows a value
   * that turns out not to be true. Turn it on for something being dragged,
   * where a round trip per frame is visible.
   */
  optimistic?: boolean;
};

type Listener = () => void;

const BACKOFF_MS = [500, 1000, 2000, 4000, 8000];
const DEFAULT_ENDPOINT = "https://colocation.reactvision.xyz";

function isThenable<T>(value: T | PromiseLike<T>): value is PromiseLike<T> {
  return typeof (value as PromiseLike<T> | null)?.then === "function";
}

/** https:// → wss://, http:// → ws://. Anything else passes through. */
function toSocketScheme(endpoint: string): string {
  if (endpoint.startsWith("https://")) return "wss://" + endpoint.slice(8);
  if (endpoint.startsWith("http://")) return "ws://" + endpoint.slice(7);
  return endpoint;
}

export class ViroReplicationClient {
  private ws: WebSocket | null = null;
  private config: ViroReplicationConfig | null = null;

  private entities = new Map<string, ViroReplicatedEntity>();
  private lastSeq = -1;
  private _state: ViroReplicationState = "idle";
  private _localPeerId = "";
  private _error: string | undefined;

  private attempt = 0;
  private closedByUs = false;
  private retryTimer: ReturnType<typeof setTimeout> | undefined;
  /** Bumped per open and on disconnect, so a late `headers` answer is dropped. */
  private openSeq = 0;

  private listeners = new Set<Listener>();
  /**
   * Optimistic writes awaiting confirmation, by ref.
   *
   * `id` is stored separately from `before` because rolling back a *create*
   * has no previous value to restore — only an entity to remove — and without
   * the id there is nothing to remove it by.
   */
  private pending = new Map<
    string,
    { id: string; before?: ViroReplicatedEntity }
  >();
  private refCounter = 0;

  get state(): ViroReplicationState {
    return this._state;
  }

  get localPeerId(): string {
    return this._localPeerId;
  }

  get error(): string | undefined {
    return this._error;
  }

  /** Snapshot of the current state. Safe to hold — it is a copy. */
  getEntities(): ViroReplicatedEntity[] {
    return [...this.entities.values()].map((e) => ({
      ...e,
      fields: { ...e.fields },
    }));
  }

  get(id: string): ViroReplicatedEntity | undefined {
    const e = this.entities.get(id);
    return e ? { ...e, fields: { ...e.fields } } : undefined;
  }

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  connect(config: ViroReplicationConfig): void {
    this.disconnect();
    this.config = config;
    this.closedByUs = false;
    this.attempt = 0;
    this.open();
  }

  disconnect(): void {
    this.closedByUs = true;
    this.openSeq++;
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.retryTimer = undefined;
    if (this.ws) {
      // Detached first: the handlers would otherwise fire during close and
      // schedule a reconnect for a session the caller has abandoned.
      this.ws.onopen = null;
      this.ws.onmessage = null;
      this.ws.onclose = null;
      this.ws.onerror = null;
      try {
        this.ws.close();
      } catch {
        // Already closing; nothing to do.
      }
    }
    this.ws = null;
    this.entities.clear();
    this.pending.clear();
    this.lastSeq = -1;
    this._localPeerId = "";
    this.setState("idle");
  }

  // ── Operations ────────────────────────────────────────────────────────────

  /** Take authority. Creates the entity if it does not exist yet. */
  claim(id: string, opts: ViroWriteOptions = {}): void {
    this.send({ op: "claim", id, expectVersion: opts.expectVersion });
  }

  release(id: string): void {
    this.send({ op: "release", id });
  }

  /** Merge `fields` into the entity. Creates it if absent. */
  set(
    id: string,
    fields: Record<string, unknown>,
    opts: ViroWriteOptions = {}
  ): void {
    const ref = this.send({
      op: "set",
      id,
      fields,
      expectVersion: opts.expectVersion,
    });
    if (!opts.optimistic || !ref) return;

    // Remember what to restore if the server refuses, then show the change now.
    const before = this.entities.get(id);
    this.pending.set(ref, {
      id,
      before: before ? { ...before, fields: { ...before.fields } } : undefined,
    });

    const base = before ?? { id, fields: {}, version: 0, owner: null };
    this.entities.set(id, { ...base, fields: { ...base.fields, ...fields } });
    this.emit();
  }

  delete(id: string, opts: ViroWriteOptions = {}): void {
    this.send({ op: "delete", id, expectVersion: opts.expectVersion });
  }

  /**
   * Empty the room, whoever is holding what.
   *
   * The reset a shared work zone needs, and the one operation that ignores
   * ownership. Issuing a reset as one `delete` per entity cannot work: an owned
   * entity refuses `not-owner`, so exactly the objects somebody is still
   * holding would survive it.
   */
  clear(): void {
    this.send({ op: "clear" });
  }

  // ── Socket ────────────────────────────────────────────────────────────────

  private open(): void {
    const cfg = this.config;
    if (!cfg) return;

    const base = toSocketScheme(cfg.endpoint ?? DEFAULT_ENDPOINT);
    const path = `${base}/functions/v1/replication/${encodeURIComponent(cfg.roomId)}`;

    this.setState(this.attempt === 0 ? "connecting" : "reconnecting");

    // Same headers the pose channel sends. React Native's WebSocket takes them
    // as a third argument and forwards them to the native handshake; only a
    // browser cannot set them, and there the credentials go in the query
    // string, which the relay refuses unless it was started to allow it (a
    // browser client needs an Origin allowlist first).
    if (isWeb) {
      if (!cfg.apiKey) {
        this.fail("a browser can only join with an apiKey");
        return;
      }
      this.attach(
        new WebSocket(
          `${path}?apiKey=${encodeURIComponent(cfg.apiKey)}` +
            `&projectId=${encodeURIComponent(cfg.projectId)}`
        )
      );
      return;
    }
    if (!cfg.apiKey && !cfg.headers) {
      this.fail("an apiKey or a headers provider is required");
      return;
    }

    const seq = ++this.openSeq;
    const connectWith = (provided: Record<string, string> | undefined) => {
      if (seq !== this.openSeq) return;
      const headers: Record<string, string> = { ...provided };
      if (cfg.apiKey) headers["x-api-key"] = cfg.apiKey;
      headers["x-project-id"] = cfg.projectId;
      // Logged by the relay, never used for a decision. It is what separates
      // one client build from another when a refusal shows up in the relay log
      // and every device otherwise looks alike. An app tag from the provider
      // stays in front of it, as on the pose channel's handshake.
      const build = `viro/${VIRO_VERSION} (${Platform.OS})`;
      const app = headers["x-rv-client"];
      headers["x-rv-client"] = app ? `${app} ${build}` : build;
      this.attach(
        new (WebSocket as unknown as HeaderWebSocket)(path, null, { headers })
      );
    };
    // A provider that cannot answer is treated as a dropped socket, so it
    // backs off and retries on the same ladder.
    const providerFailed = () => {
      if (seq === this.openSeq) this.retryOrFail();
    };

    let provided: Record<string, string> | PromiseLike<Record<string, string>>;
    try {
      provided = cfg.headers?.() ?? {};
    } catch {
      providerFailed();
      return;
    }
    // Synchronous answers connect synchronously, as a bare apiKey always has.
    if (isThenable(provided)) provided.then(connectWith, providerFailed);
    else connectWith(provided);
  }

  private attach(ws: WebSocket): void {
    this.ws = ws;

    ws.onopen = () => {
      this.attempt = 0;
      // State becomes synced on the welcome, not here: an open socket without a
      // snapshot has nothing to answer reads with.
      if (this.lastSeq >= 0)
        ws.send(JSON.stringify({ op: "resync", sinceSeq: this.lastSeq }));
    };

    ws.onmessage = (ev: { data: unknown }) => {
      if (typeof ev.data !== "string") return;
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(ev.data);
      } catch {
        return;
      }
      this.handle(msg);
    };

    const dropped = (ev?: { code?: number; reason?: string }) => {
      if (this.closedByUs || this.ws !== ws) return;
      this.ws = null;

      // Keyed on the reason, not the code: 1008 also carries rate-limited,
      // too-large and slow-consumer, and all three are meant to reconnect.
      // Only this one is a decision that will not change on a retry.
      if (ev?.reason === "auth-revoked") {
        this.fail("these credentials or this plan can no longer join the room");
        return;
      }
      this.retryOrFail();
    };
    ws.onclose = dropped;
    ws.onerror = () => dropped();
  }

  private retryOrFail(): void {
    if (this.attempt >= BACKOFF_MS.length) {
      this.fail("replication socket gave up reconnecting");
      return;
    }
    const delay = BACKOFF_MS[this.attempt++];
    this.setState("reconnecting");
    this.retryTimer = setTimeout(() => this.open(), delay);
  }

  private fail(error: string): void {
    this._error = error;
    this.setState("failed");
  }

  private handle(msg: Record<string, unknown>): void {
    switch (msg.t) {
      case "welcome":
        this._localPeerId = String(msg.you ?? "");
        this.replaceAll(
          msg.entities as ViroReplicatedEntity[],
          Number(msg.seq)
        );
        this.setState("synced");
        return;

      case "snapshot":
        // Arrives when a resync gap exceeded the server's retained history.
        this.replaceAll(
          msg.entities as ViroReplicatedEntity[],
          Number(msg.seq)
        );
        this.setState("synced");
        return;

      case "delta":
        this.applyDeltas((msg.ops ?? []) as AppliedOp[]);
        return;

      case "reject":
        this.rollback(
          msg as unknown as {
            ref?: string;
            reason: string;
            current?: ViroReplicatedEntity;
          }
        );
        return;
    }
  }

  private replaceAll(entities: ViroReplicatedEntity[], seq: number): void {
    this.entities.clear();
    for (const e of entities ?? []) this.entities.set(e.id, e);
    this.lastSeq = Number.isFinite(seq) ? seq : -1;
    this.pending.clear();
    this.emit();
  }

  private applyDeltas(ops: AppliedOp[]): void {
    for (const op of ops) {
      // A gap means a delta never arrived. Carrying on would leave this client
      // quietly describing state that no longer matches the room, so it stops
      // and asks for everything since what it does have.
      if (this.lastSeq >= 0 && op.seq > this.lastSeq + 1) {
        this.requestResync();
        return;
      }
      if (op.seq <= this.lastSeq) continue; // already applied

      if (op.kind === "upsert") {
        this.entities.set(op.entity.id, this.reconcile(op));
      } else if (op.kind === "delete") {
        this.entities.delete(op.id);
        // Same rule as an upsert: only this device's own op retires one of its
        // own writes. Without it another peer's delete, or anyone's `clear`,
        // would consume the record that holds the next echo back.
        if (op.by === this._localPeerId) this.settleOwnWrite(op.id);
      } else if (op.kind === "owner") {
        const e = this.entities.get(op.id);
        if (e)
          this.entities.set(op.id, {
            ...e,
            owner: op.owner,
            version: op.version,
          });
        else
          this.entities.set(op.id, {
            id: op.id,
            fields: {},
            owner: op.owner,
            version: op.version,
          });
      }
      this.lastSeq = op.seq;
    }
    this.emit();
  }

  /**
   * What an upsert should become locally, given what this device still has in
   * flight.
   *
   * The relay broadcasts to the sender as well, so a drag writing every 33 ms
   * over a 63 ms round trip has two more writes outstanding by the time the
   * first comes back. Taking that echo puts the object where the hand was two
   * writes ago, and the next write pulls it forward again: on the device doing
   * the dragging that reads as the object trailing the finger and snapping
   * back, the faster the drag the further back. Only the fields are held; the
   * version and owner the server assigned are adopted either way.
   */
  private reconcile(
    op: Extract<AppliedOp, { kind: "upsert" }>
  ): ViroReplicatedEntity {
    if (op.by !== this._localPeerId) return op.entity;
    if (!this.settleOwnWrite(op.entity.id)) return op.entity;
    const held = this.entities.get(op.entity.id);
    if (!held) return op.entity;
    // Server fields underneath, so a field only it knows about is not lost.
    return { ...op.entity, fields: { ...op.entity.fields, ...held.fields } };
  }

  /**
   * Retire the oldest optimistic write for `id`, reporting whether there was
   * one.
   *
   * A delta carries no ref, but the relay applies one connection's ops in the
   * order they were sent and broadcasts them in that order, so the nth echo
   * settles the nth write. This is also what bounds `pending`, which is why
   * nothing clears it wholesale: doing that on any delta dropped the record a
   * later rejection of an unrelated write needed to roll back.
   */
  private settleOwnWrite(id: string): boolean {
    for (const [ref, p] of this.pending) {
      if (p.id !== id) continue;
      this.pending.delete(ref);
      return true;
    }
    return false;
  }

  private requestResync(): void {
    if (this.ws?.readyState !== 1) return;
    this.ws.send(JSON.stringify({ op: "resync", sinceSeq: this.lastSeq }));
  }

  private rollback(msg: {
    ref?: string;
    reason: string;
    current?: ViroReplicatedEntity;
  }): void {
    if (msg.ref && this.pending.has(msg.ref)) {
      const p = this.pending.get(msg.ref)!;
      this.pending.delete(msg.ref);

      // Prefer the server's current value over the local pre-write one: it is
      // newer, and it is what the caller needs in order to retry sensibly.
      if (msg.current) {
        this.entities.set(msg.current.id, msg.current);
      } else if (p.before) {
        this.entities.set(p.id, p.before);
      } else {
        // Refused create: the server has no such entity, so neither should we.
        this.entities.delete(p.id);
      }
      this.emit();
    } else if (msg.current) {
      this.entities.set(msg.current.id, msg.current);
      this.emit();
    }

    this.onReject?.({
      reason: msg.reason as ViroReplicationRejectReason,
      current: msg.current,
    });
  }

  /** Called for every refused operation. */
  onReject?: (rejection: ViroReplicationRejection) => void;

  private send(op: Record<string, unknown>): string | null {
    if (this.ws?.readyState !== 1) return null;
    const ref = `r${++this.refCounter}`;
    const payload: Record<string, unknown> = { ...op, ref };
    if (payload.expectVersion === undefined) delete payload.expectVersion;
    this.ws.send(JSON.stringify(payload));
    return ref;
  }

  private setState(s: ViroReplicationState): void {
    if (this._state === s) return;
    this._state = s;
    this.emit();
  }

  private emit(): void {
    for (const fn of this.listeners) fn();
  }
}

type AppliedOp =
  | { kind: "upsert"; seq: number; entity: ViroReplicatedEntity; by: string }
  | { kind: "delete"; seq: number; id: string; by: string }
  | {
      kind: "owner";
      seq: number;
      id: string;
      owner: string | null;
      version: number;
      by: string;
    };

/**
 * Copyright (c) 2017-present, Viro Media, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */
import { ViroSceneContext } from "../ViroSceneContext";
import * as React from "react";
import {
  findNodeHandle,
  NativeModules,
  NativeSyntheticEvent,
  requireNativeComponent,
} from "react-native";
// @ts-ignore
// The visionOS-safe resolver. Image.resolveAssetSource returns an empty uri there;
// see ViroAssetSource.ts for why, and what it falls back to.
import { resolveViroAssetSource as resolveAssetSource } from "../Utilities/ViroAssetSource";
import {
  ViroAmbientLightInfo,
  ViroAmbientLightUpdateEvent,
  ViroARAnchorFoundEvent,
  ViroARAnchorRemovedEvent,
  ViroARAnchorUpdatedEvent,
  ViroARHitTestResult,
  ViroARNodeReference,
  ViroARPointCloud,
  ViroARPointCloudUpdateEvent,
  ViroCameraARHitTest,
  ViroCameraARHitTestEvent,
  ViroCameraTransform,
  ViroCameraTransformEvent,
  ViroPlatformInfo,
  ViroPlatformUpdateEvent,
  ViroTrackingReason,
  ViroTrackingState,
  ViroTrackingUpdatedEvent,
} from "../Types/ViroEvents";
import {
  Viro3DPoint,
  ViroPhysicsWorld,
  ViroRay,
  ViroRotation,
  ViroScale,
  ViroSoundRoom,
  ViroSource,
} from "../Types/ViroUtils";
import { ViroBase } from "../ViroBase";
import { ViroTrackingStateConstants } from "../ViroConstants";
import { ViroCommonProps } from "./ViroCommonProps";
import { ViroActiveCameraTracker } from "../Utilities/ViroActiveCameraTracker";
import { isQuest, isVisionOS } from "../Utilities/ViroPlatform";
import { warnUnsupported } from "../Utilities/ViroUnsupported";
import { markARSceneRoot } from "../VisionOS/ViroImmersiveSpaceGate";
import { withMissingModuleFallback } from "../Utilities/ViroNativeModule";

const ViroCameraModule = withMissingModuleFallback(
  NativeModules.ViroCameraModule,
  "ViroCameraModule"
);

type Props = ViroCommonProps & {
  displayPointCloud?: {
    imageSource?: ViroSource;
    imageScale?: ViroScale;
    maxPoints?: number;
  };

  anchorDetectionTypes?: string[] | string;

  onCameraARHitTest?: (event: ViroCameraARHitTest) => void;
  onARPointCloudUpdate?: (pointCloud: ViroARPointCloud) => void;
  onCameraTransformUpdate?: (cameraTransform: ViroCameraTransform) => void;
  onTrackingUpdated?: (
    state: ViroTrackingState,
    reason: ViroTrackingReason
  ) => void;
  onPlatformUpdate?: (platformInfoViro: ViroPlatformInfo) => void;
  onAmbientLightUpdate?: (update: ViroAmbientLightInfo) => void;
  /**
   * Fired once when depth data (LiDAR or monocular depth estimation) first becomes
   * available for the session — i.e. hit tests can now return DepthPoints. Useful for
   * hiding an "initializing depth…" state instead of acting on early, inaccurate
   * feature points. On devices using monocular depth estimation, this can take a few
   * seconds after the AR screen appears while the model warms up.
   */
  onDepthReady?: () => void;
  /**
   * Describes the acoustic properties of the room around the user
   */
  soundRoom?: ViroSoundRoom;
  physicsWorld?: ViroPhysicsWorld;
  postProcessEffects?: string[];
  /**
   * Turns this scene's tone mapping pass on or off. It is on by default, applying
   * a Hable luminance-only curve that renders pure white at about 0.77 and makes
   * bright materials glow. Off passes colour through untouched.
   *
   * Prefer this over `hdrEnabled={false}` on the navigator when the goal is only
   * an untouched tone curve: PBR requires HDR, so switching HDR off drops every
   * PBR material back to Blinn and silently discards roughness, metalness and the
   * ambient occlusion map.
   */
  toneMappingEnabled?: boolean;

  /**
   * ##### DEPRECATION WARNING - this prop may be removed in future releases #####
   * @deprecated
   */
  onTrackingInitialized?: () => void;
};

type State = {
  /**
   * The React tag of the camera the scene draws from, or null for its default camera. It
   * reaches the native scene as a prop rather than through `VRTCameraModule` so that a camera
   * mounted between its siblings attaches: see `ViroActiveCameraTracker`.
   */
  activeCameraTag: number | null;
};

export class ViroARScene extends ViroBase<Props, State> {
  state: State = { activeCameraTag: null };
  onTrackingFirstInitialized = false;
  _unmounting = false;

  // One tracker for the component's life, so the context value is stable and the cameras do
  // not re-render on every render of the scene.
  _cameras = new ViroActiveCameraTracker((activeCameraTag) => {
    // A camera unmounting with the whole scene still reports in; the scene is past rendering.
    if (!this._unmounting) {
      this.setState({ activeCameraTag });
    }
  });

  componentWillUnmount() {
    this._unmounting = true;
  }

  _onCameraARHitTest = (
    event: NativeSyntheticEvent<ViroCameraARHitTestEvent>
  ) => {
    var hitTestEventObj = {
      hitTestResults: event.nativeEvent.hitTestResults,
      cameraOrientation: {
        position: [
          event.nativeEvent.cameraOrientation[0],
          event.nativeEvent.cameraOrientation[1],
          event.nativeEvent.cameraOrientation[2],
        ] as Viro3DPoint,
        rotation: [
          event.nativeEvent.cameraOrientation[3],
          event.nativeEvent.cameraOrientation[4],
          event.nativeEvent.cameraOrientation[5],
        ] as ViroRotation,
        forward: [
          event.nativeEvent.cameraOrientation[6],
          event.nativeEvent.cameraOrientation[7],
          event.nativeEvent.cameraOrientation[8],
        ] as Viro3DPoint,
        up: [
          event.nativeEvent.cameraOrientation[9],
          event.nativeEvent.cameraOrientation[10],
          event.nativeEvent.cameraOrientation[11],
        ] as Viro3DPoint,
      },
    };
    this.props.onCameraARHitTest &&
      this.props.onCameraARHitTest(hitTestEventObj);
  };

  _onARPointCloudUpdate = (
    event: NativeSyntheticEvent<ViroARPointCloudUpdateEvent>
  ) => {
    this.props.onARPointCloudUpdate &&
      this.props.onARPointCloudUpdate(event.nativeEvent.pointCloud);
  };

  _onCameraTransformUpdate = (
    event: NativeSyntheticEvent<ViroCameraTransformEvent>
  ) => {
    var cameraTransform = {
      // ** DEPRECATION WARNING ** The cameraTransform key will be deprecated in a future release,
      cameraTransform: {
        position: [
          event.nativeEvent.cameraTransform[0],
          event.nativeEvent.cameraTransform[1],
          event.nativeEvent.cameraTransform[2],
        ] as Viro3DPoint,
        rotation: [
          event.nativeEvent.cameraTransform[3],
          event.nativeEvent.cameraTransform[4],
          event.nativeEvent.cameraTransform[5],
        ] as ViroRotation,
        forward: [
          event.nativeEvent.cameraTransform[6],
          event.nativeEvent.cameraTransform[7],
          event.nativeEvent.cameraTransform[8],
        ] as Viro3DPoint,
        up: [
          event.nativeEvent.cameraTransform[9],
          event.nativeEvent.cameraTransform[10],
          event.nativeEvent.cameraTransform[11],
        ] as Viro3DPoint,
      },
      position: [
        event.nativeEvent.cameraTransform[0],
        event.nativeEvent.cameraTransform[1],
        event.nativeEvent.cameraTransform[2],
      ] as Viro3DPoint,
      rotation: [
        event.nativeEvent.cameraTransform[3],
        event.nativeEvent.cameraTransform[4],
        event.nativeEvent.cameraTransform[5],
      ] as ViroRotation,
      forward: [
        event.nativeEvent.cameraTransform[6],
        event.nativeEvent.cameraTransform[7],
        event.nativeEvent.cameraTransform[8],
      ] as Viro3DPoint,
      up: [
        event.nativeEvent.cameraTransform[9],
        event.nativeEvent.cameraTransform[10],
        event.nativeEvent.cameraTransform[11],
      ] as Viro3DPoint,
    };
    this.props.onCameraTransformUpdate &&
      this.props.onCameraTransformUpdate(cameraTransform);
  };

  _onPlatformUpdate = (
    event: NativeSyntheticEvent<ViroPlatformUpdateEvent>
  ) => {
    this.props.onPlatformUpdate &&
      this.props.onPlatformUpdate(event.nativeEvent.platformInfoViro);
  };

  // TODO VIRO-3172: Remove in favor of deprecating onTrackingInitialized
  componentDidMount() {
    this.onTrackingFirstInitialized = false;
  }

  _onTrackingUpdated = (
    event: NativeSyntheticEvent<ViroTrackingUpdatedEvent>
  ) => {
    if (this.props.onTrackingUpdated) {
      this.props.onTrackingUpdated(
        event.nativeEvent.state,
        event.nativeEvent.reason
      );
    }

    // TODO VIRO-3172: Remove in favor of deprecating onTrackingInitialized
    if (
      (event.nativeEvent.state == ViroTrackingStateConstants.TRACKING_LIMITED ||
        event.nativeEvent.state ==
          ViroTrackingStateConstants.TRACKING_NORMAL) &&
      !this.onTrackingFirstInitialized
    ) {
      this.onTrackingFirstInitialized = true;
      if (this.props.onTrackingInitialized) {
        this.props.onTrackingInitialized();
      }
    }
  };

  /**
   * ##### DEPRECATION WARNING - this prop may be removed in future releases #####
   * @deprecated
   */
  _onTrackingInitialized = (
    _event: NativeSyntheticEvent<ViroTrackingUpdatedEvent>
  ) => {
    this.props.onTrackingInitialized && this.props.onTrackingInitialized();
  };

  /**
   * Gives constant estimates of the ambient light as detected by the camera.
   * Returns object w/ "intensity" and "color" keys
   */
  _onAmbientLightUpdate = (
    event: NativeSyntheticEvent<ViroAmbientLightUpdateEvent>
  ) => {
    this.props.onAmbientLightUpdate &&
      this.props.onAmbientLightUpdate(event.nativeEvent.ambientLightInfo);
  };

  /**
   * Fired once when depth data first becomes available for hit testing.
   */
  _onDepthReady = (_event: NativeSyntheticEvent<{}>) => {
    this.props.onDepthReady && this.props.onDepthReady();
  };

  _onAnchorFound = (event: NativeSyntheticEvent<ViroARAnchorFoundEvent>) => {
    // TODO: this is in a different format than the other onAnchorFound methods
    this.props.onAnchorFound &&
      this.props.onAnchorFound(event.nativeEvent.anchor);
  };

  _onAnchorUpdated = (
    event: NativeSyntheticEvent<ViroARAnchorUpdatedEvent>
  ) => {
    // TODO: this is in a different format than the other onAnchorUpdated methods
    this.props.onAnchorUpdated &&
      this.props.onAnchorUpdated(event.nativeEvent.anchor);
  };

  _onAnchorRemoved = (
    event: NativeSyntheticEvent<ViroARAnchorRemovedEvent>
  ) => {
    // TODO: this is in a different format than the other onAnchorRemoved methods
    this.props.onAnchorRemoved &&
      this.props.onAnchorRemoved(event.nativeEvent.anchor);
  };

  findCollisionsWithRayAsync = async (
    from: Viro3DPoint,
    to: Viro3DPoint,
    closest: any,
    viroTag: string
  ) => {
    return await NativeModules.VRTSceneModule.findCollisionsWithRayAsync(
      findNodeHandle(this),
      from,
      to,
      closest,
      viroTag
    );
  };

  findCollisionsWithShapeAsync = async (
    from: Viro3DPoint,
    to: Viro3DPoint,
    shapeString: string,
    shapeParam: any,
    viroTag: string
  ) => {
    return await NativeModules.VRTSceneModule.findCollisionsWithShapeAsync(
      findNodeHandle(this),
      from,
      to,
      shapeString,
      shapeParam,
      viroTag
    );
  };

  performARHitTestWithRay = async (ray: ViroRay) => {
    return await NativeModules.VRTARSceneModule.performARHitTestWithRay(
      findNodeHandle(this),
      ray
    );
  };

  performARHitTestWithWorldPoints = async (
    origin: Viro3DPoint,
    destination: Viro3DPoint
  ) => {
    return await NativeModules.VRTARSceneModule.performARHitTestWithWorldPoints(
      findNodeHandle(this),
      origin,
      destination
    );
  };

  performARHitTestWithPosition = async (position: Viro3DPoint) => {
    return await NativeModules.VRTARSceneModule.performARHitTestWithPosition(
      findNodeHandle(this),
      position
    );
  };

  performARHitTestWithPoint = async (x: number, y: number) => {
    return await NativeModules.VRTARSceneModule.performARHitTestWithPoint(
      findNodeHandle(this),
      x,
      y
    );
  };

  /**
   * Create an AR anchor at the location of a hit test result.
   *
   * This method creates a persistent AR anchor that will be tracked by the
   * AR system. The anchor can be used to place virtual content that stays
   * in place as the user moves around.
   *
   * The returned node reference can be passed to a ViroARNode component
   * to attach 3D content (though ViroARNode is optional and not yet implemented).
   *
   * Note: Hit test results are only valid for 30 seconds. Call this method
   * soon after performing the hit test.
   *
   * @param hitResult The hit test result to create an anchor from
   * @returns Promise resolving to an AR node reference, or null if failed
   *
   * @example
   * ```tsx
   * // Perform hit test
   * const results = await arSceneRef.current.performARHitTestWithPoint(x, y);
   *
   * if (results.length > 0) {
   *   // Create anchor from first result
   *   const nodeRef = await arSceneRef.current.createAnchoredNode(results[0]);
   *
   *   if (nodeRef) {
   *     // Store reference for later use
   *     setAnchoredNodeRef(nodeRef);
   *     console.log('Anchor created:', nodeRef.anchorId);
   *   }
   * }
   * ```
   */
  createAnchoredNode = async (
    hitResult: ViroARHitTestResult
  ): Promise<ViroARNodeReference | null> => {
    if (!hitResult._hitResultId) {
      throw new Error(
        "Hit result does not have an ID. " +
          "Make sure you use a hit result from performARHitTest methods."
      );
    }

    try {
      const nodeRef =
        await NativeModules.VRTARSceneModule.createAnchoredNodeFromHitResult(
          hitResult._hitResultId,
          findNodeHandle(this)
        );

      return nodeRef;
    } catch (error) {
      console.error("Failed to create anchored node:", error);
      return null;
    }
  };

  /**
   * ##### DEPRECATION WARNING - this prop may be removed in future releases #####
   * @deprecated
   */
  // getCameraPositionAsync = async () => {
  //   console.warn(
  //     "[Viro] ViroScene.getCameraPositionAsync has been DEPRECATED. Please use getCameraOrientationAsync instead."
  //   );
  //   var orientation = await NativeModules.VRTCameraModule.getCameraOrientation(
  //     findNodeHandle(this)
  //   );
  //   var position = [orientation[0], orientation[1], orientation[2]];
  //   return position;
  // }

  getCameraOrientationAsync = async () => {
    var orientation = await NativeModules.VRTCameraModule.getCameraOrientation(
      findNodeHandle(this)
    );
    return {
      position: [orientation[0], orientation[1], orientation[2]],
      rotation: [orientation[3], orientation[4], orientation[5]],
      forward: [orientation[6], orientation[7], orientation[8]],
      up: [orientation[9], orientation[10], orientation[11]],
    };
  };

  getCameraPositionAsync = async () => {
    // TODO: Two functions with the same name??
    return await ViroCameraModule.getCameraPosition(findNodeHandle(this));
  };

  render() {
    // The AR view managers are excluded from the visionOS renderer, so ViroARScene has no
    // native half there and mounting it would crash rather than render nothing.
    if (isVisionOS) {
      warnUnsupported(
        "ViroARScene",
        "Apple Vision Pro",
        "Use ViroScene instead: visionOS composes the passthrough world itself."
      );
      // Tells an enclosing ViroXRSceneNavigator not to open the ImmersiveSpace. It renders before
      // this and reads the answer in its mount effect, which runs after.
      markARSceneRoot();
      return null;
    }
    // On Meta Quest, ViroARScene renders as a mixed-reality scene through the
    // OpenXR renderer (passthrough + XR_FB_scene plane anchors). No longer gated.
    // Uncomment this line to check for misnamed props
    //checkMisnamedProps("ViroARScene", this.props);

    // Since anchorDetectionTypes can be either a string or an array, convert the string to a 1-element array.
    let anchorDetectionTypes =
      typeof this.props.anchorDetectionTypes === "string"
        ? new Array(this.props.anchorDetectionTypes)
        : this.props.anchorDetectionTypes ?? ["planesHorizontal", "planesVertical"];

    let timeToFuse = undefined;
    if (
      this.props.onFuse != undefined &&
      typeof this.props.onFuse === "object"
    ) {
      timeToFuse = this.props.onFuse.timeToFuse;
    }

    let displayPointCloud = false;
    let pointCloudImage = undefined;
    let pointCloudScale = undefined;
    let pointCloudMaxPoints = undefined;
    // parse out displayPointCloud prop
    if (this.props.displayPointCloud) {
      displayPointCloud = true;
      pointCloudImage = resolveAssetSource(
        this.props.displayPointCloud.imageSource
      );
      pointCloudScale = this.props.displayPointCloud.imageScale;
      pointCloudMaxPoints = this.props.displayPointCloud.maxPoints;
    }

    if (this.props.onTrackingInitialized && !this.onTrackingFirstInitialized) {
      console.warn(
        "[Viro] ViroARScene.onTrackingInitialized() has been DEPRECATED. Please use onTrackingUpdated() instead."
      );
    }

    return (
      <ViroSceneContext.Provider value={this._cameras}>
        <VRTARScene
          {...this.props}
          activeCameraTag={this.state.activeCameraTag}
          canHover={(this.props.onHover != undefined || this.props.onGaze != undefined)}
          canClick={
            this.props.onClick != undefined ||
            this.props.onClickState != undefined
          }
          canTouch={this.props.onTouch != undefined}
          canScroll={this.props.onScroll != undefined}
          canSwipe={this.props.onSwipe != undefined}
          canDrag={this.props.onDrag != undefined}
          canPinch={this.props.onPinch != undefined}
          canRotate={this.props.onRotate != undefined}
          canFuse={this.props.onFuse != undefined}
          canCameraARHitTest={this.props.onCameraARHitTest != undefined}
          canARPointCloudUpdate={this.props.onARPointCloudUpdate != undefined}
          canCameraTransformUpdate={
            this.props.onCameraTransformUpdate != undefined
          }
          onHoverViro={this._onHover}
          onClickViro={this._onClickState}
          onClick={undefined}
          onTouchViro={this._onTouch}
          onScrollViro={this._onScroll}
          onSwipeViro={this._onSwipe}
          onDragViro={this._onDrag}
          onPinchViro={this._onPinch}
          onRotateViro={this._onRotate}
          onFuseViro={this._onFuse}
          onCameraARHitTestViro={this._onCameraARHitTest}
          onARPointCloudUpdateViro={this._onARPointCloudUpdate}
          onCameraTransformUpdateViro={this._onCameraTransformUpdate}
          onPlatformUpdateViro={this._onPlatformUpdate}
          onTrackingUpdatedViro={this._onTrackingUpdated}
          onAmbientLightUpdateViro={this._onAmbientLightUpdate}
          onDepthReadyViro={this._onDepthReady}
          onAnchorFoundViro={this._onAnchorFound}
          onAnchorUpdatedViro={this._onAnchorUpdated}
          onAnchorRemovedViro={this._onAnchorRemoved}
          timeToFuse={timeToFuse}
          anchorDetectionTypes={anchorDetectionTypes}
          displayPointCloud={displayPointCloud}
          pointCloudImage={pointCloudImage}
          pointCloudScale={pointCloudScale}
          pointCloudMaxPoints={pointCloudMaxPoints}
        />
      </ViroSceneContext.Provider>
    );
  }
}

var VRTARScene = requireNativeComponent<any>(
  "VRTARScene",
  // @ts-ignore
  ViroARScene,
  {
    nativeOnly: {
      canHover: true,
      canClick: true,
      canTouch: true,
      canScroll: true,
      canSwipe: true,
      canDrag: true,
      canPinch: true,
      canRotate: true,
      canFuse: true,
      canCameraARHitTest: true,
      canARPointCloudUpdate: true,
      canCameraTransformUpdate: true,
      onHoverViro: true,
      onClickViro: true,
      onTouchViro: true,
      onScrollViro: true,
      onSwipeViro: true,
      onDragViro: true,
      onPinchViro: true,
      onRotateViro: true,
      onFuseViro: true,
      onPlatformUpdateViro: true,
      onTrackingInitializedViro: true,
      onTrackingUpdatedViro: true,
      onAmbientLightUpdateViro: true,
      onDepthReadyViro: true,
      onAnchorFoundViro: true,
      onAnchorUpdatedViro: true,
      onAnchorRemovedViro: true,
      onCameraARHitTestViro: true,
      onARPointCloudUpdateViro: true,
      onCameraTransformUpdateViro: true,
      timeToFuse: true,
      pointCloudImage: true,
      pointCloudScale: true,
      pointCloudMaxPoints: true,
      activeCameraTag: true,
    },
  }
);

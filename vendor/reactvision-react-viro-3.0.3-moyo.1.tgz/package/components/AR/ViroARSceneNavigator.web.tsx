/**
 * Web implementation of ViroARSceneNavigator. Owns the <canvas> + ViroWebRenderer
 * (WASM host, virocore) and drives a ViroArSession which runs slam-wasm to track
 * the device and inject poses into the renderer. Scenes render their children as
 * C-API-backed nodes via context, exactly like Viro3DSceneNavigator.web.
 *
 * Web AR needs a user gesture: getUserMedia and (on iOS Safari) DeviceMotion
 * permission can only be requested from a tap. So we render a "Start AR" overlay
 * and begin tracking on tap.
 *
 * The tracking engine is loaded as a classic <script> exposing a global
 * `SlamModule` factory (MODULARIZE + EXPORT_NAME='SlamModule'). That engine is
 * tinyvio, built through its platforms/slam drop-in C API — the name is the
 * interface's, not the implementation's, and keeping it is why this file did
 * not change when the engine did. Override via `loadSlam` for ESM setups.
 *
 * MVP scope: single scene; camera + 6-DoF pose tracking. Planes/hit-test are a
 * follow-up.
 */
import * as React from "react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ViroArSession,
  ViroTrackingState,
  TrackingReason,
  requestDeviceMotionPermission,
  type ViroHandle,
  type ViroWebRendererOptions,
  type ViroArSessionOptions,
  type SlamWasmFactory,
} from "@reactvision/viro-web-renderer";
import {
  ViroRendererContext,
  ViroParentNodeContext,
  ViroARContext,
} from "../Web/ViroWebContext";
import type { ArPlaneAnchor } from "@reactvision/viro-web-renderer";
import { useViroWebRenderer } from "../Web/viroRendererHost";
import {
  useViroRendererEffects,
  type ViroRendererEffectProps,
} from "../Web/useViroRendererEffects";
import { useViroReticle, type ViroReticleProps } from "../Web/useViroReticle";

/** AR capture/tuning knobs forwarded to the ViroArSession. */
type ArOptions = Partial<
  Pick<
    ViroArSessionOptions,
    | "captureWidth"
    | "captureHeight"
    | "feedWidth"
    | "feedHeight"
    | "poseSmoothing"
    | "facingMode"
    | "intrinsics"
    | "intrinsicsSize"
    | "tuning"
    | "showCameraBackground"
    | "detectPlanes"
    | "maxPlanes"
    | "renderWhileLimited"
    | "playback"
  >
>;

type Props = {
  initialScene: { scene: React.ComponentType<any> };
  viroAppProps?: any;
  /** WASM renderer asset-loading options (bundler/ESM). See Viro3DSceneNavigator.web. */
  webRendererOptions?: Omit<ViroWebRendererOptions, "canvas">;
  /**
   * URL to the tracking engine's glue (tinyvio-slam.js), injected as a <script>.
   *
   * Optional. `@reactvision/viro-web-renderer` ships the engine, and that copy
   * is used when neither this nor `loadSlam` is given. Set this only to serve a
   * different build, or one hosted somewhere your bundler put it.
   */
  slamScriptUrl?: string;
  /** Override how the tracking-engine factory is obtained (e.g. an ESM import()). */
  loadSlam?: ViroArSessionOptions["loadSlam"];
  /** Capture/tuning options for tracking. */
  arOptions?: ArOptions;
  /**
   * Called once the AR session is running, with the session itself.
   *
   * For hosts that drive the session rather than only observe it — replaying a
   * recording means stepping frames by hand, which needs the session object.
   * Live hosts do not need this; the session is also on ViroARContext.
   */
  onSessionReady?: (session: ViroArSession) => void;
  /** Overlay label for the start button. */
  startLabel?: string;
  /**
   * Called when AR cannot track for want of motion data: the viewer denied
   * motion access (the session is then not started), or it was granted and no
   * events arrive. The tracker needs gravity from the IMU before it can start,
   * so without motion it never leaves "initializing".
   */
  onMotionUnavailable?: (reason: "denied" | "no-events") => void;
  [key: string]: any;
} & ViroRendererEffectProps &
  ViroReticleProps;

const containerStyle: React.CSSProperties = {
  position: "relative",
  width: "100%",
  height: "100%",
  overflow: "hidden",
};
const canvasStyle: React.CSSProperties = {
  display: "block",
  width: "100%",
  height: "100%",
  touchAction: "none",
};
const overlayStyle: React.CSSProperties = {
  position: "absolute",
  inset: 0,
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  gap: 12,
  background: "rgba(0,0,0,0.55)",
  color: "#fff",
  font: "500 16px system-ui, sans-serif",
  textAlign: "center",
  padding: 24,
};
const buttonStyle: React.CSSProperties = {
  padding: "12px 28px",
  fontSize: 16,
  fontWeight: 600,
  color: "#000",
  background: "#fff",
  border: "none",
  borderRadius: 999,
  cursor: "pointer",
};
const statusStyle: React.CSSProperties = {
  position: "absolute",
  top: 12,
  left: "50%",
  transform: "translateX(-50%)",
  padding: "6px 14px",
  borderRadius: 999,
  background: "rgba(0,0,0,0.5)",
  color: "#fff",
  font: "500 13px system-ui, sans-serif",
  pointerEvents: "none",
};

// Load slam-wasm as a classic script exposing a global `SlamModule` factory.
let slamScriptPromise: Promise<SlamWasmFactory> | null = null;
function loadSlamViaScript(url: string): Promise<SlamWasmFactory> {
  if (slamScriptPromise) return slamScriptPromise;
  slamScriptPromise = new Promise<SlamWasmFactory>((resolve, reject) => {
    const existing = (globalThis as any).SlamModule as SlamWasmFactory | undefined;
    if (existing) {
      resolve(existing);
      return;
    }
    const script = document.createElement("script");
    script.src = url;
    script.async = true;
    script.onload = () => {
      const factory = (globalThis as any).SlamModule as SlamWasmFactory | undefined;
      if (factory) resolve(factory);
      else reject(new Error(`slam script loaded but global 'SlamModule' is missing: ${url}`));
    };
    script.onerror = () => reject(new Error(`failed to load slam script: ${url}`));
    document.head.appendChild(script);
  });
  return slamScriptPromise;
}

/*
 * A status readout, so it reports the state rather than guessing at a cause.
 * Limited is not only a startup condition — ARKit and ARCore also report it for
 * poor light or fast motion — so calling it "initializing" would be wrong every
 * time it happens mid-session.
 */
const MOTION_DENIED =
  "Motion access was denied. AR needs the motion sensors to track: allow " +
  "Motion & Orientation Access for this site and try again.";
const MOTION_MISSING = "No motion sensor data. AR can't start tracking on this device.";
/** How long NoGravity may last before the tracker is taken to have no IMU. */
const NO_MOTION_AFTER_MS = 3000;

function trackingLabel(state: ViroTrackingState): string {
  switch (state) {
    case ViroTrackingState.Normal:
      return "Tracking";
    case ViroTrackingState.Limited:
      return "Tracking limited";
    default:
      return "No tracking";
  }
}

export function ViroARSceneNavigator(props: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<ViroArSession | null>(null);

  const [started, setStarted] = useState(false);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tracking, setTracking] = useState<ViroTrackingState>(ViroTrackingState.Unavailable);
  const [motionMissing, setMotionMissing] = useState(false);
  const noGravitySinceRef = useRef<number | null>(null);
  const motionMissingRef = useRef(false);
  const [anchors, setAnchors] = useState<ArPlaneAnchor[]>([]);

  // One renderer per canvas, kept across StrictMode's unmount/remount and torn
  // down (render loop included) on a real unmount. See viroRendererHost.
  const renderer = useViroWebRenderer(canvasRef, props.webRendererOptions, (err) => {
    console.error("[Viro web AR] failed to initialize renderer:", err);
    setError("Could not initialize the renderer.");
  });
  useViroRendererEffects(renderer, props);
  useViroReticle(renderer, props);
  const rootNode = useMemo<ViroHandle>(
    () => (renderer ? renderer.scene.getRootNode() : 0),
    [renderer],
  );

  // The camera session ends with the navigator.
  useEffect(
    () => () => {
      sessionRef.current?.stop();
      sessionRef.current = null;
    },
    [],
  );

  // Keep the renderer's viewport in sync with the canvas size.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!renderer || !canvas) return;
    const observer = new ResizeObserver(() => renderer.resize());
    observer.observe(canvas);
    renderer.resize();
    return () => observer.disconnect();
  }, [renderer]);

  const resolveLoadSlam = useCallback((): ViroArSessionOptions["loadSlam"] => {
    if (props.loadSlam) return props.loadSlam;
    const url = props.slamScriptUrl;
    if (url) return () => loadSlamViaScript(url);
    // Neither given: let the renderer load the engine it ships with. Returning
    // undefined is what selects that path -- it is the default, not a failure.
    // A host that injected the <script> itself is still served, because the
    // bundled loader reuses an existing `SlamModule` global rather than
    // fetching a second copy of a 265 KB module to arrive at the same object.
    return undefined;
  }, [props.loadSlam, props.slamScriptUrl]);

  const startAR = useCallback(async () => {
    if (!renderer || starting || started) return;
    setStarting(true);
    setError(null);
    // Replay needs neither: no camera to open, no motion events to subscribe to.
    // Asking anyway would put a permission prompt in front of a preview that
    // cannot use the answer.
    if (!props.arOptions?.playback) {
      // Request DeviceMotion permission from within this tap (required on iOS).
      // The answer used to be ignored: a denial started the session anyway,
      // with no IMU, and the tracker then never left "initializing" while the
      // screen said nothing about why. renderWhileLimited is the one caller
      // that wants to go on regardless (a desktop preview has no IMU at all).
      const motion = await requestDeviceMotionPermission();
      if (!motion && !props.arOptions?.renderWhileLimited) {
        setError(MOTION_DENIED);
        setStarting(false);
        props.onMotionUnavailable?.("denied");
        return;
      }
    }
    noGravitySinceRef.current = null;
    motionMissingRef.current = false;
    setMotionMissing(false);
    const session = new ViroArSession({
      sceneApi: renderer.scene,
      loadSlam: resolveLoadSlam(),
      ...props.arOptions,
      onStatus: (state, _quality, detail) => {
        setTracking(state);
        // Granted is not the same as arriving: some browsers grant and then
        // deliver nothing. NoGravity past a few seconds means no IMU at all.
        if (detail?.reason === TrackingReason.NoGravity) {
          const now = performance.now();
          noGravitySinceRef.current ??= now;
          if (!motionMissingRef.current && now - noGravitySinceRef.current > NO_MOTION_AFTER_MS) {
            motionMissingRef.current = true;
            setMotionMissing(true);
            props.onMotionUnavailable?.("no-events");
          }
        } else if (noGravitySinceRef.current !== null) {
          noGravitySinceRef.current = null;
          motionMissingRef.current = false;
          setMotionMissing(false);
        }
      },
      onAnchorsUpdated: (next) => setAnchors(next),
      onError: (err) => {
        console.error("[Viro web AR] session error:", err);
        setError(err.message);
        setStarted(false);
        setStarting(false);
      },
    });
    sessionRef.current = session;
    // start() rejects when it cannot start, having already called onError with
    // the reason. Swallow the rejection here rather than letting it escape an
    // onClick handler, and above all do not fall through to setStarted(true):
    // that used to run even on a denied camera, undoing the state onError had
    // just set and leaving the UI claiming a session that does not exist.
    try {
      await session.start();
    } catch {
      sessionRef.current = null;
      return;
    }
    setStarted(true);
    setStarting(false);
    props.onSessionReady?.(session);
  }, [
    renderer,
    starting,
    started,
    resolveLoadSlam,
    props.arOptions,
    props.onSessionReady,
    props.onMotionUnavailable,
  ]);

  // Replay starts on its own. The button exists to satisfy a browser that will
  // not open a camera without a gesture; there is no camera here, and a preview
  // that waits for a click nobody is there to make would simply never render.
  useEffect(() => {
    // Waits for rootNode, not just for the renderer: the live path starts from a
    // tap, which happens long after the scene has mounted, and matching that
    // ordering costs nothing.
    if (props.arOptions?.playback && renderer && rootNode && !started && !starting) {
      void startAR();
    }
  }, [props.arOptions?.playback, renderer, rootNode, started, starting, startAR]);

  const SceneComponent = props.initialScene?.scene;

  const sceneNavigator = {
    push: () => {},
    pop: () => {},
    popN: () => {},
    jump: () => {},
    replace: () => {},
    viroAppProps: props.viroAppProps ?? {},
  };

  return (
    <div style={containerStyle}>
      <canvas ref={canvasRef} style={canvasStyle} />

      {renderer && rootNode && SceneComponent ? (
        <ViroRendererContext.Provider value={renderer}>
          <ViroARContext.Provider
            value={{ session: sessionRef.current, anchors, trackingState: tracking }}
          >
            <ViroParentNodeContext.Provider value={rootNode}>
              <SceneComponent sceneNavigator={sceneNavigator} {...props.viroAppProps} />
            </ViroParentNodeContext.Provider>
          </ViroARContext.Provider>
        </ViroRendererContext.Provider>
      ) : null}

      {started ? (
        <div style={statusStyle}>
          {motionMissing && !props.arOptions?.renderWhileLimited
            ? MOTION_MISSING
            : trackingLabel(tracking)}
        </div>
      ) : (
        <div style={overlayStyle}>
          {error ? <div style={{ color: "#ff8080" }}>{error}</div> : null}
          <div>{props.startLabel ?? "AR needs access to your camera."}</div>
          <button
            type="button"
            style={buttonStyle}
            disabled={!renderer || starting}
            onClick={startAR}
          >
            {starting ? "Starting…" : "Start AR"}
          </button>
        </div>
      )}
    </div>
  );
}

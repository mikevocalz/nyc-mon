/**
 * What a scene asks for that the web host cannot draw or run.
 *
 * `StudioARScene.web` reports this through `onUnsupported` so the caller can put
 * a banner over the scene, and Studio's publish flow warns against the same
 * list. It only earns that if it is complete: a gap that is not listed here
 * reaches the viewer as a scene that opens correctly and then does nothing,
 * which reads as a bug in the content rather than a limit of the surface.
 *
 * Each entry is a feature the host actively drops, not one it renders
 * differently. Approximations belong in the component that makes them.
 */
import type { StudioSceneResponse } from "../types";
import { isTapToPlaceAsset } from "./placementStore";

/** Whether the host wraps the scene's assets in a ViroARPlane. */
export function usesPlaneWrapper(
  planeDetection: string | null | undefined,
  mode: "ar" | "3d",
): boolean {
  if (mode !== "ar") return false;
  const detection = (planeDetection ?? "NONE").toUpperCase();
  return detection === "AUTOMATIC" || detection === "MANUAL";
}

export function webUnsupportedFeatures(
  sceneData: StudioSceneResponse,
  /** "3d" has no camera to hit-test against, so guided placement cannot run. */
  mode: "ar" | "3d" = "ar",
): string[] {
  const { scene, assets } = sceneData;
  const features: string[] = [];

  // The node factory's marker assets are filtered out of the tree entirely.
  if (assets.some((a) => a.trigger_image_url)) features.push("image markers");

  // Physics runs on web now: Bullet is in the binary and the host drives it.

  // Gaze is a headset affordance: the native host wires it on Quest only, and a
  // browser has no gaze ray either. Standing a mouse hover in for it would give
  // web a behaviour no phone has, which is the opposite of parity.
  if (sceneData.gaze_bindings?.length) features.push("gaze triggers");

  // Proximity runs everywhere now: the host reads each target's world position
  // off its renderer handle, so a plane-local authored position is no longer
  // what the metres are measured from.

  // Collision triggers ride the physics world, so they run wherever it does.

  // Guided placement needs a tracked camera to hit-test a tap against, so it
  // runs in AR and nowhere else. In 3d the queue would never advance and the
  // assets would stay hidden for the whole scene.
  if (mode !== "ar" && assets.some(isTapToPlaceAsset)) {
    features.push("tap to place");
  }

  if (((scene.plane_detection as string) ?? "").toUpperCase() === "MANUAL") {
    features.push("manual plane selection");
  }

  return features;
}

/**
 * Copyright (c) 2021-present, Viro Media, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * To do
 * - source types
 * - clickState types
 */

import {
  ViroARTrackingReasonConstants,
  ViroTrackingStateConstants,
} from "../ViroConstants";
import { Viro3DPoint, ViroRotation } from "./ViroUtils";

export type ViroHoverEvent = {
  isHovering: boolean;
  position: Viro3DPoint;
  source: number;
};

export type ViroClickEvent = {
  position: Viro3DPoint;
  source: number;
};

export type ViroClickStateEvent = {
  clickState: ViroClickState;
  position: Viro3DPoint;
  source: number;
};

export type ViroClickState =
  | ViroClickStateTypes.CLICK_DOWN
  | ViroClickStateTypes.CLICK_UP
  | ViroClickStateTypes.CLICKED;

export enum ViroClickStateTypes {
  CLICK_DOWN = 1, // Click Down: Triggered when the user has performed a click down action while hovering on this control.|
  CLICK_UP = 2, // Click Up: Triggered when the user has performed a click up action while hovering on this control.|
  CLICKED = 3, // Clicked: Triggered when the user has performed both a click down and click up action on this control sequentially, thereby having "Clicked" the object.|
}

export type ViroTouchEvent = {
  touchState: any; // TODO: is there a better type for this?
  touchPos: Viro3DPoint;
  source: number;
};

export type ViroScrollEvent = {
  scrollPos: Viro3DPoint;
  source: number;
};

export type ViroSwipeEvent = {
  swipeState: any; // TODO: is there a better type for this?
  source: number;
};

export type ViroFuseEvent = {
  source: number;
};

export type ViroPinchEvent = {
  pinchState: ViroPinchState;
  scaleFactor: number;
  source: number;
};

export type ViroPinchState =
  | ViroPinchStateTypes.PINCH_START
  | ViroPinchStateTypes.PINCH_MOVE
  | ViroPinchStateTypes.PINCH_END;

export enum ViroPinchStateTypes {
  PINCH_START = 1, // Triggered when the user has started a pinch gesture.
  PINCH_MOVE = 2, // Triggered when the user has adjusted the pinch, moving both fingers.
  PINCH_END = 3, //  When the user has finishes the pinch gesture and released both touch points.
}

export type ViroRotateEvent = {
  rotateState: ViroRotateState;
  rotationFactor: number; // TODO: confirm this type is correct
  source: number;
};

export type ViroRotateState =
  | ViroRotateStateTypes.ROTATE_START
  | ViroRotateStateTypes.ROTATE_MOVE
  | ViroRotateStateTypes.ROTATE_END;

export enum ViroRotateStateTypes {
  ROTATE_START = 1, // Triggered when the user has started a rotation gesture.
  ROTATE_MOVE = 2, // Triggered when the user has adjusted the rotation, moving both fingers.
  ROTATE_END = 3, //  When the user has finishes the rotation gesture and released both touch points.
}

export type ViroDragEvent = {
  dragToPos: Viro3DPoint;
  source: number;
};

export type ViroPlatformEvent = {
  platformInfoViro: ViroPlatformInfo;
};

export type ViroCollisionEvent = {
  viroTag: string;
  collidedPoint: Viro3DPoint;
  collidedNormal: Viro3DPoint;
};

/**
 * Platform information for the current device.
 *
 * | |iOS Cardboard|Android Cardboard| Daydream | GearVR
 * |-------------------|---------------|---------------|---------------|---------------|
 * |Platform|gvr|gvr|gvr|ovr-mobile|
 * |Headset|cardboard|cardboard|daydream|gearvr|
 * |Controller|cardboard|cardboard|daydream|gearvr|
 */
export type ViroPlatformInfo = {
  platform: ViroPlatformTypes;
  /** @deprecated */
  vrPlatform: ViroPlatformTypes;
  headset: ViroHeadsetTypes;
  controller: ViroControllerTypes;
};

export enum ViroPlatformTypes {
  GVR = "gvr",
  GEAR_VR = "ovr-mobile",
  QUEST = "quest",
}

export enum ViroHeadsetTypes {
  CARDBOARD = "cardboard",
  DAYDREAM = "daydream",
  GEARVR = "gearvr",
}

export enum ViroControllerTypes {
  CARDBOARD = "cardboard",
  DAYDREAM = "daydream",
  GEARVR = "gearvr",
}

export type ViroCameraTransformEvent = {
  cameraTransform: number[];
};

export type ViroPlatformUpdateEvent = {
  platformInfoViro: ViroPlatformInfo;
};

export type ViroCameraTransform = {
  /** @deprecated The cameraTransform key will be deprecated in a future release */
  cameraTransform: {
    position: Viro3DPoint;
    rotation: ViroRotation;
    forward: Viro3DPoint;
    up: Viro3DPoint;
  };
  position: Viro3DPoint;
  rotation: ViroRotation;
  forward: Viro3DPoint;
  up: Viro3DPoint;
};

export type ViroExitViroEvent = {};

export type ViroErrorEvent = {
  error: Error;
};

/** ===========================================================================
 * Quest / OpenXR Hand Tracking Types (M4)
 * ============================================================================ */

export type ViroJoint = {
  position: Viro3DPoint;
  /** Sphere radius representing finger pad size (meters). */
  radius: number;
};

export type ViroHandJoints = {
  wrist: ViroJoint;
  thumbMetacarpal: ViroJoint;
  thumbProximal: ViroJoint;
  thumbDistal: ViroJoint;
  thumbTip: ViroJoint;
  indexMetacarpal: ViroJoint;
  indexProximal: ViroJoint;
  indexIntermediate: ViroJoint;
  indexDistal: ViroJoint;
  indexTip: ViroJoint;
  middleMetacarpal: ViroJoint;
  middleProximal: ViroJoint;
  middleIntermediate: ViroJoint;
  middleDistal: ViroJoint;
  middleTip: ViroJoint;
  ringMetacarpal: ViroJoint;
  ringProximal: ViroJoint;
  ringIntermediate: ViroJoint;
  ringDistal: ViroJoint;
  ringTip: ViroJoint;
  littleMetacarpal: ViroJoint;
  littleProximal: ViroJoint;
  littleIntermediate: ViroJoint;
  littleDistal: ViroJoint;
  littleTip: ViroJoint;
};

export type ViroHandPinchEvent = {
  hand: "left" | "right";
  /** World-space position of the pinch point (midpoint between thumb tip and index tip). */
  position: Viro3DPoint;
  /** Pinch strength [0..1] from XR_FB_hand_tracking_aim, or 1.0 on pinch-complete fallback. */
  pinchStrength: number;
};

/** Per-frame skeletal hand data dispatched via onHandUpdate. null when hand is not tracked. */
export type ViroHandUpdateEvent = {
  left: ViroHandJoints | null;
  right: ViroHandJoints | null;
};

/** ===========================================================================
 * Viro Animation Events
 * ============================================================================ */
export type ViroAnimationStartEvent = {};
export type ViroAnimationFinishEvent = {};

/** ===========================================================================
 * Viro Loading Events
 * ============================================================================ */
export type ViroLoadStartEvent = {};
export type ViroLoadEndEvent = {
  success: boolean;
};
export type ViroLoadErrorEvent = ViroErrorEvent;

/** ===========================================================================
 * Viro 360 Video Events
 * ============================================================================ */
export type ViroVideoBufferStartEvent = {};
export type ViroVideoBufferEndEvent = {};
export type ViroVideoUpdateTimeEvent = {
  currentTime: number;
  totalTime: number;
};
export type ViroVideoErrorEvent = ViroErrorEvent;
export type ViroVideoFinishEvent = ViroErrorEvent;

/** ===========================================================================
 * Viro Animated Component Events
 * ============================================================================ */
export type ViroAnimatedComponentStartEvent = {};
export type ViroAnimatedComponentFinishEvent = {};

/** ===========================================================================
 * Viro AR Anchor Events
 * ============================================================================ */

/**
 * Classification of detected planes.
 * iOS 12+ provides ML-based classification via ARKit.
 * Android provides basic inference from plane orientation.
 */
export type ViroARPlaneClassification =
  | "None"
  | "Wall"
  | "Floor"
  | "Ceiling"
  | "Table"
  | "Seat"
  | "Door"
  | "Window"
  | "Unknown";

/**
 * Alignment of detected planes with respect to gravity.
 */
export type ViroARPlaneAlignment =
  | "Horizontal"
  | "HorizontalUpward"
  | "HorizontalDownward"
  | "Vertical";

/**
 * Represents an AR anchor detected in the real world.
 */
export type ViroAnchor = {
  anchorId: string;
  type: "anchor" | "plane" | "image";
  position: [number, number, number];
  rotation: [number, number, number]; // In degrees
  scale: [number, number, number];
  // Plane-specific properties (present when type === "plane")
  center?: [number, number, number];
  width?: number;
  height?: number;
  alignment?: ViroARPlaneAlignment;
  classification?: ViroARPlaneClassification;
  vertices?: Array<[number, number, number]>;
  // Image-specific properties (present when type === "image")
  trackingMethod?: string;
};

export type ViroAnchorFoundMap = ViroAnchor;
export type ViroAnchorUpdatedMap = ViroAnchor;

export type ViroARAnchorRemovedEvent = {
  anchor: ViroAnchor;
};
export type ViroARAnchorUpdatedEvent = {
  anchorUpdatedMap: ViroAnchorUpdatedMap;
  anchor: ViroAnchor;
};
export type ViroARAnchorFoundEvent = {
  anchorFoundMap: ViroAnchorFoundMap;
  anchor: ViroAnchor;
};

/** ===========================================================================
 * Viro AR Plane Events
 * ============================================================================ */
export type ViroPlaneUpdatedMap = ViroAnchor;
export type ViroPlaneUpdatedEvent = any;
export type ViroARPlaneSizes = any;

/** ===========================================================================
 * Viro AR Hit Test
 * ============================================================================ */
export type ViroCameraARHitTestEvent = {
  hitTestResults: ViroARHitTestResult[];
  cameraOrientation: number[];
};
export type ViroCameraARHitTest = {
  hitTestResults: ViroARHitTestResult[];
  cameraOrientation: {
    position: Viro3DPoint;
    rotation: ViroRotation;
    forward: Viro3DPoint;
    up: Viro3DPoint;
  };
};

export type ViroARHitTestResult = {
  type:
    | "ExistingPlaneUsingExtent"
    | "ExistingPlane"
    | "EstimatedHorizontalPlane"
    | "FeaturePoint"
    | "DepthPoint";
  transform: {
    position: Viro3DPoint;
    rotation: ViroRotation;
    scale: Viro3DPoint;
  };
  hasDepthData: boolean;
  depthValue?: number;
  depthConfidence?: number;
  depthSource?: "lidar" | "monocular" | "arcore" | "none";

  /** @internal - Hit result ID for anchor creation, auto-generated */
  _hitResultId?: string;
};

/**
 * Reference to an AR node created from a hit test result.
 * Used to track anchored nodes and access their properties.
 */
export type ViroARNodeReference = {
  /** Unique identifier for the node */
  nodeId: string;

  /** React tag for the native view */
  reactTag: number;

  /** ID of the associated AR anchor */
  anchorId?: string;

  /** Current transform of the anchored node */
  transform?: {
    position: Viro3DPoint;
    rotation: ViroRotation;
    scale: Viro3DPoint;
  };
};

export type ViroARPointCloudUpdateEvent = {
  pointCloud: ViroARPointCloud;
};

export type ViroARPointCloud = any;

export type ViroTrackingUpdatedEvent = {
  state: ViroTrackingState;
  reason: ViroTrackingReason;
};

export type ViroTrackingState =
  | ViroTrackingStateConstants.TRACKING_NORMAL
  | ViroTrackingStateConstants.TRACKING_LIMITED
  | ViroTrackingStateConstants.TRACKING_UNAVAILABLE;

export type ViroTrackingReason =
  | ViroARTrackingReasonConstants.TRACKING_REASON_NONE
  | ViroARTrackingReasonConstants.TRACKING_REASON_EXCESSIVE_MOTION
  | ViroARTrackingReasonConstants.TRACKING_REASON_INSUFFICIENT_FEATURES;

export type ViroAmbientLightUpdateEvent = {
  ambientLightInfo: ViroAmbientLightInfo;
};

export type ViroAmbientLightInfo = {
  intensity: number; // TODO: This might not be right
  color: string;
};

export type ViroWorldOrigin = {
  position: Viro3DPoint;
  rotation: ViroRotation;
};

export type ViroNativeTransformUpdateEvent = {
  position: Viro3DPoint;
};

export type ViroControllerStatusEvent = {
  controllerStatus: ViroControllerStatus;
  source: number;
};

export type ViroControllerStatus = any;

/** ===========================================================================
 * Viro AR Portal Events
 * ============================================================================ */
export type ViroPortalEnterEvent = any;
export type ViroPortalExitEvent = any;

/** ===========================================================================
 * Viro Sound Events
 * ============================================================================ */
export type ViroSoundFinishEvent = any;

/** ===========================================================================
 * Viro Cloud Anchor Events
 * ============================================================================ */

/**
 * State of a cloud anchor operation.
 * Maps to GARCloudAnchorState (iOS) and Anchor.CloudAnchorState (Android)
 */
export type ViroCloudAnchorState =
  | "None"
  | "Success"
  | "ErrorInternal"
  | "TaskInProgress"
  | "ErrorNotAuthorized"
  | "ErrorResourceExhausted"
  | "ErrorHostingDatasetProcessingFailed"
  | "ErrorCloudIdNotFound"
  | "ErrorResolvingSdkVersionTooOld"
  | "ErrorResolvingSdkVersionTooNew"
  | "ErrorHostingServiceUnavailable"
  /*
   * The ReactVision provider's host, resolve or scan was cancelled through
   * cancelCloudAnchorOperations(), for example by leaving a co-location session.
   */
  | "ErrorCancelled"
  /*
   * The five below come from the ReactVision provider rather than ARCore, and
   * were missing here while native already emitted them: the state crosses the
   * bridge as an untyped string, so nothing failed to compile and a caller
   * switching on this union silently missed every one of them.
   *
   * ErrorResolvingLocalizationNoMatch is the common one on phones — the 30
   * second SIFT window closing without two consistent matches. It says the
   * anchor was not recognised from here, not that it does not exist.
   */
  | "ErrorNetworkFailure"
  | "ErrorAuthenticationFailed"
  | "ErrorHostingInsufficientVisualFeatures"
  | "ErrorResolvingLocalizationNoMatch"
  | "ErrorAnchorExpired"
  /**
   * Emitted by JS platform guards, never by native: the running platform has no
   * cloud anchor path at all (Quest, visionOS). Distinct from a failure — there
   * was nothing to attempt.
   */
  | "ErrorNotSupported";

/**
 * Unified AR provider — controls both cloud anchors and geospatial anchors.
 */
export type ViroProvider = "none" | "arcore" | "reactvision";

/** @deprecated Use ViroProvider */
export type ViroCloudAnchorProvider = ViroProvider;

/**
 * Represents a cloud-hosted AR anchor.
 *
 * `position`/`rotation` are always in world coordinates at resolve time — how
 * that world pose was originally anchored depends on how the anchor was
 * hosted: `hostCloudAnchor()` ties it to a hand-placed physical anchor;
 * `finishScan()` (room/building-scale scans, no placed anchor) ties it to a
 * self-defined location frame instead (origin at the scan's camera-position
 * centroid, oriented by the first keyframe's heading). Callers do not need to
 * know which one produced a given `cloudAnchorId` — both resolve to the same
 * world-space shape.
 */
export type ViroCloudAnchor = {
  /** The local anchor ID */
  anchorId: string;
  /** The cloud anchor ID (assigned after successful hosting) */
  cloudAnchorId?: string;
  /** Current state of the cloud anchor */
  state: ViroCloudAnchorState;
  /** Position in world coordinates */
  position: [number, number, number];
  /** Rotation in degrees */
  rotation: [number, number, number];
  /** Scale */
  scale: [number, number, number];
  /**
   * Opaque CSV-encoded transform for this resolved anchor (WS-C). Pass it
   * straight into `loadWorldMeshFromFile()` as `resolvedTransform` to attach
   * a mesh snapshot hosted alongside this anchor. Treat as opaque; do not
   * parse or construct this value.
   */
  resolvedTransform?: string;
};

/**
 * Result of a host cloud anchor operation.
 */
export type ViroHostCloudAnchorResult = {
  success: boolean;
  cloudAnchorId?: string;
  error?: string;
  state: ViroCloudAnchorState;
};

/**
 * Result of a finishScan() operation (WS-A room/building-scale scan, the
 * counterpart to ViroHostCloudAnchorResult for scans with no placed anchor).
 */
export type ViroFinishScanResult = {
  success: boolean;
  cloudAnchorId?: string;
  /**
   * Opaque token identifying the location frame this scan was hosted in.
   * Pass it straight into snapshotWorldMeshToFile() if attaching a mesh —
   * there is no placed anchor to derive one from otherwise. Treat as opaque;
   * do not parse or construct this value.
   */
  locationTransform?: string;
  error?: string;
  /**
   * What the coverage gate measured, when it is the reason this failed.
   *
   * The message is a sentence for a person; this is the same verdict in numbers, so an app can
   * say which one fell short instead of repeating "insufficient scan quality".
   */
  diagnostics?: ViroScanDiagnostics;
};

/**
 * How a scan is doing while it is still going.
 *
 * Safe to poll on a timer: the renderer reads the keyframe buffer's camera poses and
 * triangulates nothing.
 */
export type ViroScanStatus = {
  /** False when no ReactVision provider is configured — nothing is being scanned. */
  available: boolean;
  /** True between startScan() and finishScan(). */
  scanning?: boolean;
  keyframes?: number;
  /** Keyframe pairs at least 3 cm apart — the same measure the coverage gate applies. */
  viewpointPairs?: number;
  /**
   * Bounding-box diagonal of the camera path so far.
   *
   * Not the number the gate finally checks, which is the spread of the *triangulated points*
   * and only exists after finishScan(). Walking a wider path is what produces a wider cloud,
   * but treat this as guidance, not as a prediction.
   */
  cameraSpreadMeters?: number;
  minKeyframes?: number;
  minViewpointPairs?: number;
  minSpreadMeters?: number;
  meetsKeyframes?: boolean;
  meetsViewpointPairs?: boolean;
  meetsSpread?: boolean;
  /**
   * Points triangulated from the scan so far, and the count hosting needs.
   * Sent by renderers that triangulate while scanning; absent from older ones.
   */
  triangulatedPoints?: number;
  minTriangulatedPoints?: number;
  error?: string;
};

/** The measurements behind the last scan-based host, pass or fail. */
export type ViroScanDiagnostics = {
  /** False until a scan has finished or failed in this session. */
  valid: boolean;
  keyframes?: number;
  triangulatedPoints?: number;
  viewpointPairs?: number;
  /** Spread of the triangulated points — the number the gate compared. */
  spreadMeters?: number;
  minPoints?: number;
  minViewpointPairs?: number;
  minSpreadMeters?: number;
};

/**
 * Result of snapshotWorldMeshToFile() (WS-C). filePath points at a local
 * cache file — pass it straight into rvUploadAsset() to persist it as a
 * cloud anchor asset.
 */
export type ViroWorldMeshSnapshotResult = {
  success: boolean;
  filePath?: string;
  error?: string;
};

/**
 * Result of loadWorldMeshFromFile() (WS-C). success is false if there was no
 * AR scene, world mesh was not enabled (see setWorldMeshEnabled), or the
 * file was malformed.
 */
export type ViroWorldMeshLoadResult = {
  success: boolean;
  error?: string;
};

/**
 * Result of a resolve cloud anchor operation. See {@link ViroCloudAnchor} for
 * how `anchor`'s pose relates to the original hosting method.
 */
export type ViroResolveCloudAnchorResult = {
  success: boolean;
  anchor?: ViroCloudAnchor;
  error?: string;
  state: ViroCloudAnchorState;
};

/**
 * Progress of a cloud anchor resolve, from `getCloudAnchorStatus()`.
 *
 * `message` is the useful field: resolving passes through downloading the
 * anchor, looking for it, and holding after a first match, and only the message
 * separates "never seen" from "seen once" — which is the difference between a
 * hopeless spot and one worth standing still in.
 */
export type ViroCloudAnchorStatus = {
  /** False when nothing is resolving; the other fields are then empty. */
  active: boolean;
  /** 0 to 1, monotonic within one resolve. */
  progress: number;
  message: string;
};

/**
 * Result of `rvCreateSharedFrame()` / `rvJoinSharedFrame()` (CL-H).
 *
 * `transform` is the same opaque, column-major CSV a resolved cloud anchor
 * returns, so a shared frame and a cloud anchor are interchangeable downstream.
 */
export type ViroSharedFrameResult = {
  success: boolean;
  /** UUID of the underlying platform anchor. */
  frameId?: string;
  transform?: string;
  error?: string;
};

/**
 * Fired by `<ViroARCloudAnchor>` once a cloud anchor has localised and its
 * location frame is established.
 *
 * `transform` is the same opaque token as `ViroCloudAnchor.resolvedTransform`.
 * Feed it to `parseLocationTransform()` when converting coordinates for another
 * device, or pass it straight into `loadWorldMeshFromFile()` for a mesh.
 */
export type ViroLocalizedEvent = {
  cloudAnchorId: string;
  /** Frame origin in this session's world coordinates. */
  position: [number, number, number];
  /** Frame orientation, Euler degrees. */
  rotation: [number, number, number];
  scale: [number, number, number];
  transform: string;
};

/**
 * @deprecated Never fired. The `onCloudAnchorStateChange` prop this typed was
 * declared on `ViroARSceneNavigator` and never wired to anything — no handler,
 * no native event constant on either platform — so an app that set it heard
 * nothing. The prop was removed in 3.0.1; this type is kept exported so an
 * existing import does not break, and will go in the next major.
 *
 * Cloud anchor state is available without it, and always was:
 *
 * - `hostCloudAnchor()` and `resolveCloudAnchor()` resolve with `state` on the
 *   result, which is the outcome this event would have reported.
 * - `rvGetCloudAnchor(anchorId)` returns the current state of a known anchor,
 *   for polling one you did not just host or resolve.
 */
export type ViroCloudAnchorStateChangeEvent = {
  anchorId: string;
  cloudAnchorId?: string;
  state: ViroCloudAnchorState;
  error?: string;
};

/** ===========================================================================
 * Viro Geospatial API Events and Types
 * ============================================================================ */

/** @deprecated Use ViroProvider */
export type ViroGeospatialAnchorProvider = ViroProvider;

/**
 * Earth tracking state.
 * Maps to GARSessionEarthState (iOS) and Earth.EarthState (Android)
 */
export type ViroEarthTrackingState =
  | "Enabled"
  | "Paused"
  | "Stopped"
  | "Localizing";

/**
 * State of an AR session recording. The same four values on every platform: the iOS bridge
 * returns them directly and the Android bridge maps its Java enum onto them.
 *
 * Web is not in the list on purpose: ViroARSceneNavigator.web.tsx exposes no imperative API at
 * all, so there is no getRecordingStatus to call there rather than one that answers "Unsupported".
 */
export type ViroRecordingStatus =
  | "None"
  | "Recording"
  | "IOError"
  | "Unsupported";

/**
 * VPS (Visual Positioning System) availability at a location.
 */
export type ViroVPSAvailability = "Available" | "Unavailable" | "Unknown";

/**
 * Type of geospatial anchor.
 */
export type ViroGeospatialAnchorType = "WGS84" | "Terrain" | "Rooftop";

/**
 * Quaternion representation [x, y, z, w] in East-Up-South (EUS) coordinate frame.
 */
export type ViroQuaternion = [number, number, number, number];

/**
 * The camera's geospatial pose including location, orientation, and accuracy.
 */
export type ViroGeospatialPose = {
  /** Latitude in degrees */
  latitude: number;
  /** Longitude in degrees */
  longitude: number;
  /** Altitude in meters above the WGS84 ellipsoid */
  altitude: number;
  /** Heading in degrees (0 = North, 90 = East) */
  heading: number;
  /** Orientation quaternion [x, y, z, w] in EUS frame */
  quaternion: ViroQuaternion;
  /** Horizontal accuracy in meters (95% confidence) */
  horizontalAccuracy: number;
  /** Vertical accuracy in meters (95% confidence) */
  verticalAccuracy: number;
  /** Heading accuracy in degrees (95% confidence) */
  headingAccuracy: number;
  /** Orientation yaw accuracy in degrees (95% confidence) */
  orientationYawAccuracy: number;
};

/**
 * Represents a geospatial anchor in the AR session.
 */
export type ViroGeospatialAnchor = {
  /** Unique identifier for this anchor */
  anchorId: string;
  /** Type of geospatial anchor */
  type: ViroGeospatialAnchorType;
  /** Latitude in degrees */
  latitude: number;
  /** Longitude in degrees */
  longitude: number;
  /** Altitude in meters */
  altitude: number;
  /** Heading in degrees */
  heading: number;
  /** Position in world coordinates [x, y, z] */
  position: [number, number, number];
};

/**
 * Result of checking geospatial mode support.
 */
export type ViroGeospatialSupportResult = {
  supported: boolean;
  error?: string;
};

/**
 * Result of checking whether only approximate location is granted (WS-D).
 * When true, horizontalAccuracy will stay coarse and geospatial tracking
 * will never leave "Localizing" — surface an explicit error instead of
 * waiting on it to resolve on its own.
 */
export type ViroLocationAccuracyResult = {
  reduced: boolean;
  error?: string;
};

/**
 * Result of getting Earth tracking state.
 */
export type ViroEarthTrackingStateResult = {
  state: ViroEarthTrackingState;
  error?: string;
};

/**
 * Result of getting the camera geospatial pose.
 */
export type ViroGeospatialPoseResult = {
  success: boolean;
  pose?: ViroGeospatialPose;
  error?: string;
};

/**
 * Result of checking VPS availability.
 */
export type ViroVPSAvailabilityResult = {
  availability: ViroVPSAvailability;
  error?: string;
};

/**
 * Result of creating a geospatial anchor.
 */
export type ViroCreateGeospatialAnchorResult = {
  success: boolean;
  anchor?: ViroGeospatialAnchor;
  error?: string;
};

/** ===========================================================================
 * Viro Scene Semantics API Types
 * ============================================================================ */

/**
 * Semantic labels for scene classification.
 * Each pixel in the camera feed can be classified into one of these categories.
 */
export type ViroSemanticLabel =
  | "unlabeled"
  | "sky"
  | "building"
  | "tree"
  | "road"
  | "sidewalk"
  | "terrain"
  | "structure"
  | "object"
  | "vehicle"
  | "person"
  | "water";

/**
 * Semantic label fractions representing the percentage of pixels
 * for each label in the current frame.
 * Keys are semantic label names, values are fractions between 0.0 and 1.0.
 */
export type ViroSemanticLabelFractions = {
  unlabeled: number;
  sky: number;
  building: number;
  tree: number;
  road: number;
  sidewalk: number;
  terrain: number;
  structure: number;
  object: number;
  vehicle: number;
  person: number;
  water: number;
};

/**
 * Result of checking semantic mode support.
 */
export type ViroSemanticSupportResult = {
  supported: boolean;
  error?: string;
};

/**
 * Result of getting semantic label fractions.
 */
export type ViroSemanticLabelFractionsResult = {
  success: boolean;
  fractions?: ViroSemanticLabelFractions;
  error?: string;
};

/**
 * Result of getting a specific semantic label fraction.
 */
export type ViroSemanticLabelFractionResult = {
  success: boolean;
  fraction: number;
  error?: string;
};

// ===========================================================================
// Monocular Depth Estimation Types
// ===========================================================================

/**
 * Result of checking monocular depth support.
 */
export type ViroMonocularDepthSupportResult = {
  supported: boolean;
  error?: string;
};

/**
 * Result of checking if monocular depth model is available (bundled).
 */
export type ViroMonocularDepthModelAvailableResult = {
  available: boolean;
  error?: string;
};

/**
 * Result of checking monocular depth preference.
 */
export type ViroMonocularDepthPreferenceResult = {
  preferred: boolean;
  error?: string;
};

/**
 * Result of checking if depth occlusion is supported on this device.
 */
export type ViroDepthOcclusionSupportResult = {
  supported: boolean;
  minARCoreVersion?: string;
  error?: string;
};

/**
 * Result of checking geospatial setup prerequisites.
 */
export type ViroGeospatialSetupStatusResult = {
  geospatialSupported: boolean;
  locationServicesAvailable: boolean;
  apiKeyConfigured: boolean;
  arCoreVersion?: string;
  error?: string;
};

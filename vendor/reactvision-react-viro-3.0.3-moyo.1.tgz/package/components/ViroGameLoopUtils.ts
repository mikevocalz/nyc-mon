/**
 * ViroGameLoopUtils — direct node manipulation that bypasses the React reconciler.
 *
 * Call these from inside useGameLoop / onUpdate callbacks for zero-setState
 * positional updates. Each dispatches a view-manager command that writes to the
 * VRONode through the same setter the corresponding prop uses — no setState, no
 * diffing, no re-render.
 *
 * The commands are declared on the shared base of every node manager:
 * ViroViewManager on iOS, VRTNodeManager on Android. They must stay in step with
 * the names below — a command a manager does not declare is a runtime error, not
 * a silent no-op.
 *
 * The vector is sent flattened as the command args ([x, y, z]), not wrapped in
 * an array. The native signatures must match that shape: on iOS each method
 * takes the react tag plus x, y and z (the interop layer prepends the tag), and
 * on Android applyTransformCommand reads args as a flat float array.
 *
 * Copyright © 2026 ReactVision. All rights reserved.
 */

import { findNodeHandle, UIManager } from "react-native";
import type React from "react";

export const ViroGameLoopUtils = {
  /**
   * Set the node's position without going through React state.
   * Equivalent to <ViroNode position={[x,y,z]} /> but synchronous
   * and reconciler-free — safe to call every frame.
   */
  setPosition(
    nodeRef: React.RefObject<any>,
    position: [number, number, number]
  ): void {
    const handle = findNodeHandle(nodeRef.current);
    if (handle == null) return;
    // RN 0.88 types the command id as a number; both platforms accept the name string.
    UIManager.dispatchViewManagerCommand(handle, "setPosition" as unknown as number, position);
  },

  /**
   * Set Euler rotation (degrees) without going through React state.
   */
  setRotation(
    nodeRef: React.RefObject<any>,
    rotation: [number, number, number]
  ): void {
    const handle = findNodeHandle(nodeRef.current);
    if (handle == null) return;
    UIManager.dispatchViewManagerCommand(handle, "setRotationEuler" as unknown as number, rotation);
  },

  /**
   * Set uniform or non-uniform scale without going through React state.
   */
  setScale(
    nodeRef: React.RefObject<any>,
    scale: [number, number, number]
  ): void {
    const handle = findNodeHandle(nodeRef.current);
    if (handle == null) return;
    UIManager.dispatchViewManagerCommand(handle, "setScale" as unknown as number, scale);
  },
};

export const VIRO_VERSION = "3.0.3-moyo.1";

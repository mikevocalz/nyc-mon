import {
  AndroidConfig,
  ConfigPlugin,
  ExportedConfigWithProps,
  withAndroidManifest,
  withAppBuildGradle,
  withDangerousMod,
  withFinalizedMod,
  withGradleProperties,
  withProjectBuildGradle,
  withSettingsGradle,
} from "@expo/config-plugins";
import type { ExpoConfig } from "@expo/config-types";
import fs from "fs";
import path from "path";
import { insertLinesHelper } from "./util/insertLinesHelper";
import { addQuestRenderModelEntries } from "./util/questRenderModel";
import {
  META_SPATIAL_LAYOUT_FLAVOR_WARNING,
  removeMetaSpatialLayoutFromFlavoredApp,
  renderMetaSpatialLayoutDependencies,
} from "./util/metaSpatialLayoutGradle";
import {
  disabledQuestEntryNames,
  isMetaOnlyName,
  syncQuestFlavorManifest,
} from "./util/questFlavorManifest";
import {
  OPENXR_RENDER_QUALITY_META_NAMES,
  resolveOpenXRRenderQualityMetaData,
} from "./util/openxrRenderQuality";
import { ViroConfigurationOptions, XrMode } from "./withViro";
import { assertMetaVrGlassesXrMode, resolveMetaDefaultDeviceTargets } from "./metaTargeting";
let viroPluginConfig = ["AR", "GVR"];

const withBranchAndroid: ConfigPlugin<ViroConfigurationOptions> = (config) => {
  // Directly edit MainApplication.java
  return withDangerousMod(config, [
    "android",
    async (config) => {
      let mainApplicationPath = "";
      let isJava: boolean;
      const mainApplicationPrefix = path.join(
        config.modRequest.platformProjectRoot,
        "app",
        "src",
        "main",
        "java",
        ...(config?.android?.package?.split?.(".") || [])
      );
      const mainApplicationPathJava = path.join(
        mainApplicationPrefix,
        "MainApplication.java"
      );
      const mainApplicationPathKotlin = path.join(
        mainApplicationPrefix,
        "MainApplication.kt"
      );
      if (fs.existsSync(mainApplicationPathJava)) {
        isJava = true;
        mainApplicationPath = mainApplicationPathJava;
      } else if (fs.existsSync(mainApplicationPathKotlin)) {
        isJava = false;
        mainApplicationPath = mainApplicationPathKotlin;
      } else {
        throw new Error(
          "MainApplication.kt or MainApplication.java file not found."
        );
      }

      fs.readFile(mainApplicationPath, "utf-8", (err, data) => {
        const packageName = config?.android?.package;
        if (isJava) {
          data = insertLinesHelper(
            "import com.viromedia.bridge.ReactViroPackage;",
            `package ${packageName};`,
            data
          );
        } else {
          // Handle Backticks in package names for Kotlin
          const packageMatch = data.match(/package\s+[\w.`]+/);
          if (!packageMatch) {
            throw new Error(
              "Package declaration not found in MainApplication.kt"
            );
          }
          data = insertLinesHelper(
            "import com.viromedia.bridge.ReactViroPackage",
            packageMatch[0],
            data
          );
        }

        const viroPlugin = config?.plugins?.find(
          (plugin) =>
            Array.isArray(plugin) && plugin[0] === "@reactvision/react-viro"
        );

        if (Array.isArray(viroPlugin)) {
          if (Array.isArray(viroPlugin[1].android?.xRMode)) {
            viroPluginConfig = (
              viroPlugin[1].android?.xRMode as XrMode[]
            ).filter((mode) => ["AR", "GVR", "OVR_MOBILE", "QUEST", "PICO"].includes(mode));
          } else if (
            ["AR", "GVR", "OVR_MOBILE", "QUEST", "PICO"].includes(viroPlugin[1]?.android?.xRMode)
          ) {
            viroPluginConfig = [viroPlugin[1]?.android.xRMode];
          }
        }

        let target = "";
        for (const viroConfig of viroPluginConfig) {
          if (isJava) {
            target =
              target +
              `      packages.add(new ReactViroPackage(ReactViroPackage.ViroPlatform.${viroConfig}))\n`;
          } else {
            // Use proper Kotlin syntax for newer formats
            target =
              target +
              `            add(ReactViroPackage(ReactViroPackage.ViroPlatform.${viroConfig}))\n`;
          }
        }

        if (isJava) {
          data = insertLinesHelper(
            target,
            "List<ReactPackage> packages = new PackageList(this).getPackages();",
            data
          );
        } else {
          // Handle various MainApplication.kt formats
          if (data.includes("// packages.add(new MyReactNativePackage());")) {
            data = insertLinesHelper(
              target,
              "// packages.add(new MyReactNativePackage());",
              data
            );
          } else if (data.includes("// add(MyReactNativePackage())")) {
            data = insertLinesHelper(
              target,
              "// add(MyReactNativePackage())",
              data
            );
          } else if (data.includes("// packages.add(MyReactNativePackage())")) {
            // Handle newer Expo format: // packages.add(MyReactNativePackage())
            data = insertLinesHelper(
              target,
              "// packages.add(MyReactNativePackage())",
              data
            );
          } else if (
            data.includes("val packages = PackageList(this).packages")
          ) {
            // Handle newer format where packages is declared as val
            data = insertLinesHelper(
              target,
              "val packages = PackageList(this).packages",
              data
            );
          } else {
            throw new Error(
              "Unable to insert Android packages into package list. Please create a new issue on GitHub and reference this message! " +
                "Expected to find one of: '// packages.add(new MyReactNativePackage());', '// add(MyReactNativePackage())', " +
                "'// packages.add(MyReactNativePackage())', or 'val packages = PackageList(this).packages'"
            );
          }
        }

        fs.writeFile(mainApplicationPath, data, "utf-8", function (err) {
          if (err) console.log("Error writing MainApplication.java");
        });
      });
      return config;
    },
  ]);
};

const withViroProjectBuildGradle = (config: ExpoConfig) =>
  withProjectBuildGradle(config, async (newConfig) => {
    newConfig.modResults.contents = newConfig.modResults.contents.replace(
      /minSdkVersion.*/,
      `minSdkVersion = 24`
    );

    // Ensure New Architecture is enabled
    //if (!newConfig.modResults.contents.includes("newArchEnabled=true")) {
    //  newConfig.modResults.contents +=
    //    "\n// ViroReact requires New Architecture\nnewArchEnabled=true\n";
    //}

    newConfig.modResults.contents = newConfig.modResults.contents.replace(
      /classpath\("com.android.tools.build:gradle.*/,
      `classpath('com.android.tools.build:gradle:4.1.1')`
    );
    return newConfig;
  });

function assertDirectAppDependency(projectRoot: string, packageName: string): void {
  const packageJsonPath = path.join(projectRoot, "package.json");
  let appPackage: any;
  try {
    appPackage = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"));
  } catch {
    throw new Error(
      `[Viro] metaSpatialLayout requires a readable app package.json at ${packageJsonPath}.`
    );
  }
  const sections = [
    appPackage.dependencies,
    appPackage.optionalDependencies,
    appPackage.devDependencies,
  ];
  if (!sections.some((section) => section?.[packageName])) {
    throw new Error(
      `[Viro] metaSpatialLayout requires ${packageName} as a direct app dependency. ` +
        "Install both @metavr/layout-compat and @metavr/layout-window-compat before expo prebuild."
    );
  }
}

const withViroAppBuildGradle = (
  config: ExpoConfig,
  props?: ViroConfigurationOptions
) =>
  withAppBuildGradle(config, async (config) => {
    let metaSpatialDependencies = "";
    if (props?.android?.metaSpatialLayout) {
      const configuredModes = props.android.xRMode ?? [];
      const modes = Array.isArray(configuredModes)
        ? configuredModes
        : [configuredModes as XrMode];
      if (!modes.includes("QUEST")) {
        throw new Error(
          '[Viro] android.metaSpatialLayout requires android.xRMode to include "QUEST".'
        );
      }
      assertDirectAppDependency(config.modRequest.projectRoot, "@metavr/layout-compat");
      assertDirectAppDependency(config.modRequest.projectRoot, "@metavr/layout-window-compat");
      const bomVersion =
        props.android.metaSpatialLayoutBomVersion ?? "1.2026.0.0";
      metaSpatialDependencies = renderMetaSpatialLayoutDependencies(bomVersion);
    }

    // ViroReact New Architecture (Fabric) Dependencies
    const viroNewArchDependencies = `
    // ========================================================================
    // ViroReact New Architecture (Fabric) Dependencies
    // https://viro-community.readme.io/docs/installation-instructions
    implementation project(':gvr_common')
    implementation project(':arcore_client')
    implementation project(path: ':react_viro')
    implementation project(path: ':viro_renderer')
    implementation 'androidx.media3:media3-exoplayer:1.1.1'
    implementation 'androidx.media3:media3-exoplayer-dash:1.1.1'
    implementation 'androidx.media3:media3-exoplayer-hls:1.1.1'
    implementation 'androidx.media3:media3-exoplayer-smoothstreaming:1.1.1'
    implementation 'com.google.protobuf.nano:protobuf-javanano:3.1.0'
    // Required for ARCore Geospatial API
    implementation 'com.google.android.gms:play-services-location:21.0.1'${metaSpatialDependencies}
    // ========================================================================`;

    // Add Viro dependencies for legacy architecture (fallback)
    config.modResults.contents = config.modResults.contents.replace(
      /implementation "com.facebook.react:react-native:\+"  \/\/ From node_modules/,
      `implementation "com.facebook.react:react-native:+"  // From node_modules${viroNewArchDependencies}`
    );

    // Add Viro dependencies for new architecture (primary)
    config.modResults.contents = config.modResults.contents.replace(
      /implementation\("com.facebook.react:react-android"\)/,
      `implementation("com.facebook.react:react-android")${viroNewArchDependencies}`
    );
    // :react_viro and :viro_renderer declare a "device" flavor dimension
    // (mobile, pico, quest). An app without that dimension cannot pick a
    // variant, so default it from xRMode. An app that defines its own
    // device flavors overrides this per flavor.
    if (
      !config.modResults.contents.includes("missingDimensionStrategy 'device'") &&
      !/flavorDimensions[^\n]*"device"/.test(config.modResults.contents)
    ) {
      const configured = props?.android?.xRMode ?? [];
      const modes = Array.isArray(configured) ? configured : [configured as XrMode];
      const device = modes.includes("QUEST") ? "quest" : modes.includes("PICO") ? "pico" : "mobile";
      config.modResults.contents = config.modResults.contents.replace(
        /defaultConfig\s*\{/,
        (match) => `${match}\n        missingDimensionStrategy 'device', '${device}'`
      );
    }
    return config;
  });

/**
 * Resolve the on-disk `@reactvision/react-viro/android` directory as a path
 * relative to the Android project root (where `settings.gradle` lives).
 *
 * Hardcoding `../node_modules/...` assumes react-viro is installed in the app's
 * own `node_modules`. That is false under pnpm/yarn workspaces (and npm
 * workspaces), where the package is hoisted to the monorepo root or nested
 * under `.pnpm`, so Gradle fails with "Configuring project ':gvr_common'
 * without an existing directory is not allowed". Resolving via Node follows
 * symlinks/hoisting and works in both flat and workspace layouts.
 */
export function resolveViroAndroidRelativePath(projectRoot: string, androidRoot: string): string {
  const fallback = "../node_modules/@reactvision/react-viro/android";
  try {
    const pkgJson = require.resolve("@reactvision/react-viro/package.json", {
      paths: [projectRoot],
    });
    const viroAndroidDir = path.join(path.dirname(pkgJson), "android");
    // Gradle resolves relative File(...) against the settings.gradle dir (androidRoot).
    // Always emit POSIX separators — Gradle accepts them on every platform.
    return path.relative(androidRoot, viroAndroidDir).split(path.sep).join("/");
  } catch {
    return fallback;
  }
}

const withViroSettingsGradle = (config: ExpoConfig) =>
  withSettingsGradle(config, async (config) => {
    const viroAndroidRoot = resolveViroAndroidRelativePath(
      config.modRequest.projectRoot,
      config.modRequest.platformProjectRoot
    );
    config.modResults.contents += `
include ':react_viro', ':arcore_client', ':gvr_common', ':viro_renderer'
project(':arcore_client').projectDir = new File('${viroAndroidRoot}/arcore_client')
project(':gvr_common').projectDir = new File('${viroAndroidRoot}/gvr_common')
project(':viro_renderer').projectDir = new File('${viroAndroidRoot}/viro_renderer')
project(':react_viro').projectDir = new File('${viroAndroidRoot}/react_viro')
    `;
    return config;
  });

const withViroManifest = (config: ExpoConfig) =>
  withAndroidManifest(
    config,
    async (newConfig: ExportedConfigWithProps<any>) => {
      // TODO(pico): PICO manifest block + activity registration — see docs/pico, gated on device facts
      const contents = newConfig.modResults;
      contents.manifest.$["xmlns:tools"] = "http://schemas.android.com/tools";

      // Initialize meta-data array if it doesn't exist
      if (!contents?.manifest?.application?.[0]["meta-data"]) {
        contents.manifest.application[0]["meta-data"] = [];
      }

      // Resolve xRMode so we only declare ARCore on flavors that
      // actually use it. Quest/PICO ship their own AR runtimes via
      // OpenXR — declaring ARCore there causes the SDK to launch the
      // Google Play Services for AR install activity at runtime even
      // though value="optional".
      const viroPlugin = config?.plugins?.find(
        (plugin) =>
          Array.isArray(plugin) && plugin[0] === "@reactvision/react-viro"
      );
      const xrModeRaw =
        Array.isArray(viroPlugin) && viroPlugin.length > 1
          ? (viroPlugin[1] as any)?.android?.xRMode
          : undefined;
      const xrModes: string[] = Array.isArray(xrModeRaw)
        ? (xrModeRaw as string[])
        : xrModeRaw
          ? [xrModeRaw as string]
          : ["AR", "GVR"];
      const usesArcore = xrModes.includes("AR");

      if (usesArcore) {
        contents?.manifest?.application?.[0]["meta-data"]?.push({
          $: {
            "android:name": "com.google.ar.core",
            "android:value": "optional",
          },
        });
      }

      // Add Google Cloud API key for ARCore Cloud Anchors and Geospatial API if configured

      // Derive active XR modes from the config at apply-time.
      // `viroPluginConfig` (module-level) is updated by withBranchAndroid's
      // withDangerousMod callback, which runs *after* withAndroidManifest
      // callbacks — so it is still ["AR","GVR"] here. Read from config.plugins
      // directly instead.
      const activeXrModes = (() => {
        const p = (newConfig.plugins ?? []).find(
          (plugin: any) => Array.isArray(plugin) && plugin[0] === "@reactvision/react-viro"
        );
        if (Array.isArray(p) && p[1]?.android?.xRMode) {
          const xrMode = p[1].android.xRMode;
          return Array.isArray(xrMode) ? (xrMode as string[]) : [xrMode as string];
        }
        return viroPluginConfig;
      })();
      const questBuild = activeXrModes.includes("QUEST");
      const questFeatures = Array.isArray(viroPlugin)
        ? (viroPlugin[1] as ViroConfigurationOptions | undefined)?.android?.questFeatures
        : undefined;
      const questPassthroughCamera = questFeatures?.passthroughCamera !== false;

      if (Array.isArray(viroPlugin) && viroPlugin.length > 1) {
        const pluginOptions = viroPlugin[1] as ViroConfigurationOptions;

        // Resolve unified provider prop; old geospatialAnchorProvider overrides for backward compat.
        // Default to "reactvision" only when rvApiKey is present (implies RV intent) but provider
        // is not explicitly set — avoids injecting location permissions for apps with no credentials.
        const legacyOpts = pluginOptions as { geospatialAnchorProvider?: string };
        const geospatialAnchorProvider = legacyOpts.geospatialAnchorProvider
          ?? pluginOptions.provider
          ?? (pluginOptions.rvApiKey ? "reactvision" : undefined);

        if (pluginOptions.googleCloudApiKey) {
          contents?.manifest?.application?.[0]["meta-data"]?.push({
            $: {
              "android:name": "com.google.android.ar.API_KEY",
              "android:value": pluginOptions.googleCloudApiKey,
            },
          });
        }
        if (pluginOptions.rvApiKey) {
          contents?.manifest?.application?.[0]["meta-data"]?.push({
            $: {
              "android:name": "com.reactvision.RVApiKey",
              "android:value": pluginOptions.rvApiKey,
            },
          });
        }
        if (pluginOptions.rvProjectId) {
          contents?.manifest?.application?.[0]["meta-data"]?.push({
            $: {
              "android:name": "com.reactvision.RVProjectId",
              "android:value": pluginOptions.rvProjectId,
            },
          });
        }
        if (pluginOptions.rvEndpoint) {
          contents?.manifest?.application?.[0]["meta-data"]?.push({
            $: {
              "android:name": "com.reactvision.RVEndpoint",
              "android:value": pluginOptions.rvEndpoint,
            },
          });
        }

        // Add location permissions when geospatial provider is active. A Quest
        // has no GPS, so a Quest build (headset-only, see android.hardware.vr.headtracking
        // below) would declare location it can never use.
        if (
          (geospatialAnchorProvider === "arcore" || geospatialAnchorProvider === "reactvision") &&
          !questBuild
        ) {
          const existingPermissions: string[] = (contents.manifest["uses-permission"] || [])
            .map((p: any) => p.$?.["android:name"]);
          if (!existingPermissions.includes("android.permission.ACCESS_FINE_LOCATION")) {
            contents.manifest["uses-permission"].push({
              $: { "android:name": "android.permission.ACCESS_FINE_LOCATION" },
            });
          }
          if (!existingPermissions.includes("android.permission.ACCESS_COARSE_LOCATION")) {
            contents.manifest["uses-permission"].push({
              $: { "android:name": "android.permission.ACCESS_COARSE_LOCATION" },
            });
          }
        }
      }

      if (
        activeXrModes.includes("GVR") ||
        activeXrModes.includes("OVR_MOBILE")
      ) {
        contents?.manifest?.application?.[0]?.activity[0][
          "intent-filter"
        ][0].category.push({
          $: {
            "android:name": "com.google.intent.category.CARDBOARD",
          },
        });
        contents?.manifest?.application?.[0]?.activity[0][
          "intent-filter"
        ][0].category.push({
          $: {
            "android:name": "com.google.intent.category.DAYDREAM",
          },
        });
      }

      // android.permission.SYSTEM_ALERT_WINDOW is merged in from React Native's
      // debug manifest and is rejected by the Meta Quest Store.
      if (contents.manifest["uses-permission"]) {
        contents.manifest["uses-permission"] = contents.manifest["uses-permission"].filter(
          (p: any) => p.$?.["android:name"] !== "android.permission.SYSTEM_ALERT_WINDOW"
        );
      }

      if (usesArcore) {
        // Preserve query entries contributed by other platform plugins (notably
        // @expo-pico/core's OpenXR broker query). Replacing the whole array made
        // Quest/AR + PICO multi-platform prebuilds depend on plugin ordering.
        const queries = contents.manifest.queries ?? [];
        const hasArCoreQuery = queries.some((query: any) =>
          query.package?.some(
            (pkg: any) => pkg.$?.["android:name"] === "com.google.ar.core"
          )
        );
        if (!hasArCoreQuery) {
          queries.push({
            package: [
              {
                $: {
                  "android:name": "com.google.ar.core",
                },
              },
            ],
          });
        }
        contents.manifest.queries = queries;
      }

      contents.manifest["uses-feature"] = [];

      // On a Quest build the camera is only the passthrough Camera2 feed, and
      // not every Quest has one, so the feature is never required there.
      const hasCameraPermission = contents.manifest["uses-permission"].some(
        (p: any) => p.$?.["android:name"] === "android.permission.CAMERA"
      );
      if (!hasCameraPermission && (!questBuild || questPassthroughCamera)) {
        contents.manifest["uses-permission"].push({
          $: {
            "android:name": "android.permission.CAMERA",
          },
        });
      }
      contents.manifest["uses-feature"].push({
        $: questBuild
          ? {
              "android:name": "android.hardware.camera",
              "android:required": "false",
              "tools:replace": "required",
            }
          : {
              "android:name": "android.hardware.camera",
            },
      });
      contents.manifest["uses-feature"].push({
        $: {
          "android:name": "android.hardware.camera.autofocus",
          "android:required": "false",
          "tools:replace": "required",
        },
      });

      // The Quest Store validator only counts a *required* GLES/Vulkan
      // declaration; required=false is reported as "no graphics API". Every
      // Quest has GLES 3, so require it there and keep it optional on phones.
      contents.manifest["uses-feature"].push({
        $: {
          "android:glEsVersion": "0x00030000",
          "android:required": activeXrModes.includes("QUEST") ? "true" : "false",
          "tools:replace": "required",
        },
      });
      contents.manifest["uses-feature"].push({
        $: {
          "android:name": "android.hardware.sensor.accelerometer",
          "android:required": "false",
          "tools:replace": "required",
        },
      });
      contents.manifest["uses-feature"].push({
        $: {
          "android:name": "android.hardware.sensor.gyroscope",
          "android:required": "false",
          "tools:replace": "required",
        },
      });

      // Quest-specific features and permissions — after uses-feature is initialized
      if (activeXrModes.includes("QUEST")) {
        contents.manifest["uses-feature"].push({
          $: {
            "android:name": "android.hardware.vr.headtracking",
            // A combined ["AR", "QUEST"] APK must remain installable on phones.
            // Quest-only binaries can require head tracking for store targeting.
            "android:required": activeXrModes.includes("AR") ? "false" : "true",
            "android:version": "1",
          },
        });
        contents.manifest["uses-feature"].push({
          $: {
            "android:name": "oculus.software.handtracking",
            "android:required": "false",
          },
        });
        // XR_FB_passthrough requires this uses-feature; without it the OpenXR
        // runtime silently strips the extension. required=false so apps that
        // only render fully-virtual scenes still install on Quest 2 etc.
        contents.manifest["uses-feature"].push({
          $: {
            "android:name": "com.oculus.feature.PASSTHROUGH",
            "android:required": "false",
          },
        });
        // Required when com.oculus.permission.EYE_TRACKING is declared. The
        // viro_renderer AAR no longer declares either (virocore #109), so an
        // opt-out just leaves them out.
        const eyeTracking = questFeatures?.eyeTracking !== false;
        if (eyeTracking) {
          contents.manifest["uses-feature"].push({
            $: { "android:name": "oculus.software.eye_tracking", "android:required": "false" },
          });
        }
        // Drop the opted-out entries, and the tools:node="remove" markers
        // older versions wrote for eye tracking, so a second prebuild without
        // --clean follows the current options.
        const disabledNames = disabledQuestEntryNames(questFeatures);
        contents.manifest["uses-permission"] = (contents.manifest["uses-permission"] || []).filter(
          (p: any) =>
            !disabledNames.includes(p.$?.["android:name"]) &&
            !(isMetaOnlyName(p.$?.["android:name"]) && p.$?.["tools:node"] === "remove")
        );
        const existingPermissions: string[] = (contents.manifest["uses-permission"] || [])
          .map((p: any) => p.$?.["android:name"]);
        // Horizon OS logs com.oculus.permission.HAND_TRACKING as deprecated and
        // asks for this name instead.
        if (!existingPermissions.includes("horizonos.permission.HAND_TRACKING")) {
          contents.manifest["uses-permission"].push({
            $: { "android:name": "horizonos.permission.HAND_TRACKING" },
          });
        }
        if (eyeTracking && !existingPermissions.includes("com.oculus.permission.EYE_TRACKING")) {
          contents.manifest["uses-permission"].push({
            $: eyeTracking
              ? { "android:name": "com.oculus.permission.EYE_TRACKING" }
              : { "android:name": "com.oculus.permission.EYE_TRACKING", "tools:node": "remove" },
          });
        }
        // Spatial Data / Scene permissions — required for the Meta OpenXR runtime
        // to expose the scene & spatial-entity extensions (XR_FB_scene,
        // XR_FB_spatial_entity*, XR_FB_scene_capture). Without USE_ANCHOR_API the
        // runtime skips those extensions, so plane / anchor data is unavailable on
        // Quest. These are runtime permissions — also require a grant at runtime.
        const sceneAnchorPerms = [
          "horizonos.permission.USE_ANCHOR_API",  // gates XR_FB_scene / XR_FB_spatial_entity on current Horizon OS
          "com.oculus.permission.USE_SCENE",      // legacy Scene permission (older OS)
          // Meta Passthrough Camera API (Quest 3 / 3S, Horizon OS v74+): grants the
          // app the headset RGB cameras via Camera2, used by ViroObjectDetector to
          // run on-device object detection over passthrough. Runtime-granted.
          ...(questPassthroughCamera ? ["horizonos.permission.HEADSET_CAMERA"] : []),
          // Co-location (CL-H). Without this the Meta runtime does not merely
          // refuse the calls — it hides the extension from
          // xrEnumerateInstanceExtensionProperties entirely, logging
          // "skipping extension=XR_META_spatial_entity_group_sharing due to:
          // missing uses-permission string ...". So the app sees a headset that
          // does not support shared anchors, which is indistinguishable from an
          // older device. Found on a Quest 3; it is not visible from the code.
          ...(questFeatures?.colocation !== false
            ? ["horizonos.permission.IMPORT_EXPORT_IOT_MAP_DATA"]
            : []),
          // Hidden the same way without this: XR_META_boundary_visibility, which
          // the renderer uses to hide the boundary while passthrough is on.
          "com.oculus.permission.BOUNDARY_VISIBILITY",
        ];
        for (const perm of sceneAnchorPerms) {
          if (!existingPermissions.includes(perm)) {
            contents.manifest["uses-permission"].push({ $: { "android:name": perm } });
          }
        }
        // XR_FB_render_model controller GLBs. Not in the viro_renderer AAR
        // manifest, which would carry them into PICO builds.
        addQuestRenderModelEntries(contents.manifest, activeXrModes, questFeatures?.renderModel);
      }

      return newConfig;
    }
  );

// ── Quest VRActivity generation ────────────────────────────────────────────────

/**
 * When QUEST mode is active, generate VRActivity.kt in the app's android source
 * and register it in AndroidManifest with com.oculus.intent.category.VR.
 *
 * VRActivity is a ReactActivity that mounts "VRQuestScene" — a root component
 * the app must register via AppRegistry. Running in a separate Activity with the
 * VR intent category causes Horizon OS to grant exclusive OpenXR display access.
 */
const withViroQuestActivity: ConfigPlugin<ViroConfigurationOptions> = (config, props) => {
  // Read xRMode directly from config.plugins. We cannot rely on the
  // module-level `viroPluginConfig` here: that variable is only updated
  // when `withBranchAndroid`'s withDangerousMod callback runs (mod-apply
  // time), which is *after* this chain-time check executes. On the first
  // prebuild of a new project, viroPluginConfig still holds the default
  // ["AR", "GVR"] when this plugin is composed, and QUEST mods would be
  // silently skipped — no VRActivity.kt and no manifest entry.
  const viroPluginEntry = config?.plugins?.find(
    (plugin) =>
      Array.isArray(plugin) && plugin[0] === "@reactvision/react-viro"
  );
  let xrModes: string[] = ["AR", "GVR"];
  if (Array.isArray(viroPluginEntry)) {
    const xrMode = viroPluginEntry[1]?.android?.xRMode;
    if (Array.isArray(xrMode)) {
      xrModes = xrMode.filter((m: string) =>
        ["AR", "GVR", "OVR_MOBILE", "QUEST", "PICO"].includes(m)
      );
    } else if (
      typeof xrMode === "string" &&
      ["AR", "GVR", "OVR_MOBILE", "QUEST", "PICO"].includes(xrMode)
    ) {
      xrModes = [xrMode];
    }
  }
  // Meta Horizon immersive mode still uses the historical QUEST enum because
  // it selects Viro's Android OpenXR + Horizon launch path. Meta VR Glasses run
  // the same OS/SDK family; do not add a fake device id to supportedDevices.
  assertMetaVrGlassesXrMode(xrModes, props?.android);
  if (!xrModes.includes("QUEST")) return config;

  // 1. Generate VRActivity.kt
  config = withDangerousMod(config, [
    "android",
    async (config) => {
      const packageName = config?.android?.package ?? "";
      const packagePath = packageName.split(".");
      const activityDir = path.join(
        config.modRequest.platformProjectRoot,
        "app", "src", "main", "java",
        ...packagePath
      );

      if (!fs.existsSync(activityDir)) {
        fs.mkdirSync(activityDir, { recursive: true });
      }

      const activityPath = path.join(activityDir, "VRActivity.kt");

      // Only write if not already present (preserve manual edits)
      if (!fs.existsSync(activityPath)) {
        const kotlinContent = `package ${packageName}

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.runtime.ReactHostImpl

/**
 * VRActivity — generated by @reactvision/react-viro Expo plugin.
 * Carries com.oculus.intent.category.VR so Horizon OS grants exclusive
 * OpenXR display access. Mounts the "VRQuestScene" React root component.
 * Launch via NativeModules.VRLauncher.launchVRScene().
 *
 * Lifecycle (requires React Native >= 0.83 / Expo >= 55):
 *   VRActivity and MainActivity share one ReactHostImpl singleton. On Quest,
 *   VRActivity launches into a separate task (FLAG_ACTIVITY_NEW_TASK), so
 *   MainActivity.onPause is dispatched *later* via ActivityManager IPC —
 *   often after VRActivity.onResume has already promoted the host to RESUMED
 *   with currentActivity = VRActivity. When that delayed onPause arrives,
 *   the standard delegate calls onHostPause(MainActivity); the identity-
 *   mismatch assertion is downgraded to a warning by
 *   skipActivityIdentityAssertionOnHostPause (set in VRLauncherModule before
 *   startActivity), but the rest of onHostPause runs unconditionally:
 *   devSupport is disabled and JavaTimerManager clears its TIMERS_EVENTS
 *   callback. Result: timers / requestAnimationFrame stop, Metro Fast Refresh
 *   dies.
 *
 *   We catch this by listening for that delayed MainActivity.onPause via
 *   Application.ActivityLifecycleCallbacks.onActivityPaused(other) and re-
 *   promoting the host on the main looper. A Handler.post inside our own
 *   onResume would fire too early (the ActivityManager hasn't queued
 *   MainActivity.onPause yet), which is why we hook the actual pause event.
 *
 *   On exit, VRActivity.onPause runs while currentActivity == this, so the
 *   identity assertion passes; MainActivity.onResume then re-promotes via
 *   its standard delegate. We do *not* re-promote on a self-pause — the
 *   onActivityPaused callback skips when other === this.
 *
 * Mutual exclusion with MainActivity:
 *   Quest will happily run MainActivity (panel) and VRActivity (immersive) at
 *   the same time if the user taps the app icon in the dock while VR is
 *   running. The same Application.ActivityLifecycleCallbacks finishes self
 *   when any other Activity in this app resumes — returning the user cleanly
 *   to the panel.
 *
 * Surface cleanup on destroy:
 *   When VRActivity is destroyed we unload its React surface (reactSurface.stop()
 *   in bridgeless arch) so its component tree — including all VRT* components
 *   — is unmounted. Without this, the React surface stayed alive in the shared
 *   ReactHost across VR re-entries, and on the second/third VR launch each
 *   stale surface remounted alongside the fresh one. The C++ scene-graph
 *   resolves a click hit to a single viewTag, but multiple VRTComponents
 *   claimed it across surfaces — most with a ReactContext bound to a
 *   destroyed VRActivity. Click events to the stale ReactContexts crashed in
 *   ComponentEventDelegate as IllegalArgumentException SoftExceptions and were
 *   silently dropped, so onClick took dozens of presses to register.
 *   We still no-op the *delegate* onDestroy() so MainActivity keeps its
 *   ReactHost; we only stop the surface explicitly.
 */
class VRActivity : ReactActivity() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lifecycleCallbacks: Application.ActivityLifecycleCallbacks? = null

    // Set true on every VRActivity.onResume; consumed by the first
    // onActivityPaused(other) that follows. One-shot — defends against the
    // single MainActivity.onPause that the NEW_TASK ordering schedules late.
    // Without one-shot semantics, every subsequent foreign pause would re-fire
    // ReactHostImpl.onHostResume, which re-fires every LifecycleEventListener
    // and sends JS a spurious AppState "active".
    private var expectingForeignPause = false

    override fun getMainComponentName(): String = "VRQuestScene"

    override fun createReactActivityDelegate(): ReactActivityDelegate =
        object : DefaultReactActivityDelegate(this, mainComponentName, fabricEnabled) {
            // VRActivity destruction MUST NOT tear down the shared ReactHost.
            // MainActivity is still alive (and re-foreground after VR exit) and
            // depends on the same ReactContext. The standard delegate's
            // onDestroy forwards to ReactHostImpl.onHostDestroy(VR), which
            // fires LifecycleEventListener.onHostDestroy on every native module
            // — releasing native resources MainActivity still uses. The next
            // Cmd+R reload then runs the JS bundle re-init against a partially
            // destroyed native side and fails with
            //   [runtime not ready]: TypeError: Cannot read property
            //   'EventEmitter' of undefined
            // followed by AppRegistryBinding::stopSurface failed and the
            // surface never recovers. By no-op'ing onDestroy here, host
            // destruction is left to MainActivity's standard delegate (the real
            // last activity). The surface itself is stopped explicitly in
            // VRActivity.onDestroy() below.
            override fun onDestroy() {
                // intentionally no-op — see comment above
            }
        }

    override fun onResume() {
        super.onResume()  // delegate.onResume() -> reactHost.onHostResume(this)
        expectingForeignPause = true
    }

    // onPause not overridden: the default delegate forwards to
    // reactHost.onHostPause(this) while currentActivity matches us, which is
    // what we want.

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val callbacks = object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(other: Activity) {
                if (other !== this@VRActivity && !isFinishing && !isDestroyed) {
                    finish()
                }
            }
            override fun onActivityPaused(other: Activity) {
                if (other === this@VRActivity || isFinishing || isDestroyed) return
                if (!expectingForeignPause) return
                expectingForeignPause = false
                // MainActivity.onPause was dispatched after our onResume (the
                // NEW_TASK race). The standard delegate already called
                // onHostPause(MainActivity), demoting the host to PAUSED and
                // disabling devSupport / clearing JavaTimerManager's frame
                // callback. Re-promote so VR keeps timers + Fast Refresh.
                mainHandler.post {
                    if (isFinishing || isDestroyed) return@post
                    (reactHost as? ReactHostImpl)?.onHostResume(this@VRActivity)
                }
            }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        }
        application.registerActivityLifecycleCallbacks(callbacks)
        lifecycleCallbacks = callbacks
    }

    override fun onDestroy() {
        // Stop the React surface attached to this VRActivity so its component
        // tree unmounts cleanly. In bridgeless arch this calls
        // reactSurface.stop() + reactSurface = null, leaving the shared
        // ReactHost intact for MainActivity. Without this the React tree from
        // each VR session piles up across re-entries and stale VRTComponents
        // intercept hit-tested viewTags with dead ReactContexts, breaking
        // onClick / onHover until you press dozens of times.
        //
        // Tell JS the immersive activity is gone before unloading the
        // surface. Horizon can finish VRActivity directly (Meta-button quit
        // confirm, OS reclaim) without exitVRScene() running, so this emit
        // is the only signal that clears VRQuestNavigatorBridge's vrActive
        // flag on that path — without it the AppState relaunch resurrects
        // VR on the next foreground edge and the user has to quit
        // repeatedly.
        try {
            reactHost?.currentReactContext
                ?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("VRLauncher.vrDestroyed", null)
        } catch (t: Throwable) {
            android.util.Log.w("VRActivity", "emit VRLauncher.vrDestroyed failed", t)
        }
        try {
            reactDelegate?.unloadApp()
        } catch (t: Throwable) {
            android.util.Log.w("VRActivity", "reactDelegate.unloadApp() failed", t)
        }
        lifecycleCallbacks?.let { application.unregisterActivityLifecycleCallbacks(it) }
        lifecycleCallbacks = null
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
`;
        fs.writeFileSync(activityPath, kotlinContent, "utf-8");
      }

      return config;
    },
  ]);

  // 2. Quest Store packaging. Expo's template resolves targetSdk through
  // rootProject.ext from gradle.properties (`android.targetSdkVersion`), so a
  // rewrite of app/build.gradle never matched anything. Only ever lower it.
  // Quest hardware is arm64-only; the other ABIs roughly double the APK and the
  // store warns on 32-bit libraries.
  const questTargetSdk = props?.android?.questTargetSdkVersion ?? 34;
  const questArm64Only = props?.android?.questArm64Only ?? true;
  config = withGradleProperties(config, (config) => {
    const current = config.modResults.find(
      (item) => item.type === "property" && item.key === "android.targetSdkVersion"
    );
    const currentSdk =
      current?.type === "property" ? parseInt(current.value, 10) : NaN;
    if (Number.isNaN(currentSdk) || currentSdk > questTargetSdk) {
      AndroidConfig.BuildProperties.updateAndroidBuildProperty(
        config.modResults,
        "android.targetSdkVersion",
        String(questTargetSdk)
      );
    }
    if (questArm64Only) {
      AndroidConfig.BuildProperties.updateAndroidBuildProperty(
        config.modResults,
        "reactNativeArchitectures",
        "arm64-v8a"
      );
    }
    return config;
  });

  // 3. Add VRActivity to AndroidManifest
  config = withAndroidManifest(config, async (config) => {
    const app = config.modResults.manifest.application?.[0];
    if (!app) return config;

    if (!app.activity) app.activity = [];

    const alreadyAdded = app.activity.some(
      (a: any) => a.$?.["android:name"] === ".VRActivity"
    );

    if (!alreadyAdded) {
      (app.activity as any[]).push({
        $: {
          "android:name": ".VRActivity",
          "android:screenOrientation": "landscape",
          "android:exported": "false",
          "android:configChanges":
            "keyboard|keyboardHidden|orientation|screenSize|uiMode",
          "android:launchMode": "singleTask",
        },
        "intent-filter": [
          {
            action: [{ $: { "android:name": "android.intent.action.MAIN" } }],
            category: [
              { $: { "android:name": "com.oculus.intent.category.VR" } },
            ],
          },
        ],
        "meta-data": [
          {
            $: {
              "android:name": "com.oculus.vr.focusaware",
              "android:value": "true",
            },
          },
        ],
      });
    }

    // Quest store validator requires all activities to be landscape.
    // Only apply when targeting Quest (questAppId present); AR/phone apps use portrait.
    const questAppId = props?.android?.questAppId;
    const mainActivity = app.activity?.[0];
    if (questAppId && mainActivity?.$ && mainActivity.$["android:name"] !== ".VRActivity") {
      mainActivity.$["android:screenOrientation"] = "landscape";
    }

    // Inject com.oculus.app_id into <application> for Meta Quest App Name
    if (questAppId) {
      if (!app["meta-data"]) app["meta-data"] = [];
      const alreadyHasAppId = (app["meta-data"] as any[]).some(
        (m: any) => m.$?.["android:name"] === "com.oculus.app_id"
      );
      if (!alreadyHasAppId) {
        (app["meta-data"] as any[]).push({
          $: {
            "android:name": "com.oculus.app_id",
            "android:value": questAppId,
          },
        });
      }
    }

    // Without this the store assumes every headset, including the retired
    // Quest 1, and warns on upload.
    const supportedDevices =
      props?.android?.questSupportedDevices ?? "quest2|questpro|quest3|quest3s";
    if (!app["meta-data"]) app["meta-data"] = [];
    const alreadyHasDevices = (app["meta-data"] as any[]).some(
      (m: any) => m.$?.["android:name"] === "com.oculus.supportedDevices"
    );
    if (!alreadyHasDevices) {
      (app["meta-data"] as any[]).push({
        $: {
          "android:name": "com.oculus.supportedDevices",
          "android:value": supportedDevices,
        },
      });
    }

    // Store delivery targeting is separate from compatibility-mode identity.
    // Meta VR Glasses do not currently have a public com.oculus.supportedDevices
    // identifier. Meta documents "quest3+" as including Quest 3 family,
    // Meta VR Glasses, and future devices.
    const metaDefaultDeviceTargets = resolveMetaDefaultDeviceTargets(props?.android);
    if (metaDefaultDeviceTargets) {
      const alreadyHasDefaultTargets = (app["meta-data"] as any[]).some(
        (m: any) => m.$?.["android:name"] === "com.meta.store.defaultDeviceTargets"
      );
      if (!alreadyHasDefaultTargets) {
        (app["meta-data"] as any[]).push({
          $: {
            "android:name": "com.meta.store.defaultDeviceTargets",
            "android:value": metaDefaultDeviceTargets,
          },
        });
      }
    }

    // Horizon OS logs that an app without this "must fix this to continue to
    // access this SDK" when it first reads a Horizon SDK manager. Meta now
    // documents <metavr:uses-metavr-sdk> and still accepts this older element,
    // which headsets on an OS from before the rename also read. 69 is the
    // first version with hybrid (panel + immersive) apps.
    const manifest = config.modResults.manifest as any;
    manifest.$["xmlns:horizonos"] = "http://schemas.horizonos/sdk";
    if (!manifest["horizonos:uses-horizonos-sdk"]) {
      const minSdkVersion = props?.android?.questHorizonOsSdk?.minSdkVersion ?? 69;
      manifest["horizonos:uses-horizonos-sdk"] = [
        {
          $: {
            "horizonos:minSdkVersion": String(minSdkVersion),
            "horizonos:targetSdkVersion": String(
              props?.android?.questHorizonOsSdk?.targetSdkVersion ?? minSdkVersion
            ),
          },
        },
      ];
    }

    return config;
  });

  return config;
};

/**
 * Moves the Meta-only entries the mods above wrote into main over to
 * app/src/quest/AndroidManifest.xml when app/build.gradle has a quest flavor,
 * so the mobile and pico flavors build without them.
 *
 * A finalized mod, because expo-horizon-core writes the quest manifest from
 * scratch in a dangerous mod and the flavors in an app build.gradle mod; only
 * a finalized mod is sure to see both on disk, and the main manifest written.
 */
const withViroQuestFlavorManifest: ConfigPlugin<ViroConfigurationOptions> = (config, props) => {
  const configured = props?.android?.xRMode ?? [];
  const modes = Array.isArray(configured) ? configured : [configured as XrMode];
  if (!modes.includes("QUEST")) return config;
  const disabled = disabledQuestEntryNames(props?.android?.questFeatures);
  return withFinalizedMod(config, [
    "android",
    async (config) => {
      await syncQuestFlavorManifest(config.modRequest.platformProjectRoot, disabled);
      return config;
    },
  ]);
};

/**
 * Keeps android.metaSpatialLayout out of flavored apps. See
 * util/metaSpatialLayoutGradle.ts for why a quest flavor needs @expo-pico/core's
 * metaLayoutSdk instead of these lines.
 */
const withViroMetaSpatialLayoutFlavors: ConfigPlugin<ViroConfigurationOptions> = (
  config,
  props
) => {
  if (!props?.android?.metaSpatialLayout) return config;
  return withFinalizedMod(config, [
    "android",
    async (config) => {
      if (removeMetaSpatialLayoutFromFlavoredApp(config.modRequest.platformProjectRoot)) {
        console.warn(META_SPATIAL_LAYOUT_FLAVOR_WARNING);
      }
      return config;
    },
  ]);
};

/**
 * Writes android.openxr as com.viro.openxr.* meta-data. Validation runs when
 * the plugin is applied, so a bad value fails `expo prebuild` (and `expo
 * config`) before any native file is touched. Existing entries with the same
 * names are replaced, so a prebuild over an existing android/ stays idempotent.
 */
const withViroOpenXRRenderQuality: ConfigPlugin<ViroConfigurationOptions> = (
  config,
  props
) => {
  const configured = props?.android?.xRMode ?? ["GVR", "AR"];
  const modes = Array.isArray(configured) ? configured : [configured as XrMode];
  const entries = resolveOpenXRRenderQualityMetaData(props?.android?.openxr, modes);
  return withAndroidManifest(config, async (config) => {
    const application = config.modResults.manifest.application?.[0];
    if (!application) return config;
    const kept = (application["meta-data"] ?? []).filter(
      (entry) => !OPENXR_RENDER_QUALITY_META_NAMES.includes(entry.$["android:name"])
    );
    application["meta-data"] = [
      ...kept,
      ...entries.map((entry) => ({
        $: { "android:name": entry.name, "android:value": entry.value },
      })),
    ];
    return config;
  });
};

export const withViroAndroid: ConfigPlugin<ViroConfigurationOptions> = (
  config,
  props
) => {
  config = withBranchAndroid(config, props) as typeof config;
  config = withViroProjectBuildGradle(config) as typeof config;
  config = withViroManifest(config) as typeof config;
  config = withViroOpenXRRenderQuality(config, props) as typeof config;
  config = withViroSettingsGradle(config) as typeof config;
  config = withViroAppBuildGradle(config, props) as typeof config;
  config = withViroQuestActivity(config, props) as typeof config;
  config = withViroQuestFlavorManifest(config, props) as typeof config;
  config = withViroMetaSpatialLayoutFlavors(config, props) as typeof config;
  return config;
};
